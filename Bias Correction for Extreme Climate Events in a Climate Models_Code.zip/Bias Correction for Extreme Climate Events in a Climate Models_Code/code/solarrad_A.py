import xarray as xr
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER

# ========================================
# Step 1: Load Data
# ========================================
ERA5_rsds = r'ERA5_ssr.nc'  # ERA5 surface solar radiation dataset path
CMIP6_rsds = r'CMIP6_rsds.nc'  # CMIP6 surface downwelling shortwave radiation dataset path

# Load datasets with chunked reading (improves memory efficiency for large files)
ds_cmip6_rsds = xr.open_dataset(CMIP6_rsds, chunks={'time': 10})
ds_era5_rsds = xr.open_dataset(ERA5_rsds, chunks={'time': 10})

# Print time ranges to verify data coverage overlap
print("CMIP6 time range:", ds_cmip6_rsds.time.min().values, "to", ds_cmip6_rsds.time.max().values)
print("ERA5 time range:", ds_era5_rsds.valid_time.min().values, "to", ds_era5_rsds.valid_time.max().values)

# Extract variables and perform unit conversion
# ERA5: Total surface solar radiation (ssr) is in J/m²; convert to daily average W/m² (divide by seconds in a day: 86400)
rsds_era5 = ds_era5_rsds['ssr'] / 86400.0
# CMIP6: Surface downwelling shortwave radiation (rsds) is typically in W/m²; no conversion needed
rsds_cmip6 = ds_cmip6_rsds['rsds']

# ========================================
# Step 2: Data Preprocessing
# ========================================
# Standardize coordinate names to ensure consistency across datasets (lat, lon, time)
rsds_era5 = rsds_era5.rename({
    'latitude': 'lat',
    'longitude': 'lon',
    'valid_time': 'time'  # Rename ERA5's "valid_time" to "time" (matches CMIP6)
})

# Handle missing/erroneous values using physical constraints of solar radiation
# Solar radiation cannot be negative; upper bound (1500 W/m²) accounts for extreme but plausible values
rsds_cmip6 = rsds_cmip6.where(rsds_cmip6 >= 0)  # Mask negative values (unphysical)
rsds_cmip6 = rsds_cmip6.where(rsds_cmip6 <= 1500)  # Mask extreme outliers (放宽上限避免过滤有效数据 → "relax upper bound to retain valid data")
rsds_era5 = rsds_era5.where(rsds_era5 >= 0)
rsds_era5 = rsds_era5.where(rsds_era5 <= 1500)

# ========================================
# Step 3: Spatiotemporal Subsetting (1950–2014)
# ========================================
# Define spatial bounds (target region: e.g., CONUS)
lat_min, lat_max = 25, 50          # Latitude range: 25°N to 50°N
lon_min, lon_max = -125, -66       # Longitude range: -125°W to -66°W (western to eastern CONUS)
lon_min_conv, lon_max_conv = lon_min + 360, lon_max + 360  # Convert west longitude to east longitude (0–360° range for dataset compatibility)

# Subset CMIP6 data to target spatiotemporal range
cmip6_crop = rsds_cmip6.sel(
    time=slice("1950", "2014"),  # Temporal subset: 1950–2014
    lat=slice(lat_min, lat_max),  # Latitude subset (ascending order for CMIP6)
    lon=slice(lon_min_conv, lon_max_conv)  # Longitude subset (0–360°E)
)

# Subset ERA5 data (note: ERA5 latitude is often stored in descending order)
era5_crop = rsds_era5.sel(
    time=slice("1950", "2014"),  # Temporal subset: match CMIP6
    lat=slice(lat_max, lat_min),  # Reverse latitude slice to align with CMIP6's ascending order
    lon=slice(lon_min_conv, lon_max_conv)
)

# Verify subsetting results (check data validity and ranges)
print("\nCMIP6 Post-Subsetting Check:")
print(f"Valid data points: {cmip6_crop.count().values}")
print(f"Time range: {cmip6_crop.time.min().values} ~ {cmip6_crop.time.max().values}")
print(f"Latitude range: {cmip6_crop.lat.min().values} ~ {cmip6_crop.lat.max().values}")
print(f"Longitude range: {cmip6_crop.lon.min().values} ~ {cmip6_crop.lon.max().values}")

print("\nERA5 Post-Subsetting Check:")
print(f"Valid data points: {era5_crop.count().values}")
print(f"Time range: {era5_crop.time.min().values} ~ {era5_crop.time.max().values}")
print(f"Latitude range: {era5_crop.lat.min().values} ~ {era5_crop.lat.max().values}")
print(f"Longitude range: {era5_crop.lon.min().values} ~ {era5_crop.lon.max().values}")

# ========================================
# Step 4: Temporal Alignment (Match by Year-Month)
# ========================================
# Add year-month identifiers to resolve date mismatches (e.g., different day-of-month values)
cmip6_crop = cmip6_crop.assign_coords(
    year_month=cmip6_crop.time.dt.strftime('%Y-%m')  # Format: "YYYY-MM" (e.g., "1950-01")
)
era5_crop = era5_crop.assign_coords(
    year_month=era5_crop.time.dt.strftime('%Y-%m')
)

# Identify common year-month pairs between datasets
common_years_months = np.intersect1d(
    cmip6_crop.year_month.values,
    era5_crop.year_month.values
)
print(f"\nNumber of common year-month pairs: {len(common_years_months)}")

# Subset data to retain only common year-month pairs (ensures temporal alignment)
cmip6_aligned = cmip6_crop.sel(
    time=[t for t, ym in zip(cmip6_crop.time.values, cmip6_crop.year_month.values)
          if ym in common_years_months]
)
era5_aligned = era5_crop.sel(
    time=[t for t, ym in zip(era5_crop.time.values, era5_crop.year_month.values)
          if ym in common_years_months]
)

# Verify alignment results
print(f"CMIP6 valid data after alignment: {cmip6_aligned.count().values}")
print(f"ERA5 valid data after alignment: {era5_aligned.count().values}")

# ========================================
# Step 5: Spatial Alignment (Grid Matching)
# ========================================
# Print grid resolution information to compare datasets
print(f"\nCMIP6 grid: {len(cmip6_aligned.lat)} latitude points, {len(cmip6_aligned.lon)} longitude points")
print(f"ERA5 grid: {len(era5_aligned.lat)} latitude points, {len(era5_aligned.lon)} longitude points")

# Align grids by interpolating to the higher-resolution grid (preserves more spatial detail)
if len(cmip6_aligned.lat) > len(era5_aligned.lat):
    # CMIP6 has higher latitude resolution: use CMIP6 grid as target
    target_lat = cmip6_aligned.lat
    target_lon = cmip6_aligned.lon
    era5_aligned = era5_aligned.interp(lat=target_lat, lon=target_lon, method='linear')  # Linear interpolation for ERA5
else:
    # ERA5 has higher resolution: use ERA5 grid as target
    target_lat = era5_aligned.lat
    target_lon = era5_aligned.lon
    cmip6_aligned = cmip6_aligned.interp(lat=target_lat, lon=target_lon, method='linear')  # Linear interpolation for CMIP6

print(f"Aligned grid: {len(target_lat)} latitude points, {len(target_lon)} longitude points")

# ========================================
# Step 6: Bias Correction
# ========================================
# Calculate temporal mean bias (CMIP6 - ERA5) across the aligned period
bias = cmip6_aligned.mean(dim='time') - era5_aligned.mean(dim='time')

# Apply bias correction: subtract mean bias from CMIP6 data
cmip6_corrected = cmip6_aligned - bias

# Compute time-averaged values for visualization
cmip6_mean = cmip6_aligned.mean(dim='time')          # Original CMIP6 mean
cmip6_corrected_mean = cmip6_corrected.mean(dim='time')  # Corrected CMIP6 mean
era5_mean = era5_aligned.mean(dim='time')            # ERA5 observed mean

# Verify data ranges for visualization
print("\nVisualization Data Statistics:")
print(f"CMIP6 mean solar radiation: {cmip6_mean.min().values:.2f}~{cmip6_mean.max().values:.2f} W/m²")
print(f"ERA5 mean solar radiation: {era5_mean.min().values:.2f}~{era5_mean.max().values:.2f} W/m²")

# ========================================
# Step 7: Plot Spatial Distributions
# ========================================
plot_extent = [lon_min, lon_max, lat_min, lat_max]  # Plot extent (west longitude for intuitive visualization)

fig = plt.figure(figsize=(16, 14))  # Set figure size for 2x2 subplots

# 1. Original CMIP6 Mean Solar Radiation
ax1 = fig.add_subplot(2, 2, 1, projection=ccrs.PlateCarree())
ax1.set_extent(plot_extent, crs=ccrs.PlateCarree())  # Set geographic extent
# Contour plot (convert longitude back to west for display: lon - 360)
im1 = ax1.contourf(
    cmip6_mean.lon - 360,
    cmip6_mean.lat,
    cmip6_mean,
    levels=np.linspace(0, 300, 11),  # 11 levels (0–300 W/m², 30 W/m² intervals)
    cmap='YlOrRd',  # Yellow-Orange-Red colormap (intuitive for solar radiation: darker = higher)
    extend='max'    # Extend colorbar for values exceeding max level
)
# Add geographic features
ax1.coastlines(resolution='50m', linewidth=0.8)  # High-resolution coastlines
ax1.add_feature(cfeature.BORDERS, linewidth=0.6)  # Country/state borders
# Add grid lines with labels
gl = ax1.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False  # Hide top labels (avoid clutter)
gl.right_labels = False  # Hide right labels
gl.xformatter = LONGITUDE_FORMATTER  # Format longitude (e.g., 120°W)
gl.yformatter = LATITUDE_FORMATTER   # Format latitude (e.g., 40°N)
# Add title and colorbar
ax1.set_title('(a) Original CMIP6 Mean Solar Radiation (W/m²)', fontsize=12)
plt.colorbar(im1, ax=ax1, orientation='vertical', label='Solar Radiation (W/m²)')

# 2. ERA5 Observed Mean Solar Radiation
ax2 = fig.add_subplot(2, 2, 2, projection=ccrs.PlateCarree())
ax2.set_extent(plot_extent, crs=ccrs.PlateCarree())
im2 = ax2.contourf(
    era5_mean.lon - 360,
    era5_mean.lat,
    era5_mean,
    levels=np.linspace(0, 300, 11),
    cmap='YlOrRd',
    extend='max'
)
ax2.coastlines(resolution='50m', linewidth=0.8)
ax2.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax2.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False
gl.right_labels = False
gl.xformatter = LONGITUDE_FORMATTER
gl.yformatter = LATITUDE_FORMATTER
ax2.set_title('(b) ERA5 Observed Mean Solar Radiation (W/m²)', fontsize=12)
plt.colorbar(im2, ax=ax2, orientation='vertical', label='Solar Radiation (W/m²)')

# 3. CMIP6 Bias (CMIP6 - ERA5)
ax3 = fig.add_subplot(2, 2, 3, projection=ccrs.PlateCarree())
ax3.set_extent(plot_extent, crs=ccrs.PlateCarree())
# Dynamically set bias levels to cover full range of bias values
bias_min = np.nanmin(bias.values)
bias_max = np.nanmax(bias.values)
bias_levels = np.linspace(np.floor(bias_min), np.ceil(bias_max), 11)
im3 = ax3.contourf(
    bias.lon - 360,
    bias.lat,
    bias,
    levels=bias_levels,
    cmap='RdBu_r',  # Red-Blue diverging colormap (red = positive bias, blue = negative bias)
    extend='both'   # Extend colorbar for values above max and below min
)
ax3.coastlines(resolution='50m', linewidth=0.8)
ax3.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax3.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False
gl.right_labels = False
gl.xformatter = LONGITUDE_FORMATTER
gl.yformatter = LATITUDE_FORMATTER
ax3.set_title('(c) CMIP6 Bias (CMIP6 - ERA5) (W/m²)', fontsize=12)
plt.colorbar(im3, ax=ax3, orientation='vertical', label='Bias (W/m²)')

# 4. Bias-Corrected CMIP6 Mean Solar Radiation
ax4 = fig.add_subplot(2, 2, 4, projection=ccrs.PlateCarree())
ax4.set_extent(plot_extent, crs=ccrs.PlateCarree())
im4 = ax4.contourf(
    cmip6_corrected_mean.lon - 360,
    cmip6_corrected_mean.lat,
    cmip6_corrected_mean,
    levels=np.linspace(0, 300, 11),
    cmap='YlOrRd',
    extend='max'
)
ax4.coastlines(resolution='50m', linewidth=0.8)
ax4.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax4.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False
gl.right_labels = False
gl.xformatter = LONGITUDE_FORMATTER
gl.yformatter = LATITUDE_FORMATTER
ax4.set_title('(d) Bias-Corrected CMIP6 Mean Solar Radiation (W/m²)', fontsize=12)
plt.colorbar(im4, ax=ax4, orientation='vertical', label='Solar Radiation (W/m²)')

# Adjust layout to avoid label cutoff and save plot
plt.tight_layout()
plt.savefig(
    'cmip6_solar_radiation_bias_correction_1950-2014_colorbars.png',
    dpi=300,                  # 300 DPI for publication-quality resolution
    bbox_inches='tight'       # Crop extra whitespace to prevent label cutoff
)
plt.show()