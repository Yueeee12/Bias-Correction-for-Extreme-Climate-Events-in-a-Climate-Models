import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

# ========================================
# Step 1: Load Data
# ========================================
ERA5_rsds = r'ERA5_ssr.nc'  # ERA5 surface solar radiation data
CMIP6_rsds = r'CMIP6_rsds.nc'  # CMIP6 surface downwelling shortwave radiation data

# Open datasets with chunked reading for efficient processing
ds_cmip6_rsds = xr.open_dataset(CMIP6_rsds, chunks={'time': 10})
ds_era5_rsds = xr.open_dataset(ERA5_rsds, chunks={'time': 10})

# Print time ranges to verify data coverage
print("CMIP6 time range:", ds_cmip6_rsds.time.min().values, "to", ds_cmip6_rsds.time.max().values)
print("ERA5 time range:", ds_era5_rsds.valid_time.min().values, "to", ds_era5_rsds.valid_time.max().values)

# Unit conversion: ERA5 ssr (J/m²/day) to W/m² (divide by seconds in a day)
rsds_era5 = ds_era5_rsds['ssr'] / 86400.0
rsds_cmip6 = ds_cmip6_rsds['rsds']  # CMIP6 rsds is already in W/m²

# ========================================
# Step 2: Handle Missing Values
# ========================================
# Mask extreme values (likely missing or erroneous)
rsds_era5 = rsds_era5.where(rsds_era5 < 1e10)
rsds_cmip6 = rsds_cmip6.where(rsds_cmip6 < 1e10)

# ========================================
# Step 3: Spatial Subsetting (CONUS)
# ========================================
# Define spatial bounds for Continental United States (CONUS)
lat_min, lat_max = 24.5, 49.4  # Latitude range: ~25°N to ~49°N
lon_min, lon_max = -125, -67   # Longitude range: ~125°W to ~67°W
lon_min_conv = lon_min + 360   # Convert to 0-360°E longitude (for dataset compatibility)
lon_max_conv = lon_max + 360

# Standardize ERA5 coordinate names to match CMIP6 ('latitude' → 'lat', 'longitude' → 'lon')
rsds_era5 = rsds_era5.rename({'latitude': 'lat', 'longitude': 'lon'})

# Subset ERA5 data (note: ERA5 latitude is often in descending order)
rsds_era5_cropped = rsds_era5.sel(
    valid_time=slice("1950", "2014"),  # Time range: 1950–2014
    lat=slice(lat_max, lat_min),      # Reverse latitude slice for ERA5
    lon=slice(lon_min_conv, lon_max_conv)
)

# Subset CMIP6 data
rsds_cmip6_cropped = rsds_cmip6.sel(
    time=slice("1950", "2014"),       # Time range: 1950–2014 (match ERA5)
    lat=slice(lat_min, lat_max),
    lon=slice(lon_min_conv, lon_max_conv)
)

# ========================================
# Step 4: Resampling + Regional Averaging
# ========================================
# Resample to monthly mean values ('1MS' = month-start frequency)
rsds_era5_monthly = rsds_era5_cropped.resample(valid_time='1MS').mean()
rsds_cmip6_monthly = rsds_cmip6_cropped.resample(time='1MS').mean()

# Compute spatial averages (regional mean over CONUS)
rsds_era5_series = rsds_era5_monthly.mean(dim=['lat', 'lon'])
rsds_cmip6_series = rsds_cmip6_monthly.mean(dim=['lat', 'lon'])

# Verify time series lengths match
print("ERA5 time series length:", rsds_era5_series.shape)
print("CMIP6 time series length:", rsds_cmip6_series.shape)

# ========================================
# Step 5: Point Verification → Check Interannual Differences
# ========================================
# Select a representative grid point for detailed comparison
# (target: ~30°N latitude, ~95°W longitude (converted to 265°E))
era5_single_point = rsds_era5_monthly.sel(lat=30, lon=lon_min_conv+30, method='nearest')
cmip6_single_point = rsds_cmip6_monthly.sel(lat=30, lon=lon_min_conv+30, method='nearest')

# ========================================
# Step 6: Plot Time Series (Regional Means)
# ========================================
plt.figure(figsize=(14, 5))
plt.plot(rsds_era5_series.valid_time.values, rsds_era5_series, label='ERA5 Regional Mean', color='blue')
plt.plot(rsds_cmip6_series.time.values, rsds_cmip6_series, label='CMIP6 Regional Mean', color='red')

# Customize plot
plt.title("Monthly Mean Solar Radiation (Regional Mean over CONUS)")
plt.ylabel("Solar Radiation (W/m²)")
plt.xlabel("Time")
plt.legend()
plt.grid(True, linestyle='--', alpha=0.7)
plt.tight_layout()  # Adjust layout to prevent label cutoff
plt.show()

# ========================================
# Step 7: Single Point Time Series Comparison
# ========================================
plt.figure(figsize=(14, 5))
plt.plot(era5_single_point.valid_time.values, era5_single_point, label='ERA5 Single Point', color='green')
plt.plot(cmip6_single_point.time.values, cmip6_single_point, label='CMIP6 Single Point', color='orange')

# Customize plot
plt.title("Monthly Mean Solar Radiation (Single Grid Point: ~30°N, ~95°W)")
plt.ylabel("Solar Radiation (W/m²)")
plt.xlabel("Time")
plt.legend()
plt.grid(True, linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()

# Zoomed-in view (2000–2005) to highlight short-term variability
plt.figure(figsize=(14, 5))
plt.plot(rsds_era5_series.valid_time.values, rsds_era5_series, label='ERA5 Regional Mean', color='blue')
plt.xlim(np.datetime64('2000-01'), np.datetime64('2005-12'))  # Focus on 5-year period
plt.title("Zoomed View: Monthly Mean Solar Radiation (2000–2005)")
plt.ylabel("Solar Radiation (W/m²)")
plt.xlabel("Time")
plt.legend()
plt.grid(True, linestyle='--', alpha=0.7)
plt.tight_layout()
plt.show()

# ========================================
# Step 8: Check for Zero Standard Deviation (Constant Values)
# ========================================
# Low standard deviation may indicate problematic data (e.g., stagnant values)
print("Regional average time series standard deviation:")
print(f"ERA5: {rsds_era5_series.std().values:.2f} W/m²")
print(f"CMIP6: {rsds_cmip6_series.std().values:.2f} W/m²")

print("\nSingle point time series standard deviation:")
print(f"ERA5: {era5_single_point.std().values:.2f} W/m²")
print(f"CMIP6: {cmip6_single_point.std().values:.2f} W/m²")