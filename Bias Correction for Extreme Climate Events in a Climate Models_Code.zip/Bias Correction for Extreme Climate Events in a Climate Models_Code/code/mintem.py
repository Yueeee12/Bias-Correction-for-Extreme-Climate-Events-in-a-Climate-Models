import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

# ----------------------------
# Step 1: Load Data
# ----------------------------
# File paths
ERA5_tasmin1 = 'mn2t.nc'
ERA5_tasmin2 = 'mn2t_1.nc'
CMIP6_tasmin = 'CMIP6_tasmin.nc'

# Load ERA5 datasets
ds1 = xr.open_dataset(ERA5_tasmin1, chunks={'valid_time': 100})
ds2 = xr.open_dataset(ERA5_tasmin2, chunks={'valid_time': 100})

# Concatenate and sort ERA5 datasets along time dimension
ds_era5 = xr.concat([ds1, ds2], dim="valid_time")
ds_era5 = ds_era5.sortby("valid_time")

# Load CMIP6
ds_cmip6 = xr.open_dataset(CMIP6_tasmin, chunks={'valid_time': 100})

# Print time ranges
print("CMIP6 time range:", ds_cmip6.time.min().values, "to", ds_cmip6.time.max().values)
print("ERA5 time range:", ds_era5.valid_time.min().values, "to", ds_era5.valid_time.max().values)

# ----------------------------
# Step 2: Extract variables
# ----------------------------
tasmin_era5 = ds_era5['mn2t']      # ERA5 daily minimum 2m temperature (K)
tasmin_cmip6 = ds_cmip6['tasmin']  # CMIP6 daily minimum 2m temperature (K)
print("ERA5 lon range:", tasmin_era5.longitude.min().values, "to", tasmin_era5.longitude.max().values)

# ----------------------------
# Step 3: Handle missing values
# ----------------------------
tasmin_cmip6 = tasmin_cmip6.where(tasmin_cmip6 != 1e20)
tasmin_era5 = tasmin_era5.where(tasmin_era5 < 1e10)

# ----------------------------
# Step 4: Crop region (e.g., CONUS)
# ----------------------------
lat_min, lat_max = 24.5, 49.4
lon_min, lon_max = -125, -67
lon_min_conv = lon_min + 360
lon_max_conv = lon_max + 360

# Rename ERA5 dimensions to match CMIP6
tasmin_era5 = tasmin_era5.rename({'latitude': 'lat', 'longitude': 'lon'})

# Fix ERA5 longitude to match CMIP6 format (0–360)
if (tasmin_era5.lon < 0).any():
    tasmin_era5['lon'] = tasmin_era5['lon'] % 360

# Crop ERA5
tasmin_era5_cropped = tasmin_era5.sel(
    valid_time=slice('1950', '2014'),
    lat=slice(lat_max, lat_min),
    lon=slice(lon_min_conv, lon_max_conv)
)

# Crop CMIP6
tasmin_cmip6_cropped = tasmin_cmip6.sel(
    time=slice('1950', '2014'),
    lat=slice(lat_min, lat_max),
    lon=slice(lon_min_conv, lon_max_conv)
)

# ----------------------------
# Step 5: Compute time-averaged temperature
# ----------------------------
tasmin_era5_mean = tasmin_era5_cropped.mean(dim='valid_time')
tasmin_cmip6_mean = tasmin_cmip6_cropped.mean(dim='time')

# ----------------------------
# Step 6: Interpolate ERA5 to CMIP6 grid
# ----------------------------
tasmin_era5_interp = tasmin_era5_mean.interp(
    lat=tasmin_cmip6_mean.lat,
    lon=tasmin_cmip6_mean.lon
)

# ----------------------------
# Step 7: Calculate the difference (ERA5 - CMIP6)
# ----------------------------
diff_tasmin = tasmin_era5_interp - tasmin_cmip6_mean

# ----------------------------
# Step 8: Optimized plotting function
# ----------------------------
def plot_map(ax, data, title, cmap, vmin=None, vmax=None, extend='both'):
    im = data.plot.pcolormesh(
        ax=ax,
        transform=ccrs.PlateCarree(),
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        add_colorbar=False,
        shading='auto'
    )
    ax.set_title(title, fontsize=12)
    ax.coastlines()
    ax.add_feature(cfeature.BORDERS, linewidth=0.5)
    ax.add_feature(cfeature.STATES.with_scale('50m'), linewidth=0.3)
    ax.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())
    return im

# ----------------------------
# Step 9: Visualize three images
# ----------------------------
fig, axs = plt.subplots(1, 3, figsize=(21, 6), subplot_kw={'projection': ccrs.PlateCarree()})

# Titles & color schemes
titles = [
    'CMIP6 Mean Minimum Temperature (K)',
    'ERA5 Interpolated Minimum Temperature (K)',
    'Difference (ERA5 - CMIP6) (K)'
]
cmaps = ['YlGnBu', 'YlOrRd', 'RdBu_r']

# Calculate color ranges (using 95% percentiles to remove extreme outliers)
tasmin_min = float(np.nanpercentile([tasmin_cmip6_mean, tasmin_era5_interp], 2))
tasmin_max = float(np.nanpercentile([tasmin_cmip6_mean, tasmin_era5_interp], 98))
diff_absmax = float(np.nanmax(np.abs(diff_tasmin)))

# Data lists
data_list = [tasmin_cmip6_mean, tasmin_era5_interp, diff_tasmin]
vmin_list = [tasmin_min, tasmin_min, -diff_absmax]
vmax_list = [tasmin_max, tasmin_max, diff_absmax]

# Plot each image
for ax, data, title, cmap, vmin, vmax in zip(axs, data_list, titles, cmaps, vmin_list, vmax_list):
    im = plot_map(ax, data, title, cmap, vmin, vmax)
    cb = fig.colorbar(im, ax=ax, orientation='vertical', shrink=0.75, pad=0.02)
    cb.set_label('K')

plt.tight_layout()
plt.show()

# ----------------------------
# Step 4: Monthly mean minimum temperature time series
# ----------------------------

# Standardize time format (ERA5 uses valid_time, CMIP6 uses time)
tasmin_era5_monthly = tasmin_era5_cropped.resample(valid_time='1MS').mean(dim='valid_time')
tasmin_cmip6_monthly = tasmin_cmip6_cropped.resample(time='1MS').mean(dim='time')

# Regional average (spatial average) to get time series
tasmin_era5_series = tasmin_era5_monthly.mean(dim=['lat', 'lon'])
tasmin_cmip6_series = tasmin_cmip6_monthly.mean(dim=['lat', 'lon'])

# Unify time formats
era5_time = tasmin_era5_series.valid_time.values
cmip6_time = tasmin_cmip6_series.time.values

# Unit conversion (K → °C)
tasmin_era5_series = tasmin_era5_series - 273.15
tasmin_cmip6_series = tasmin_cmip6_series - 273.15

# Plot
plt.figure(figsize=(12, 5))
plt.plot(era5_time, tasmin_era5_series, label='ERA5 Tmin', color='blue')
plt.plot(cmip6_time, tasmin_cmip6_series, label='CMIP6 Tmin', color='red')
plt.title("Monthly Mean Minimum Temperature Time Series")
plt.ylabel("Temperature (°C)")
plt.xlabel("Time")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()


# ----------------------------
# Step 5: 95th percentile minimum temperature spatial maps
# ----------------------------

# Calculate 95th percentile along time dimension
tasmin_era5_p95 = tasmin_era5_cropped.quantile(0.95, dim='valid_time')
tasmin_cmip6_p95 = tasmin_cmip6_cropped.quantile(0.95, dim='time')

# Interpolate ERA5 to CMIP6 grid (for consistency)
tasmin_era5_p95_interp = tasmin_era5_p95.interp(
    lat=tasmin_cmip6_p95.lat,
    lon=tasmin_cmip6_p95.lon
)

# Calculate difference
diff_p95 = tasmin_era5_p95_interp - tasmin_cmip6_p95

# Plot
fig, axs = plt.subplots(1, 3, figsize=(21, 6), subplot_kw={'projection': ccrs.PlateCarree()})

titles = [
    'CMIP6 95th Percentile of Tmin (K)',
    'ERA5 95th Percentile of Tmin (K)',
    'Difference (ERA5 - CMIP6) (K)'
]
cmaps = ['YlGnBu', 'YlOrRd', 'RdBu_r']

vmin = float(np.nanpercentile([tasmin_cmip6_p95, tasmin_era5_p95_interp], 2))
vmax = float(np.nanpercentile([tasmin_cmip6_p95, tasmin_era5_p95_interp], 98))
diff_max = float(np.nanmax(np.abs(diff_p95)))

data_list = [tasmin_cmip6_p95, tasmin_era5_p95_interp, diff_p95]
vmin_list = [vmin, vmin, -diff_max]
vmax_list = [vmax, vmax, diff_max]

for ax, data, title, cmap, vmin_, vmax_ in zip(axs, data_list, titles, cmaps, vmin_list, vmax_list):
    im = plot_map(ax, data, title, cmap, vmin=vmin_, vmax=vmax_)
    cb = fig.colorbar(im, ax=ax, orientation='vertical', shrink=0.75, pad=0.02)
    cb.set_label("K")

plt.tight_layout()
plt.show()