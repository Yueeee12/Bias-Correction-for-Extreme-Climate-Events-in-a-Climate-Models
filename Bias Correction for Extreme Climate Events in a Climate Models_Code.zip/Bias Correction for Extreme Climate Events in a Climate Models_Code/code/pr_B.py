import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import TensorDataset, DataLoader
import pandas as pd

# Set random seeds for reproducibility
torch.manual_seed(42)
np.random.seed(42)


# ----------------------------
# 1. Data Loading and Preprocessing (Same as Previous)
# ----------------------------
def load_and_preprocess():
    # Load datasets
    cmip6 = xr.open_dataset("CMIP6_pr.nc")
    era5 = xr.open_dataset("ERA5_tp.nc", chunks={"time": 10})

    # Print time ranges
    print("CMIP6 time range:", cmip6.time.min().values, "to", cmip6.time.max().values)
    print("ERA5 time range:", era5.valid_time.min().values, "to", era5.valid_time.max().values)

    # Unit conversion
    cmip6_daily = cmip6['pr'] * 86400  # Convert from kg/m²/s to mm/day
    era5_daily = era5['tp'] * 1000     # Convert from meters to mm

    # Standardize coordinate names
    era5_daily = era5_daily.rename({
        'latitude': 'lat',
        'longitude': 'lon',
        'valid_time': 'time'
    })

    # Handle missing values
    cmip6_daily = cmip6_daily.where(cmip6_daily != 1e20)  # Mask CMIP6 missing values (flagged as 1e20)
    era5_daily = era5_daily.where(era5_daily < 1e10)      # Mask extreme outliers in ERA5

    # Spatial subsetting
    lat_min, lat_max = 25, 50          # Latitude range (25°N to 50°N)
    lon_min, lon_max = -125, -66       # Longitude range (-125°W to -66°W)
    lon_min_conv, lon_max_conv = lon_min + 360, lon_max + 360  # Convert W to E longitude (0-360°)

    # Temporal subsetting (1950-2014)
    cmip6_crop = cmip6_daily.sel(
        time=slice("1950", "2014"),
        lat=slice(lat_min, lat_max),
        lon=slice(lon_min_conv, lon_max_conv)
    )

    era5_crop = era5_daily.sel(
        time=slice("1950", "2014"),
        lat=slice(lat_max, lat_min),  # Reverse latitude for ERA5 (descending order)
        lon=slice(lon_min_conv, lon_max_conv)
    )

    # Temporal alignment (match dates between CMIP6 and ERA5)
    def time_to_str(ds):
        """Convert datetime values to string format (YYYY-MM-DD) for date matching."""
        return [str(t)[:10] for t in ds.time.values]

    cmip6_str = time_to_str(cmip6_crop)
    era5_str = time_to_str(era5_crop)
    common_str = np.intersect1d(cmip6_str, era5_str)  # Find common dates

    # Subset data to retain only common dates
    cmip6_align = cmip6_crop.sel(
        time=[t for t, s in zip(cmip6_crop.time.values, cmip6_str) if s in common_str]
    )

    era5_align = era5_crop.sel(
        time=[t for t, s in zip(era5_crop.time.values, era5_str) if s in common_str]
    )

    # Spatial alignment (interpolate to the higher-resolution grid)
    # Use the grid with more latitude/longitude points as the target
    target_lat = cmip6_align.lat if len(cmip6_align.lat) > len(era5_align.lat) else era5_align.lat
    target_lon = cmip6_align.lon if len(cmip6_align.lon) > len(era5_align.lon) else era5_align.lon

    # Interpolate both datasets to the target grid
    cmip6_align = cmip6_align.interp(lat=target_lat, lon=target_lon, method='linear')
    era5_align = era5_align.interp(lat=target_lat, lon=target_lon, method='linear')

    return cmip6_align, era5_align, (lon_min, lon_max, lat_min, lat_max)


# ----------------------------
# 2. Quantile Mapping (QM) Correction (Same as Previous)
# ----------------------------
def quantile_mapping(cmip_data, obs_data, n_quantiles=100):
    """Apply quantile mapping correction to CMIP6 precipitation data using ERA5 observations."""
    lat_dim, lon_dim = cmip_data.shape[1], cmip_data.shape[2]
    qm_corrected = np.zeros_like(cmip_data)  # Array to store QM-corrected results

    # Apply QM to each grid point individually
    for i in range(lat_dim):
        for j in range(lon_dim):
            # Extract time series for the current grid point
            cmip_grid = cmip_data[:, i, j].values
            obs_grid = obs_data[:, i, j].values

            # Mask out missing values
            valid_mask = ~np.isnan(cmip_grid) & ~np.isnan(obs_grid)
            cmip_valid = cmip_grid[valid_mask]
            obs_valid = obs_grid[valid_mask]

            # Skip if there are not enough valid data points for quantile calculation
            if len(cmip_valid) < n_quantiles:
                qm_corrected[:, i, j] = cmip_grid  # Retain original data if insufficient valid points
                continue

            # Calculate quantiles for observed and simulated data
            quantiles = np.linspace(0, 1, n_quantiles)  # Quantiles from 0 to 1
            cmip_quantiles = np.quantile(cmip_valid, quantiles)  # CMIP6 quantile distribution
            obs_quantiles = np.quantile(obs_valid, quantiles)    # ERA5 quantile distribution

            # Map CMIP6 values to ERA5 quantiles using linear interpolation
            qm_corrected[:, i, j] = np.interp(
                cmip_grid, cmip_quantiles, obs_quantiles,
                left=np.nan, right=np.nan  # Use NaN for values outside quantile range
            )

    # Convert corrected array back to xarray DataArray for consistency
    return xr.DataArray(
        qm_corrected,
        dims=cmip_data.dims,
        coords=cmip_data.coords,
        name='pr_corrected'
    )


# ----------------------------
# 3. Prepare Data for PyTorch
# ----------------------------
def prepare_pytorch_data(cmip_data, obs_data, qm_data, window_size=14):
    """Prepare time-series data for PyTorch ConvLSTM model training."""
    # Convert xarray DataArrays to numpy arrays
    cmip_np = cmip_data.values
    obs_np = obs_data.values
    qm_np = qm_data.values

    # Calculate residuals (observed - QM-corrected) to be predicted by the deep model
    residual = obs_np - qm_np

    # Standardize data (z-score normalization) to stabilize model training
    scaler_cmip = StandardScaler()    # Scaler for raw CMIP6 data
    scaler_residual = StandardScaler()# Scaler for residuals

    time_steps, lat, lon = cmip_np.shape
    # Flatten spatial dimensions for scaling (shape: [time_steps, lat*lon])
    cmip_flat = cmip_np.reshape(time_steps, -1)
    residual_flat = residual.reshape(time_steps, -1)

    # Apply scaling and reshape back to original spatial dimensions
    cmip_scaled = scaler_cmip.fit_transform(cmip_flat).reshape(time_steps, lat, lon)
    residual_scaled = scaler_residual.fit_transform(residual_flat).reshape(time_steps, lat, lon)

    # Create sliding windows for time-series input
    X, y = [], []
    for i in range(window_size, len(cmip_scaled)):
        # Input window: concatenate raw CMIP6 and normalized QM data as features
        X_window = np.stack([
            cmip_scaled[i - window_size:i],  # Raw CMIP6 (scaled) over past 'window_size' steps
            qm_np[i - window_size:i] / np.nanmax(qm_np)  # QM data (normalized to 0-1)
        ], axis=-1)  # Shape: [window_size, lat, lon, 2] (2 features)
        X.append(X_window)
        # Target: residual at the current time step (scaled)
        y.append(residual_scaled[i])

    # Convert lists to numpy arrays
    X = np.array(X)
    y = np.array(y)

    # Convert to PyTorch tensors and rearrange dimensions for ConvLSTM:
    # From [samples, time_steps, lat, lon, features] to [samples, features, time_steps, lat, lon]
    X = torch.FloatTensor(X).permute(0, 4, 1, 2, 3)
    y = torch.FloatTensor(y)

    # Split into training and test sets (80% train, 20% test; no shuffle to preserve time order)
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, shuffle=False
    )

    return (X_train, X_test, y_train, y_test,
            scaler_residual, lat, lon, window_size)


# ----------------------------
# 4. Build PyTorch ConvLSTM Model
# ----------------------------
class ConvLSTMModel(nn.Module):
    """ConvLSTM-based model for residual correction of QM-corrected precipitation data."""
    def __init__(self, input_channels, hidden_channels, kernel_size, output_size):
        super(ConvLSTMModel, self).__init__()
        # First ConvLSTM layer (captures local spatial-temporal features)
        self.conv_lstm1 = nn.ConvLSTM(
            input_size=(output_size[0], output_size[1]),  # Spatial size (lat, lon)
            hidden_size=hidden_channels[0],               # Number of hidden units
            kernel_size=kernel_size,                      # Convolution kernel size (3x3)
            num_layers=1,                                 # Single layer
            batch_first=True,                             # Batch dimension first (batch, time, lat, lon, channels)
            bias=True,
            return_all_layers=False                       # Return only the final layer output
        )

        # Second ConvLSTM layer (refines spatial-temporal dependencies)
        self.conv_lstm2 = nn.ConvLSTM(
            input_size=(output_size[0], output_size[1]),
            hidden_size=hidden_channels[1],
            kernel_size=kernel_size,
            num_layers=1,
            batch_first=True,
            bias=True,
            return_all_layers=False
        )

        # Batch normalization (stabilizes training by normalizing activations)
        self.batch_norm = nn.BatchNorm2d(hidden_channels[1])

        # 3D convolution layer (combines temporal and spatial features for final prediction)
        self.conv3d = nn.Conv3d(
            in_channels=hidden_channels[1],  # Input channels from ConvLSTM
            out_channels=1,                  # Output 1 channel (residual)
            kernel_size=(3, 3, 3),           # 3D kernel (time, lat, lon)
            padding=(1, 1, 1)                # Padding to preserve spatial size
        )

        self.relu = nn.ReLU()  # ReLU activation function

    def forward(self, x):
        """Forward pass of the ConvLSTM model."""
        # Rearrange dimensions for ConvLSTM: [batch, features, time, lat, lon] → [batch, time, lat, lon, features]
        x = x.permute(0, 2, 3, 4, 1)

        # First ConvLSTM layer
        out, _ = self.conv_lstm1(x)
        x = out[0]  # Extract output from the final layer (shape: [batch, time, lat, lon, hidden_channels[0]])

        # Second ConvLSTM layer
        out, _ = self.conv_lstm2(x)
        x = out[0]  # Shape: [batch, time, lat, lon, hidden_channels[1]]

        # Rearrange for batch normalization: [batch, hidden_channels[1], time, lat, lon]
        x = x.permute(0, 4, 1, 2, 3)
        # Use only the final time step for prediction and apply batch normalization
        x = self.batch_norm(x[:, :, -1, :, :])  # Shape: [batch, hidden_channels[1], lat, lon]
        x = self.relu(x)  # Apply ReLU activation

        # Add time dimension back for 3D convolution (shape: [batch, hidden_channels[1], 1, lat, lon])
        x = x.unsqueeze(2)

        # 3D convolution to generate final residual prediction
        x = self.conv3d(x)
        # Remove extra dimensions (channels and time) to match target shape: [batch, lat, lon]
        x = x.squeeze(1).squeeze(1)

        return x


# ----------------------------
# 5. Main Workflow
# ----------------------------
if __name__ == "__main__":
    # Step 1: Load and preprocess data
    print("Loading and preprocessing data...")
    cmip, obs, extent = load_and_preprocess()
    lon_min, lon_max, lat_min, lat_max = extent  # Geographic extent for plotting

    # Step 2: Apply Quantile Mapping (QM) correction
    print("Performing Quantile Mapping correction...")
    cmip_qm = quantile_mapping(cmip, obs)

    # Step 3: Prepare data for PyTorch model
    print("Preparing data for ConvLSTM model...")
    X_train, X_test, y_train, y_test, scaler_res, lat_dim, lon_dim, win_size = prepare_pytorch_data(
        cmip, obs, cmip_qm, window_size=14  # Use 14-day sliding window
    )

    # Create DataLoader for batch training
    train_dataset = TensorDataset(X_train, y_train)
    train_loader = DataLoader(train_dataset, batch_size=32, shuffle=False)  # No shuffle for time series

    # Step 4: Initialize model, loss function, and optimizer
    print("Initializing ConvLSTM model...")
    model = ConvLSTMModel(
        input_channels=2,          # 2 input features (raw CMIP6, QM-corrected)
        hidden_channels=[32, 16],  # Hidden units for ConvLSTM layers (32 → 16)
        kernel_size=(3, 3),        # 3x3 convolution kernel
        output_size=(lat_dim, lon_dim)  # Output spatial size (matches grid dimensions)
    )

    criterion = nn.MSELoss()  # Mean Squared Error loss for regression
    optimizer = optim.Adam(model.parameters(), lr=0.001)  # Adam optimizer with learning rate 0.001

    # Step 5: Train the model
    print("Training ConvLSTM model...")
    epochs = 20  # Number of training epochs
    # Use GPU if available, otherwise CPU
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    model.to(device)  # Move model to target device

    for epoch in range(epochs):
        model.train()  # Set model to training mode
        train_loss = 0.0  # Accumulate training loss

        # Iterate over training batches
        for batch_X, batch_y in train_loader:
            # Move batch data to device (GPU/CPU)
            batch_X, batch_y = batch_X.to(device), batch_y.to(device)

            # Forward pass: compute model predictions
            outputs = model(batch_X)
            # Calculate loss between predictions and targets
            loss = criterion(outputs, batch_y)

            # Backward pass: compute gradients and optimize
            optimizer.zero_grad()  # Reset gradients to avoid accumulation
            loss.backward()        # Compute gradients via backpropagation
            optimizer.step()       # Update model weights

            # Accumulate loss (multiply by batch size to account for partial batches)
            train_loss += loss.item() * batch_X.size(0)

        # Evaluate model on test set
        model.eval()  # Set model to evaluation mode
        with torch.no_grad():  # Disable gradient computation for efficiency
            X_test_dev, y_test_dev = X_test.to(device), y_test.to(device)
            y_pred = model(X_test_dev)  # Predict on test set
            test_loss = criterion(y_pred, y_test_dev).item()  # Test set loss

        # Print training progress
        print(
            f'Epoch {epoch + 1}/{epochs}, '
            f'Train Loss: {train_loss / len(train_dataset):.6f}, '
            f'Test Loss: {test_loss:.6f}'
        )

    # Step 6: Generate final corrected results
    print("Generating final corrected precipitation data...")
    model.eval()
    with torch.no_grad():
        # Predict residuals on test set
        y_pred_scaled = model(X_test.to(device)).cpu().numpy()

    # Inverse standardization to recover original residual scale
    time_test = y_pred_scaled.shape[0]
    y_pred = scaler_res.inverse_transform(
        y_pred_scaled.reshape(time_test, -1)  # Flatten for inverse scaling
    ).reshape(time_test, lat_dim, lon_dim)  # Reshape back to [time, lat, lon]

    # Final correction: QM-corrected data + predicted residuals
    # Subset QM data to match test set time range
    cmip_qm_test = cmip_qm.isel(time=slice(win_size, None))[-time_test:].values
    cmip_final = cmip_qm_test + y_pred  # Add predicted residuals to QM data

    # Convert final results back to xarray DataArray for plotting
    cmip_final_da = xr.DataArray(
        cmip_final,
        dims=['time', 'lat', 'lon'],
        coords={
            'time': cmip_qm.isel(time=slice(win_size, None))[-time_test:].time,  # Match test set time coords
            'lat': cmip.lat,
            'lon': cmip.lon
        }
    )

    # ----------------------------
    # 6. Result Visualization
    # ----------------------------
    print("Plotting results...")
    # Calculate time-averaged precipitation for the test period
    # Subset all datasets to the test set time range
    obs_mean = obs.isel(time=slice(win_size, None))[-time_test:].mean(dim='time')
    cmip_raw_mean = cmip.isel(time=slice(win_size, None))[-time_test:].mean(dim='time')
    cmip_qm_mean = cmip_qm.isel(time=slice(win_size, None))[-time_test:].mean(dim='time')
    cmip_final_mean = cmip_final_da.mean(dim='time')

    # Create 2x2 subplot for comparison
    fig = plt.figure(figsize=(18, 16))

    # (a) Raw CMIP6 Precipitation
    ax1 = fig.add_subplot(2, 2, 1, projection=ccrs.PlateCarree())
    ax1.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())
    im1 = ax1.contourf(
        cmip_raw_mean.lon, cmip_raw_mean.lat, cmip_raw_mean,
        levels=np.arange(0, 12, 1),  # Precipitation levels (0-11 mm/day, 1 mm/day intervals)
        cmap='Blues',
        extend='max'  # Use extended colorbar for values above max level
    )
    ax1.coastlines(resolution='50m', linewidth=0.8)  # Add coastlines
    ax1.set_title('(a) Original CMIP6', fontsize=12)
    # Add colorbar with label
    plt.colorbar(im1, ax=ax1, orientation='vertical', label='Precipitation (mm/day)')

    # (b) QM-Corrected CMIP6 Precipitation
    ax2 = fig.add_subplot(2, 2, 2, projection=ccrs.PlateCarree())
    ax2.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())
    im2 = ax2.contourf(
        cmip_qm_mean.lon, cmip_qm_mean.lat, cmip_qm_mean,
        levels=np.arange(0, 12, 1),
        cmap='Blues',
        extend='max'
    )
    ax2.coastlines(resolution='50m', linewidth=0.8)
    ax2.set_title('(b) QM Corrected', fontsize=12)
    plt.colorbar(im2, ax=ax2, orientation='vertical', label='Precipitation (mm/day)')

    # (c) QM + ConvLSTM Corrected Precipitation
    ax3 = fig.add_subplot(2, 2, 3, projection=ccrs.PlateCarree())
    ax3.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())
    im3 = ax3.contourf(
        cmip_final_mean.lon, cmip_final_mean.lat, cmip_final_mean,
        levels=np.arange(0, 12, 1),
        cmap='Blues',
        extend='max'
    )
    ax3.coastlines(resolution='50m', linewidth=0.8)
    ax3.set_title('(c) QM+ConvLSTM Corrected', fontsize=12)
    plt.colorbar(im3, ax=ax3, orientation='vertical', label='Precipitation (mm/day)')

    # (d) ERA5 Observed Precipitation
    ax4 = fig.add_subplot(2, 2, 4, projection=ccrs.PlateCarree())
    ax4.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())
    im4 = ax4.contourf(
        obs_mean.lon, obs_mean.lat, obs_mean,
        levels=np.arange(0, 12, 1),
        cmap='Blues',
        extend='max'
    )
    ax4.coastlines(resolution='50m', linewidth=0.8)
    ax4.set_title('(d) ERA5 Observation', fontsize=12)
    plt.colorbar(im4, ax=ax4, orientation='vertical', label='Precipitation (mm/day)')

    # Adjust layout and display plot
    plt.tight_layout()
    plt.show()