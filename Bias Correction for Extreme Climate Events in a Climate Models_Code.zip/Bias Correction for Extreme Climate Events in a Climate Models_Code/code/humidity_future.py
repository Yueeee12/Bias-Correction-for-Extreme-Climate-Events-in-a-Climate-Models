# ======================================
# Imports & Environment
# ======================================
import numpy as np
import pandas as pd
import xarray as xr
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import mean_squared_error, mean_absolute_error
from scipy.interpolate import interp1d
from scipy.stats import pearsonr

# ======================================
# Set Seed
# ======================================
def set_seed(seed=42):
    torch.manual_seed(seed)
    np.random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
set_seed()

# ======================================
# Load Data
# ======================================
era5_ds = xr.open_dataset("ERA5_r.nc", chunks={'time': 10})
era5 = era5_ds['r'].sel(pressure_level=1000, method='nearest')
era5 = era5.where(era5 < 1e10)

future_ds = xr.open_dataset("hurs_Amon_CanESM5_ssp245_r1i1p1f1_gn_20150116-20491216.nc", chunks={'time': 10})
future = future_ds['hurs'].where(future_ds['hurs'] != 1e20)

# Define spatial domain
lat_min, lat_max = 25, 50
lon_min, lon_max = -125, -66
lon_min_conv, lon_max_conv = lon_min + 360, lon_max + 360

era5 = era5.sel(latitude=slice(lat_max, lat_min), longitude=slice(lon_min_conv, lon_max_conv))
era5 = era5.rename({'latitude':'lat','longitude':'lon'})
future = future.sel(lat=slice(lat_min, lat_max), lon=slice(lon_min_conv, lon_max_conv))

# Monthly mean over region
era5_mon = era5.mean(dim=["lat","lon"]).resample(valid_time="1MS").mean()
era5_mon = era5_mon.rename({'valid_time':'time'})
future_mon = future.mean(dim=["lat","lon"]).resample(time="1MS").mean()

# 选择训练与预测时间段
train_start, train_end = "2015", "2025"
obs = era5_mon.sel(time=slice(train_start, train_end)).values
sim_hist = future_mon.sel(time=slice(train_start, train_end)).values

future_target = future_mon.sel(time=slice(train_start, train_end)).values
future_dates = future_mon.sel(time=slice(train_start, train_end)).time.to_index()

# ======================================
# Quantile Mapping
# ======================================
def quantile_mapping(obs, sim, target):
    quantiles = np.linspace(0,1,1001)
    obs_q = np.quantile(obs, quantiles)
    sim_q = np.quantile(sim, quantiles)
    sim_q_unique, idx = np.unique(sim_q, return_index=True)
    obs_q_unique = obs_q[idx]
    qm_func = interp1d(sim_q_unique, obs_q_unique, bounds_error=False, fill_value="extrapolate")
    return qm_func(target)

sim_qm_future = quantile_mapping(obs, sim_hist, future_target)
residuals_future = sim_qm_future - future_target  # 先用QM残差

# ======================================
# Time Embedding
# ======================================
def add_time_embedding(length, start_year="2015-01"):
    dates = pd.date_range(start=start_year, periods=length, freq="MS")
    months = dates.month.values
    years = dates.year.values - dates.year.values.min()
    sin_month = np.sin(2 * np.pi * months / 12)
    cos_month = np.cos(2 * np.pi * months / 12)
    sin_year = np.sin(2 * np.pi * years / 10)
    cos_year = np.cos(2 * np.pi * years / 10)
    return np.stack([sin_month, cos_month, sin_year, cos_year], axis=1)

# ======================================
# Sequence Preparation
# ======================================
def create_sequences(data, input_len=120, pred_len=1):
    X, y = [], []
    for i in range(len(data) - input_len - pred_len + 1):
        X.append(data[i:i+input_len])
        y.append(data[i+input_len:i+input_len+pred_len])
    return np.array(X), np.array(y)

input_len = 120
X_np, y_np = create_sequences(residuals_future, input_len=input_len)

# Standardization
X_mean, X_std = X_np.mean(), X_np.std()
y_mean, y_std = y_np.mean(), y_np.std()
X_np = (X_np - X_mean) / X_std
y_np = (y_np - y_mean) / y_std

X_tensor = torch.tensor(X_np, dtype=torch.float32).unsqueeze(-1)
y_tensor = torch.tensor(y_np, dtype=torch.float32)
time_tensor = torch.tensor(add_time_embedding(len(X_tensor)), dtype=torch.float32)

dataset = TensorDataset(X_tensor, time_tensor, y_tensor)
loader = DataLoader(dataset, batch_size=16, shuffle=True)

# ======================================
# CNN-LSTM Model
# ======================================
class CNN_LSTM_Enhanced(nn.Module):
    def __init__(self, input_dim=1, cnn_channels=64, lstm_hidden=128, time_emb_dim=4, dropout=0.3):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv1d(input_dim, cnn_channels, kernel_size=3, padding=1),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Conv1d(cnn_channels, cnn_channels, kernel_size=3, padding=1),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.lstm = nn.LSTM(cnn_channels, lstm_hidden, batch_first=True)
        self.fc = nn.Sequential(
            nn.Linear(lstm_hidden + time_emb_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 1)
        )

    def forward(self, x, time_emb):
        x = x.permute(0, 2, 1)
        x = self.cnn(x).permute(0, 2, 1)
        _, (h_n, _) = self.lstm(x)
        h_last = h_n[-1]
        combined = torch.cat([h_last, time_emb], dim=1)
        return self.fc(combined).squeeze(1)

# ======================================
# Training
# ======================================
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = CNN_LSTM_Enhanced().to(device)
criterion = nn.MSELoss()
optimizer = optim.AdamW(model.parameters(), lr=1e-4)

for epoch in range(20):
    model.train()
    total_loss = 0
    for xb, tb, yb in loader:
        xb, tb, yb = xb.to(device), tb.to(device), yb.to(device)
        optimizer.zero_grad()
        preds = model(xb, tb)
        loss = criterion(preds, yb.squeeze(1))
        loss.backward()
        optimizer.step()
        total_loss += loss.item()
    print(f"Epoch {epoch+1}, Loss={total_loss/len(loader):.6f}")

# ======================================
# Inference for 2015-2025
# ======================================
model.eval()
with torch.no_grad():
    X_future_tensor = X_tensor.to(device)
    time_future_tensor = time_tensor.to(device)
    preds_future = model(X_future_tensor, time_future_tensor).cpu().numpy()
    preds_future = preds_future * y_std + y_mean

# Ensure the predicted residuals align with the target length
deep_residuals_future = np.concatenate([np.zeros(input_len), preds_future])[:len(future_target)]
sim_qm_deep_future = sim_qm_future[:len(future_target)] + deep_residuals_future

# ======================================
# Metrics Function
# ======================================
def print_metrics(obs, pred, name=""):
    if len(obs) == 0 or len(pred) == 0:
        print(f"{name:<10} No data to evaluate!")
        return
    rmse = np.sqrt(mean_squared_error(obs, pred))
    mae = mean_absolute_error(obs, pred)
    corr, _ = pearsonr(obs.flatten(), pred.flatten())
    print(f"{name:<10} RMSE: {rmse:.4f}, MAE: {mae:.4f}, Corr: {corr:.4f}")

# ======================================
# Mean Seasonal Cycle
# ======================================
def mean_seasonal_cycle(data, dates):
    """
    Calculate the mean seasonal cycle
    data : 1D array
    dates: pd.DatetimeIndex
    Returns the average for 12 months
    """
    df = pd.DataFrame({"data": data}, index=dates)
    return df.groupby(df.index.month).mean().values  # Average for months 1-12

# Use the time index from obs/future_target
era5_dates = era5_mon.sel(time=slice(train_start, train_end)).time.to_index()
future_dates = future_mon.sel(time=slice(train_start, train_end)).time.to_index()

# Generate seasonal cycles
era5_msc = mean_seasonal_cycle(obs, era5_dates)
cmip6_raw_msc = mean_seasonal_cycle(future_target, future_dates)
cmip6_qm_deep_msc = mean_seasonal_cycle(sim_qm_deep_future[:len(future_target)], future_dates)

# Plot
months = np.arange(1, 13)
plt.figure(figsize=(10,6))
plt.plot(months, cmip6_raw_msc, marker='s', label='CMIP6 Raw')
plt.plot(months, cmip6_qm_deep_msc, marker='^', label='CMIP6 QM+Deep')
plt.plot(months, era5_msc, marker='o', label='ERA5 (obs)')
plt.xticks(months)
plt.xlabel("Month")
plt.ylabel("Relative Humidity")
plt.title("Mean Seasonal Cycle (2015-2025) Relative Humidity")
plt.legend()
plt.grid(True)
plt.show()

# Align obs and simulation lengths (take minimum length)
min_len = min(len(obs), len(sim_hist), len(sim_qm_future), len(sim_qm_deep_future))
obs_aligned = obs[-min_len:]
sim_hist_aligned = sim_hist[-min_len:]
sim_qm_future_aligned = sim_qm_future[-min_len:]
sim_qm_deep_aligned = sim_qm_deep_future[:len(future_target)][-min_len:]

# ======================================
# Metrics Calculation
# ======================================
print_metrics(obs, sim_hist[:len(obs)], "CMIP6 Raw")
print_metrics(obs, sim_qm_future[:len(obs)], "CMIP6 QM")
print_metrics(obs, sim_qm_deep_future[:len(obs)], "CMIP6 QM+Deep")

# ======================================
# Relative Humidity Histogram
# ======================================
plt.figure(figsize=(12,5))

# Align data
obs = obs_aligned                 # ERA5
sim_raw = sim_hist_aligned        # CMIP6 Raw
sim_corrected = sim_qm_deep_aligned  # CMIP6 QM+Deep

# Plot histograms
plt.hist(sim_raw.flatten(), bins=50, alpha=0.5, label='CMIP6 Raw', density=True)
plt.hist(sim_corrected.flatten(), bins=50, alpha=0.5, label='CMIP6 QM+Deep', density=True)
plt.hist(obs.flatten(), bins=50, alpha=0.5, label='ERA5 (obs)', density=True)

plt.xlabel("Relative Humidity (%)")
plt.ylabel("Probability Density")
plt.title("Distribution of Monthly Relative Humidity (2015-2025)")
plt.legend()
plt.tight_layout()
plt.show()
