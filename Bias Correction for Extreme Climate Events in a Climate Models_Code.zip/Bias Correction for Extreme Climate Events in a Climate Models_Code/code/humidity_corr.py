# ======================================
# Imports & Environment
# ======================================
import numpy as np
import pandas as pd
import xarray as xr
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error
from scipy.interpolate import interp1d
from scipy.stats import pearsonr

# ======================================
# Set Seed
# ======================================
def set_seed(seed=42):
    torch.manual_seed(seed)
    np.random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
set_seed()

# ======================================
# Load RH Data
# ======================================
ERA5_rh = 'ERA5_r.nc'
CMIP6_hur = 'CMIP6_hurs.nc'

def load_rh_data():
    ds_cmip6 = xr.open_dataset(CMIP6_hur)
    ds_era5 = xr.open_dataset(ERA5_rh)

    cmip6 = ds_cmip6['hurs']
    era5 = ds_era5['r']

    print("Available ERA5 pressure levels:", era5.pressure_level.values)
    era5 = era5.sel(pressure_level=1000, method='nearest')

    cmip6 = cmip6.where(cmip6 != 1e20)
    era5 = era5.where(era5 < 1e10)

    cmip6 = cmip6.sel(time=slice("1950", "2014"))
    era5 = era5.sel(valid_time=slice("1950", "2014"))

    lat_min, lat_max = 25, 50
    lon_min, lon_max = -125, -66
    lon_min_conv, lon_max_conv = lon_min + 360, lon_max + 360

    cmip6 = cmip6.sel(lat=slice(lat_min, lat_max), lon=slice(lon_min_conv, lon_max_conv))
    era5 = era5.sel(latitude=slice(lat_max, lat_min), longitude=slice(lon_min_conv, lon_max_conv))
    era5 = era5.rename({'latitude': 'lat', 'longitude': 'lon'})

    cmip6_mon = cmip6.mean(dim=["lat", "lon"]).resample(time="1MS").mean()
    era5_mon = era5.mean(dim=["lat", "lon"]).resample(valid_time="1MS").mean()
    era5_mon = era5_mon.rename({'valid_time': 'time'})

    return cmip6_mon.values, era5_mon.values, pd.date_range("1950-01", periods=len(cmip6_mon), freq="MS")

sim, obs, dates = load_rh_data()

# ======================================
# Quantile Mapping
# ======================================
def quantile_mapping(obs, sim, target):
    quantiles = np.linspace(0, 1, 1001)
    obs_q = np.quantile(obs, quantiles)
    sim_q = np.quantile(sim, quantiles)
    sim_q_unique, idx = np.unique(sim_q, return_index=True)
    obs_q_unique = obs_q[idx]
    qm_func = interp1d(sim_q_unique, obs_q_unique, bounds_error=False, fill_value="extrapolate")
    return qm_func(target)

sim_qm = quantile_mapping(obs, sim, sim)
residuals = obs - sim_qm

# ======================================
# Time Embedding
# ======================================
def add_time_embedding(length, start_year="1950-01"):
    dates = pd.date_range(start=start_year, periods=length, freq="MS")
    months = dates.month.values
    years = dates.year.values - dates.year.values.min()
    sin_month = np.sin(2 * np.pi * months / 12)
    cos_month = np.cos(2 * np.pi * months / 12)
    sin_year = np.sin(2 * np.pi * years / 10)
    cos_year = np.cos(2 * np.pi * years / 10)
    return np.stack([sin_month, cos_month, sin_year, cos_year], axis=1)

# ======================================
# Sequence Preparation
# ======================================
def create_sequences(data, input_len=120, pred_len=1):
    X, y = [], []
    for i in range(len(data) - input_len - pred_len + 1):
        X.append(data[i:i+input_len])
        y.append(data[i+input_len:i+input_len+pred_len])
    return np.array(X), np.array(y)

input_len = 120
X_np, y_np = create_sequences(residuals, input_len=input_len)

# Split train/val before standardization
X_train_np, X_val_np, y_train_np, y_val_np = train_test_split(X_np, y_np, test_size=0.2, random_state=42)

# Standardization
X_mean, X_std = X_train_np.mean(), X_train_np.std()
y_mean, y_std = y_train_np.mean(), y_train_np.std()
X_train_np = (X_train_np - X_mean) / X_std
X_val_np = (X_val_np - X_mean) / X_std
y_train_np = (y_train_np - y_mean) / y_std
y_val_np = (y_val_np - y_mean) / y_std

# Convert to tensors
X_train_tensor = torch.tensor(X_train_np, dtype=torch.float32).unsqueeze(-1)
y_train_tensor = torch.tensor(y_train_np, dtype=torch.float32)
X_val_tensor = torch.tensor(X_val_np, dtype=torch.float32).unsqueeze(-1)
y_val_tensor = torch.tensor(y_val_np, dtype=torch.float32)

# Time embeddings aligned with sequences
X_time_train = torch.tensor(add_time_embedding(len(X_train_tensor)), dtype=torch.float32)
X_time_val = torch.tensor(add_time_embedding(len(X_val_tensor), start_year=f"1950-{input_len//12 + 1}"), dtype=torch.float32)

train_loader = DataLoader(TensorDataset(X_train_tensor, X_time_train, y_train_tensor), batch_size=64, shuffle=True)
val_loader = DataLoader(TensorDataset(X_val_tensor, X_time_val, y_val_tensor), batch_size=64)

# ======================================
# CNN-LSTM Model
# ======================================
class CNN_LSTM_Enhanced(nn.Module):
    def __init__(self, input_dim=1, cnn_channels=64, lstm_hidden=128, time_emb_dim=4, dropout=0.3):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv1d(input_dim, cnn_channels, kernel_size=3, padding=1),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Conv1d(cnn_channels, cnn_channels, kernel_size=3, padding=1),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.lstm = nn.LSTM(cnn_channels, lstm_hidden, batch_first=True)
        self.fc = nn.Sequential(
            nn.Linear(lstm_hidden + time_emb_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 1)
        )

    def forward(self, x, time_emb):
        x = x.permute(0, 2, 1)
        x = self.cnn(x).permute(0, 2, 1)
        _, (h_n, _) = self.lstm(x)
        h_last = h_n[-1]
        combined = torch.cat([h_last, time_emb], dim=1)
        return self.fc(combined).squeeze(1)

# ======================================
# Training Loop
# ======================================
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

model = CNN_LSTM_Enhanced().to(device)
criterion = nn.MSELoss()
optimizer = optim.AdamW(model.parameters(), lr=1e-4)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', patience=15)

def correlation_loss(pred, target):
    vx = pred - torch.mean(pred)
    vy = target - torch.mean(target)
    corr = torch.sum(vx * vy) / (torch.sqrt(torch.sum(vx**2)) * torch.sqrt(torch.sum(vy**2)) + 1e-8)
    return 1 - corr

best_val_loss = float('inf')
wait, patience = 0, 15

for epoch in range(1, 101):
    model.train()
    train_loss = 0
    for xb, tb, yb in train_loader:
        xb, tb, yb = xb.to(device), tb.to(device), yb.to(device)
        optimizer.zero_grad()
        preds = model(xb, tb)
        loss = criterion(preds, yb.squeeze(1)) + 0.3 * correlation_loss(preds, yb.squeeze(1))
        loss.backward()
        optimizer.step()
        train_loss += loss.item()

    model.eval()
    val_loss = 0
    val_preds, val_targets = [], []
    with torch.no_grad():
        for xb, tb, yb in val_loader:
            xb, tb, yb = xb.to(device), tb.to(device), yb.to(device)
            preds = model(xb, tb)
            loss = criterion(preds, yb.squeeze(1)) + 0.3 * correlation_loss(preds, yb.squeeze(1))
            val_loss += loss.item()
            val_preds.append(preds.cpu().numpy())
            val_targets.append(yb.cpu().numpy())

    val_preds = np.concatenate(val_preds)
    val_targets = np.concatenate(val_targets)
    corr, _ = pearsonr(val_preds.flatten(), val_targets.flatten())

    print(f"Epoch {epoch:03d} | Train Loss: {train_loss/len(train_loader):.6f} | "
          f"Val Loss: {val_loss/len(val_loader):.6f} | Val Corr: {corr:.4f}")

    scheduler.step(val_loss/len(val_loader))
    if val_loss < best_val_loss:
        best_val_loss = val_loss
        wait = 0
        torch.save(model.state_dict(), "cnn_lstm_rh.pth")
    else:
        wait += 1
        if wait >= patience:
            print("Early stopping.")
            break

# ======================================
# Inference & Evaluation
# ======================================
X_pred, _ = create_sequences(residuals, input_len=input_len, pred_len=1)
X_pred = (X_pred - X_mean) / X_std
X_pred_tensor = torch.tensor(X_pred, dtype=torch.float32).unsqueeze(-1).to(device)
X_time_pred = torch.tensor(add_time_embedding(len(X_pred)), dtype=torch.float32).to(device)

model.eval()
with torch.no_grad():
    preds = model(X_pred_tensor, X_time_pred).cpu().numpy()
    preds = preds * y_std + y_mean

deep_residuals = np.concatenate([np.zeros(input_len), preds])[:len(obs)]
sim_qm_deep = sim_qm + deep_residuals

# ======================================
# Average Seasonal Cycle
# ======================================
sim_cycle = pd.Series(sim[:len(dates)], index=dates).groupby(dates.month).mean()
sim_qm_deep_cycle = pd.Series(sim_qm_deep[:len(dates)], index=dates).groupby(dates.month).mean()
obs_cycle = pd.Series(obs[:len(dates)], index=dates).groupby(dates.month).mean()

# ======================================
# Plotting
# ======================================
months = np.arange(1, 13)
plt.figure(figsize=(10, 5))
plt.plot(months, sim_cycle, label='CMIP6 Raw', marker='o', alpha=0.6)
plt.plot(months, sim_qm_deep_cycle, label='QM + CNN-LSTM', marker='s', alpha=0.8)
plt.plot(months, obs_cycle, label='ERA5 Observed', marker='^', linewidth=1.5)
plt.xlabel("Month")
plt.ylabel("Relative Humidity (%)")
plt.title("Average Seasonal Cycle of Relative Humidity (1950-2014)")
plt.xticks(months)
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

def print_metrics(obs, pred, name=""):
    rmse = np.sqrt(mean_squared_error(obs, pred))
    mae = mean_absolute_error(obs, pred)
    corr, _ = pearsonr(obs, pred)
    print(f"{name} RMSE: {rmse:.4f}, MAE: {mae:.4f}, Corr: {corr:.4f}")

print("\n===== RH Evaluation =====")
print_metrics(obs, sim, "Raw")
print_metrics(obs, sim_qm, "QM")
print_metrics(obs, sim_qm_deep, "QM+Deep")

plt.figure(figsize=(12, 5))
n = len(obs)
plt.hist(sim[:n], bins=50, alpha=0.5, label='Raw CMIP6')
plt.hist(sim_qm_deep[:n], bins=50, alpha=0.5, label='QM+CNN-LSTM Corrected')
plt.hist(obs[:n], bins=50, alpha=0.5, label='ERA5')
plt.xlabel('Relative Humidity (%)')
plt.ylabel('Frequency')
plt.title("RH Distribution")
plt.legend()
plt.tight_layout()
plt.show()

# ======================================
# Simple Scatter Plot: Simulated vs Observed
# ======================================

# Ensure variable names correspond
sim_raw = sim  # Original simulation
sim_corrected = sim_qm_deep  # Corrected with QM + CNN-LSTM

plt.figure(figsize=(6, 6))
plt.scatter(obs, sim_raw, alpha=0.3, label='Raw')
plt.scatter(obs, sim_qm, alpha=0.3, label='QM')
plt.scatter(obs, sim_corrected, alpha=0.3, label='QM+CNN-LSTM')
plt.plot([obs.min(), obs.max()], [obs.min(), obs.max()], 'k--', lw=2)
plt.xlabel('Observed')
plt.ylabel('Simulated')
plt.legend()
plt.title('Scatter Relative Humidity Plot of Simulated vs Observed')
plt.tight_layout()
plt.show()
