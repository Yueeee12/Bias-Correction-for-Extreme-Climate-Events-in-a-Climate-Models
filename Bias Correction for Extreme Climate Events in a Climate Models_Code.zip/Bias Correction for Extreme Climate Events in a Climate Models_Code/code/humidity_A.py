import xarray as xr
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER

# ----------------------------
# Step 1: Load Data
# ----------------------------
# Load relative humidity datasets
ds_cmip6 = xr.open_dataset('CMIP6_hurs.nc')
ds_era5 = xr.open_dataset('ERA5_r.nc', chunks={"time": 10})  # Chunking improves efficiency

# Extract variables and standardize coordinate names
cmip6 = ds_cmip6['hurs']  # CMIP6 relative humidity variable (unit: %)
era5 = ds_era5['r'].squeeze().rename({  # ERA5 relative humidity variable (unit: %)
    'latitude': 'lat',
    'longitude': 'lon',
    'valid_time': 'time'
})

# Print time ranges
print("CMIP6 original time range:", cmip6.time.min().values, "to", cmip6.time.max().values)
print("ERA5 original time range:", era5.time.min().values, "to", era5.time.max().values)

# ----------------------------
# Step 2: Data Preprocessing
# ----------------------------
# No unit conversion needed (both are in %)

# Handle missing values (adjust thresholds according to dataset documentation)
cmip6 = cmip6.where(cmip6 >= 0)    # Relative humidity cannot be negative
cmip6 = cmip6.where(cmip6 <= 100)  # Relative humidity cannot exceed 100%
era5 = era5.where(era5 >= 0)
era5 = era5.where(era5 <= 100)

# ----------------------------
# Step 3: Temporal and Spatial Subsetting (1950-2014)
# ----------------------------
lat_min, lat_max = 25, 50
lon_min, lon_max = -125, -66
lon_min_conv, lon_max_conv = lon_min + 360, lon_max + 360  # Convert west longitude to east (0–360 range)

# Crop CMIP6 data
cmip6_crop = cmip6.sel(
    time=slice("1950", "2014"),
    lat=slice(lat_min, lat_max),
    lon=slice(lon_min_conv, lon_max_conv)
)

# Crop ERA5 data (note: ERA5 latitude may be in descending order)
era5_crop = era5.sel(
    time=slice("1950", "2014"),
    lat=slice(lat_max, lat_min),  # Reverse latitude order to match CMIP6
    lon=slice(lon_min_conv, lon_max_conv)
)

# ----------------------------
# Step 4: Temporal Alignment - Align by year-month (key step)
# ----------------------------
# Add year-month identifiers (e.g., "1950-01")
cmip6_crop = cmip6_crop.assign_coords(
    year_month=cmip6_crop.time.dt.strftime('%Y-%m')
)
era5_crop = era5_crop.assign_coords(
    year_month=era5_crop.time.dt.strftime('%Y-%m')
)

# Find common year-months
common_years_months = np.intersect1d(
    cmip6_crop.year_month.values,
    era5_crop.year_month.values
)
print(f"\nNumber of common year-months: {len(common_years_months)}")

# Select data based on common year-months
cmip6_aligned = cmip6_crop.sel(
    time=[t for t, ym in zip(cmip6_crop.time.values, cmip6_crop.year_month.values)
          if ym in common_years_months]
)
era5_aligned = era5_crop.sel(
    time=[t for t, ym in zip(era5_crop.time.values, era5_crop.year_month.values)
          if ym in common_years_months]
)

# ----------------------------
# Step 5: Spatial Alignment - Fix dimension mismatch
# ----------------------------
# Print original grid info
print(f"\nCMIP6 grid: {len(cmip6_aligned.lat)} latitude points, {len(cmip6_aligned.lon)} longitude points")
print(f"ERA5 grid: {len(era5_aligned.lat)} latitude points, {len(era5_aligned.lon)} longitude points")

# Select the higher-resolution grid as the target grid
if len(cmip6_aligned.lat) > len(era5_aligned.lat):
    target_lat = cmip6_aligned.lat
    target_lon = cmip6_aligned.lon
    # Interpolate ERA5 to CMIP6 grid
    era5_aligned = era5_aligned.interp(lat=target_lat, lon=target_lon, method='linear')
else:
    target_lat = era5_aligned.lat
    target_lon = era5_aligned.lon
    # Interpolate CMIP6 to ERA5 grid
    cmip6_aligned = cmip6_aligned.interp(lat=target_lat, lon=target_lon, method='linear')

print(f"Aligned grid: {len(target_lat)} latitude points, {len(target_lon)} longitude points")

# ----------------------------
# Step 6: Bias Correction
# ----------------------------
# Compute time-mean bias (CMIP6 - ERA5)
bias = cmip6_aligned.mean(dim='time') - era5_aligned.mean(dim='time')

# Apply bias correction
cmip6_corrected = cmip6_aligned - bias

# Compute time-mean fields for plotting
cmip6_mean = cmip6_aligned.mean(dim='time')
cmip6_corrected_mean = cmip6_corrected.mean(dim='time')
era5_mean = era5_aligned.mean(dim='time')

# ----------------------------
# Step 7: Plot Spatial Distributions
# ----------------------------
plot_extent = [lon_min, lon_max, lat_min, lat_max]  # Convert back to west longitude for display

fig = plt.figure(figsize=(16, 14))

# 1. Original CMIP6 mean relative humidity
ax1 = fig.add_subplot(2, 2, 1, projection=ccrs.PlateCarree())
ax1.set_extent(plot_extent, crs=ccrs.PlateCarree())
im1 = ax1.contourf(
    cmip6_mean.lon - 360,
    cmip6_mean.lat,
    cmip6_mean,
    levels=np.linspace(0, 100, 11),
    cmap='YlGnBu',
    extend='max'
)
ax1.coastlines(resolution='50m', linewidth=0.8)
ax1.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax1.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False
gl.right_labels = False
gl.xformatter = LONGITUDE_FORMATTER
gl.yformatter = LATITUDE_FORMATTER
ax1.set_title('(a) Original CMIP6 Mean Relative Humidity (%)', fontsize=12)
plt.colorbar(im1, ax=ax1, orientation='vertical', label='Relative Humidity (%)')

# 2. ERA5 observed mean relative humidity
ax2 = fig.add_subplot(2, 2, 2, projection=ccrs.PlateCarree())
ax2.set_extent(plot_extent, crs=ccrs.PlateCarree())
im2 = ax2.contourf(
    era5_mean.lon - 360,
    era5_mean.lat,
    era5_mean,
    levels=np.linspace(0, 100, 11),
    cmap='YlGnBu',
    extend='max'
)
ax2.coastlines(resolution='50m', linewidth=0.8)
ax2.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax2.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False
gl.right_labels = False
gl.xformatter = LONGITUDE_FORMATTER
gl.yformatter = LATITUDE_FORMATTER
ax2.set_title('(b) ERA5 Observed Mean Relative Humidity (%)', fontsize=12)
plt.colorbar(im2, ax=ax2, orientation='vertical', label='Relative Humidity (%)')

# 3. Bias distribution
ax3 = fig.add_subplot(2, 2, 3, projection=ccrs.PlateCarree())
ax3.set_extent(plot_extent, crs=ccrs.PlateCarree())
bias_min = np.nanmin(bias.values)
bias_max = np.nanmax(bias.values)
bias_levels = np.linspace(np.floor(bias_min), np.ceil(bias_max), 11)
im3 = ax3.contourf(
    bias.lon - 360,
    bias.lat,
    bias,
    levels=bias_levels,
    cmap='RdBu_r',
    extend='both'
)
ax3.coastlines(resolution='50m', linewidth=0.8)
ax3.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax3.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False
gl.right_labels = False
gl.xformatter = LONGITUDE_FORMATTER
gl.yformatter = LATITUDE_FORMATTER
ax3.set_title('(c) CMIP6 Bias (CMIP6 - ERA5) (%)', fontsize=12)
plt.colorbar(im3, ax=ax3, orientation='vertical', label='Bias (%)')

# 4. Bias-corrected CMIP6 mean relative humidity
ax4 = fig.add_subplot(2, 2, 4, projection=ccrs.PlateCarree())
ax4.set_extent(plot_extent, crs=ccrs.PlateCarree())
im4 = ax4.contourf(
    cmip6_corrected_mean.lon - 360,
    cmip6_corrected_mean.lat,
    cmip6_corrected_mean,
    levels=np.linspace(0, 100, 11),
    cmap='YlGnBu',
    extend='max'
)
ax4.coastlines(resolution='50m', linewidth=0.8)
ax4.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax4.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False
gl.right_labels = False
gl.xformatter = LONGITUDE_FORMATTER
gl.yformatter = LATITUDE_FORMATTER
ax4.set_title('(d) Bias-Corrected CMIP6 Mean Relative Humidity (%)', fontsize=12)
plt.colorbar(im4, ax=ax4, orientation='vertical', label='Relative Humidity (%)')

plt.tight_layout()
plt.savefig('cmip6_humidity_bias_correction_1950-2014_colorbars.png', dpi=300, bbox_inches='tight')
plt.show()
