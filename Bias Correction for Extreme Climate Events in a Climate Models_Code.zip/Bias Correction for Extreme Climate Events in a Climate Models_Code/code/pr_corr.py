import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER

# ----------------------------
# Step 1: Load Data
# ----------------------------
cmip6 = xr.open_dataset("CMIP6_pr.nc")
era5 = xr.open_dataset("ERA5_tp.nc", chunks={"time": 10})

# Print time ranges
print("CMIP6 original time range:", cmip6.time.min().values, "to", cmip6.time.max().values)
print("ERA5 original time range:", era5.valid_time.min().values, "to", era5.valid_time.max().values)

# ----------------------------
# Step 2: Data Preprocessing
# ----------------------------
# Unit conversion
cmip6_daily = cmip6['pr'] * 86400  # Convert kg/m²/s to mm/day
era5_daily = era5['tp'] * 1000  # Convert m to mm

# Standardize coordinate names
era5_daily = era5_daily.rename({
    'latitude': 'lat',
    'longitude': 'lon',
    'valid_time': 'time'
})

# Handle missing values
cmip6_daily = cmip6_daily.where(cmip6_daily != 1e20)
era5_daily = era5_daily.where(era5_daily < 1e10)

# ----------------------------
# Step 3: Temporal and Spatial Subsetting (1950-2014)
# ----------------------------
lat_min, lat_max = 25, 50
lon_min, lon_max = -125, -66
lon_min_conv, lon_max_conv = lon_min + 360, lon_max + 360  # Longitude conversion

# Subset CMIP6 data
cmip6_crop = cmip6_daily.sel(
    time=slice("1950", "2014"),
    lat=slice(lat_min, lat_max),
    lon=slice(lon_min_conv, lon_max_conv)
)

# Subset ERA5 data
era5_crop = era5_daily.sel(
    time=slice("1950", "2014"),
    lat=slice(lat_max, lat_min),  # ERA5 latitude may be in descending order
    lon=slice(lon_min_conv, lon_max_conv)
)


# ----------------------------
# Step 4: Temporal Alignment - Fix time format issues
# ----------------------------
def convert_time_to_str(ds):
    """Convert time values to string format for comparison"""
    return [str(t)[:10] for t in ds.time.values]


# Convert times to strings
cmip6_times_str = convert_time_to_str(cmip6_crop)
era5_times_str = convert_time_to_str(era5_crop)

# Find common time points
common_times_str = np.intersect1d(cmip6_times_str, era5_times_str)

# Subset data using common times
cmip6_aligned = cmip6_crop.sel(
    time=[t for t, s in zip(cmip6_crop.time.values, cmip6_times_str) if s in common_times_str]
)
era5_aligned = era5_crop.sel(
    time=[t for t, s in zip(era5_crop.time.values, era5_times_str) if s in common_times_str]
)

# ----------------------------
# Step 5: Spatial Alignment - Fix dimension mismatch
# ----------------------------
# Print original grid information
print(f"CMIP6 grid: {len(cmip6_aligned.lat)} latitude points, {len(cmip6_aligned.lon)} longitude points")
print(f"ERA5 grid: {len(era5_aligned.lat)} latitude points, {len(era5_aligned.lon)} longitude points")

# Choose higher resolution grid as target
if len(cmip6_aligned.lat) > len(era5_aligned.lat):
    target_lat = cmip6_aligned.lat
    target_lon = cmip6_aligned.lon
    # Interpolate ERA5 to CMIP6 grid
    era5_aligned = era5_aligned.interp(lat=target_lat, lon=target_lon, method='linear')
else:
    target_lat = era5_aligned.lat
    target_lon = era5_aligned.lon
    # Interpolate CMIP6 to ERA5 grid
    cmip6_aligned = cmip6_aligned.interp(lat=target_lat, lon=target_lon, method='linear')

print(f"Aligned grid: {len(target_lat)} latitude points, {len(target_lon)} longitude points")

# ----------------------------
# Step 6: Bias Correction
# ----------------------------
# Calculate temporal mean bias (CMIP6 - ERA5)
bias = cmip6_aligned.mean(dim='time') - era5_aligned.mean(dim='time')

# Apply bias correction
cmip6_corrected = cmip6_aligned - bias

# Calculate temporal means for plotting
cmip6_mean = cmip6_aligned.mean(dim='time')
cmip6_corrected_mean = cmip6_corrected.mean(dim='time')
era5_mean = era5_aligned.mean(dim='time')

import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER
import numpy as np

# ========================================
# Step 7: Plot Spatial Distribution of Precipitation (with Independent Colorbars and Lat/Lon Grids)
# ========================================
plot_extent = [lon_min, lon_max, lat_min, lat_max]  # Geographic extent for plotting (defined earlier)

fig = plt.figure(figsize=(26, 14))  # Increase figure width to reserve space for colorbars

# Create a 2x2 grid of subplots
axes = []
for i in range(4):
    ax = fig.add_subplot(2, 2, i + 1, projection=ccrs.PlateCarree())  # Use PlateCarree projection
    ax.set_extent(plot_extent, crs=ccrs.PlateCarree())  # Set consistent geographic extent

    # Add latitude/longitude grid lines
    gl = ax.gridlines(
        draw_labels=True,        # Show grid line labels
        linewidth=0.5,           # Grid line width
        color='gray',            # Grid line color
        linestyle='--'           # Dashed grid lines
    )
    gl.top_labels = False       # Hide labels on the top edge
    gl.right_labels = False     # Hide labels on the right edge
    gl.xformatter = LONGITUDE_FORMATTER  # Format longitude labels (e.g., 120°W)
    gl.yformatter = LATITUDE_FORMATTER   # Format latitude labels (e.g., 40°N)

    axes.append(ax)  # Store subplot axes in a list for later use

# -----------------------------
# 1. Original CMIP6 Mean Precipitation
# -----------------------------
im1 = axes[0].contourf(
    cmip6_mean.lon,             # Longitude coordinates
    cmip6_mean.lat,             # Latitude coordinates
    cmip6_mean,                 # Mean precipitation data
    levels=np.arange(0, 12, 1), # Contour levels (0 to 11 mm/day, 1 mm/day interval)
    cmap='Blues',               # Color map for precipitation (blues = wetter)
    extend='max'                # Extend colorbar for values exceeding max level
)
axes[0].coastlines(resolution='50m', linewidth=0.8)  # Add high-res coastlines
axes[0].add_feature(cfeature.BORDERS, linewidth=0.6)  # Add country borders
axes[0].set_title('(a) Original CMIP6 Mean Precipitation (mm/day)', fontsize=12)  # Subplot title

# -----------------------------
# 2. ERA5 Observed Mean Precipitation
# -----------------------------
im2 = axes[1].contourf(
    era5_mean.lon,
    era5_mean.lat,
    era5_mean,
    levels=np.arange(0, 12, 1),
    cmap='Blues',
    extend='max'
)
axes[1].coastlines(resolution='50m', linewidth=0.8)
axes[1].add_feature(cfeature.BORDERS, linewidth=0.6)
axes[1].set_title('(b) ERA5 Observed Mean Precipitation (mm/day)', fontsize=12)

# -----------------------------
# 3. Bias Distribution (CMIP6 - ERA5)
# -----------------------------
im3 = axes[2].contourf(
    bias.lon,
    bias.lat,
    bias,
    levels=np.arange(-6, 7, 1),  # Contour levels (-6 to 6 mm/day, 1 mm/day interval)
    cmap='RdBu_r',               # Diverging color map (red = positive bias, blue = negative bias)
    extend='both'                # Extend colorbar for values above max and below min levels
)
axes[2].coastlines(resolution='50m', linewidth=0.8)
axes[2].add_feature(cfeature.BORDERS, linewidth=0.6)
axes[2].set_title('(c) CMIP6 Bias (CMIP6 - ERA5) (mm/day)', fontsize=12)

# -----------------------------
# 4. Bias-Corrected CMIP6 Mean Precipitation
# -----------------------------
im4 = axes[3].contourf(
    cmip6_corrected_mean.lon,
    cmip6_corrected_mean.lat,
    cmip6_corrected_mean,
    levels=np.arange(0, 12, 1),
    cmap='Blues',
    extend='max'
)
axes[3].coastlines(resolution='50m', linewidth=0.8)
axes[3].add_feature(cfeature.BORDERS, linewidth=0.6)
axes[3].set_title('(d) Bias-Corrected CMIP6 Mean Precipitation (mm/day)', fontsize=12)

# -----------------------------
# Add Independent Colorbars
# -----------------------------
# Define colorbar positions (format: [left, bottom, width, height] in figure coordinates)
cbar_positions = [
    [0.43, 0.55, 0.015, 0.35],  # Colorbar for (a) Original CMIP6 (left side of top-left subplot)
    [0.93, 0.55, 0.015, 0.35],  # Colorbar for (b) ERA5 (right side of top-right subplot)
    [0.43, 0.1, 0.015, 0.35],   # Colorbar for (c) Bias (left side of bottom-left subplot)
    [0.93, 0.1, 0.015, 0.35]    # Colorbar for (d) Corrected CMIP6 (right side of bottom-right subplot)
]

# Create and configure each colorbar
for im, pos, label in zip(
    [im1, im2, im3, im4],  # Contour plot objects
    cbar_positions,         # Predefined colorbar positions
    [
        'Precipitation (mm/day)',  # Label for precipitation colorbars
        'Precipitation (mm/day)',
        'Bias (mm/day)',           # Label for bias colorbar
        'Precipitation (mm/day)'
    ]
):
    cbar_ax = fig.add_axes(pos)  # Create a dedicated axis for the colorbar
    fig.colorbar(im, cax=cbar_ax, label=label)  # Link colorbar to contour plot and add label

# Adjust overall layout to reserve space for right-side colorbars
plt.tight_layout(rect=[0, 0, 0.92, 1])  # Rect: [left, bottom, right, top] (shrink right margin to 0.92)

# Save plot with high resolution and tight bounding box (avoids label cutoff)
plt.savefig(
    'cmip6_bias_correction_1950-2014_precipitation_with_latlon.png',
    dpi=300,                  # 300 DPI for publication-quality resolution
    bbox_inches='tight'       # Crop extra whitespace around the figure
)
plt.show()  # Display the plot