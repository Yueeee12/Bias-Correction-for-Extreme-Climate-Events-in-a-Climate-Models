import numpy as np
import pandas as pd
import xarray as xr
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d

# --- Time helper functions ---
def detect_time_dim(da: xr.DataArray) -> str:
    if "time" in da.dims:
        return "time"
    if "valid_time" in da.dims:
        return "valid_time"
    for d in da.dims:
        if "time" in d:
            return d
    raise ValueError(f"Time dimension not found in dims={da.dims}")

def to_datetime_index(da: xr.DataArray, dim: str) -> pd.DatetimeIndex:
    try:
        idx = da.indexes[dim]
        return pd.DatetimeIndex(idx.to_datetimeindex())
    except Exception:
        try:
            cal = getattr(da[dim].dt, "calendar", None)
            da2 = da.convert_calendar("standard", use_cftime=False, dim=dim)
            return pd.to_datetime(da2[dim].values)
        except Exception:
            raise RuntimeError("Cannot convert time to datetime index.")

# --- Monthly Quantile Mapping (QM) ---
def seasonal_qm_fit_apply(obs_vals, obs_dates, sim_vals, sim_dates, target_vals, target_dates, n_q=1001):
    out = np.empty_like(target_vals, dtype=float)
    for m in range(1, 13):
        o = np.asarray(obs_vals[obs_dates.month == m], float)
        s = np.asarray(sim_vals[sim_dates.month == m], float)
        t = np.asarray(target_vals[target_dates.month == m], float)
        q = np.linspace(0, 1, n_q)
        o_q = np.quantile(o, q)
        s_q = np.quantile(s, q)
        s_q_u, idx = np.unique(s_q, return_index=True)
        o_q_u = o_q[idx]
        f = interp1d(s_q_u, o_q_u, bounds_error=False, fill_value=(o_q_u[0], o_q_u[-1]))
        out[target_dates.month == m] = f(t)
    return out

# --- Sequence generation function ---
def make_sequences(arr, L=60):
    arr = np.asarray(arr, float)
    return np.array([arr[i:i+L] for i in range(len(arr)-L)])

# --- CNN + LSTM model ---
class CNNLSTM(nn.Module):
    def __init__(self, input_len):
        super().__init__()
        self.conv1 = nn.Conv1d(1, 16, kernel_size=3, padding=1)
        self.relu = nn.ReLU()
        self.lstm = nn.LSTM(16, 32, batch_first=True)
        self.fc = nn.Linear(32, 1)
        self.input_len = input_len
    def forward(self, x):
        x = self.relu(self.conv1(x))     # [B,16,L]
        x = x.permute(0, 2, 1)           # [B,L,16]
        x, _ = self.lstm(x)              # [B,L,32]
        y = self.fc(x[:, -1, :])         # [B,1]
        return y.squeeze(1)

# ========== Load data ==========
# Future CMIP6 max temperature, usually in Kelvin (K)
ds_tasmax = xr.open_dataset("tasmax_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc", chunks={'time': 10})
future = ds_tasmax['tasmax']  # Adjust variable name if needed

# ERA5 max temperature, usually in Celsius or K*100; assume K here
era5_ds = xr.open_dataset("mx2t_1.nc", chunks={'time': 10})
era5 = era5_ds['mx2t']  # Replace if variable name differs
print("CMIP6 time range:", future.time.min().values, "to", future.time.max().values)
print("ERA5 time range:", era5.valid_time.min().values, "to", era5.valid_time.max().values)

# ========== Time and spatial handling ==========
# Rename lat/lon coordinates
if "latitude" in era5.coords:
    era5 = era5.rename({"latitude": "lat", "longitude": "lon"})
if "latitude" in future.coords:
    future = future.rename({"latitude": "lat", "longitude": "lon"})

# Convert time index
time_dim_era5 = detect_time_dim(era5)
time_dim_future = detect_time_dim(future)
dates_era5 = to_datetime_index(era5, time_dim_era5)
dates_future = to_datetime_index(future, time_dim_future)

# Clip region (example: North America)
lat_min, lat_max = 25, 50
lon_min, lon_max = -125, -66
lon_min_c, lon_max_c = lon_min + 360, lon_max + 360  # CMIP6 usually 0-360

era5 = era5.sel(lat=slice(lat_max, lat_min), lon=slice(lon_min_c, lon_max_c))
future = future.sel(lat=slice(lat_min, lat_max), lon=slice(lon_min_c, lon_max_c))

# Select time period: ERA5 2015-2025, future CMIP6 2015-2049
era5_sel = era5.sel({time_dim_era5: slice("2015-01", "2025-12")})
future_sel = future.sel({time_dim_future: slice("2015-01", "2049-12")})

# Spatial average
era5_mon = era5_sel.mean(dim=["lat", "lon"]).resample({time_dim_era5: "1MS"}).mean()
future_mon = future_sel.mean(dim=["lat", "lon"]).resample({time_dim_future: "1MS"}).mean()

# Adjust units if needed
# era5_mon += 273.15  # Uncomment if ERA5 is in Celsius

obs_vals = era5_mon.values
target_vals = future_mon.values
dates_obs = to_datetime_index(era5_mon, time_dim_era5)
dates_target = to_datetime_index(future_mon, time_dim_future)

# Use 2015-2025 for QM training
future_mon_1525 = future_mon.sel({time_dim_future: slice("2015-01", "2025-12")})
sim_vals = future_mon_1525.values
sim_dates = to_datetime_index(future_mon_1525, time_dim_future)

# ========== Monthly QM ==========
qm_future_all = seasonal_qm_fit_apply(
    obs_vals=obs_vals, obs_dates=dates_obs,
    sim_vals=sim_vals, sim_dates=sim_dates,
    target_vals=target_vals, target_dates=dates_target,
    n_q=1001
)

# ========== CNN-LSTM residual training ==========
mask_overlap = (dates_target >= dates_obs.min()) & (dates_target <= dates_obs.max())
qm_overlap = qm_future_all[mask_overlap]
dates_overlap = dates_target[mask_overlap]

# Align overlapping period
df_obs = pd.DataFrame({"date": dates_obs, "obs": obs_vals}).set_index("date")
df_qm = pd.DataFrame({"date": dates_overlap, "qm": qm_overlap}).set_index("date")
joined = df_obs.join(df_qm, how="inner")
obs_tr = joined["obs"].values
qm_tr = joined["qm"].values
residuals_train = obs_tr - qm_tr

input_len = 60
X_np = make_sequences(qm_tr, L=input_len)
y_np = residuals_train[input_len:]

# Standardization
x_mean, x_std = X_np.mean(), X_np.std() + 1e-8
Xn = (X_np - x_mean) / x_std
y_mean, y_std = y_np.mean(), y_np.std() + 1e-8
yn = (y_np - y_mean) / y_std

X_tensor = torch.tensor(Xn, dtype=torch.float32).unsqueeze(1)
y_tensor = torch.tensor(yn, dtype=torch.float32)

# Train/validation split
n = len(X_tensor)
ntr = max(int(0.8 * n), 1)
X_tr, X_va = X_tensor[:ntr], X_tensor[ntr:]
y_tr, y_va = y_tensor[:ntr], y_tensor[ntr:]

train_loader = DataLoader(TensorDataset(X_tr, y_tr), batch_size=64, shuffle=True)
val_loader = DataLoader(TensorDataset(X_va, y_va), batch_size=64) if len(X_va) > 0 else None

model = CNNLSTM(input_len=input_len)
optimizer = optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-5)
criterion = nn.MSELoss()

best_val, patience, max_patience = np.inf, 0, 30
for ep in range(300):
    model.train()
    tr_losses = []
    for bx, by in train_loader:
        optimizer.zero_grad()
        pred = model(bx)
        loss = criterion(pred, by)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()
        tr_losses.append(loss.item())
    if val_loader is not None:
        model.eval()
        va_losses = []
        with torch.no_grad():
            for bx, by in val_loader:
                va_losses.append(criterion(model(bx), by).item())
        va = np.mean(va_losses)
    else:
        va = np.mean(tr_losses)
    tr = np.mean(tr_losses)
    print(f"Epoch {ep+1:03d} Train {tr:.6f} Val {va:.6f}")
    if va < best_val - 1e-6:
        best_val, patience = va, 0
        torch.save(model.state_dict(), "best_cnn_lstm_tasmax.pth")
    else:
        patience += 1
        if patience >= max_patience:
            print("Early stopping.")
            break

model.load_state_dict(torch.load("best_cnn_lstm_tasmax.pth", map_location="cpu"))
model.eval()

# ========== Predict residuals ==========
def predict_residuals_on_series(qm_series, L, x_mean, x_std, y_mean, y_std, mdl):
    qm_series = np.asarray(qm_series, float)
    res = np.zeros_like(qm_series)
    cnt = np.zeros_like(qm_series)
    with torch.no_grad():
        for i in range(len(qm_series) - L):
            window = qm_series[i:i+L]
            win_n = (window - x_mean) / x_std
            x = torch.tensor(win_n, dtype=torch.float32).unsqueeze(0).unsqueeze(1)
            pred_n = mdl(x).cpu().numpy()[0]
            pred = pred_n * y_std + y_mean
            res[i+L] += pred
            cnt[i+L] += 1
    cnt[cnt == 0] = 1
    return res / cnt

pred_res_1549 = predict_residuals_on_series(qm_future_all, input_len, x_mean, x_std, y_mean, y_std, model)
future_corrected_all = qm_future_all + pred_res_1549

# ========== Plot time series ==========
start, end = pd.Timestamp("2015-01-01"), pd.Timestamp("2025-12-31")

mask_era = (dates_obs >= start) & (dates_obs <= end)
x_era, y_era = dates_obs[mask_era], obs_vals[mask_era]

mask_fu = (dates_target >= start) & (dates_target <= end)
x_unc, y_unc = dates_target[mask_fu], target_vals[mask_fu]

y_cor = future_corrected_all[mask_fu]

plt.figure(figsize=(14,6))
plt.plot(x_unc, y_unc, label='Future (Uncorrected)', linewidth=1.2)
plt.plot(x_unc, y_cor, label='Future (QM + CNN-LSTM Corrected)', linewidth=1.8)
plt.plot(x_era, y_era, label='ERA5 (2015-2025)', linewidth=1.5)
plt.axvline(pd.Timestamp('2015-01-01'), color='red', linestyle='--')
plt.xlabel("Year")
plt.ylabel("Max Temperature (K)")
plt.title("Monthly Mean Max Temperature (2015-2025)")
plt.legend()
plt.tight_layout()
plt.show()


# --- Compute average seasonal cycle ---
def monthly_climatology(dates, values):
    """Compute the average value for each month across years. Returns a 12-element array (Jan to Dec)."""
    values = np.asarray(values)
    months = np.array([d.month for d in dates])
    climat = np.array([values[months == m].mean() for m in range(1, 13)])
    return climat

era_clim = monthly_climatology(x_era, y_era)
unc_clim = monthly_climatology(x_unc, y_unc)
cor_clim = monthly_climatology(x_unc, y_cor)

# --- Plot seasonal cycle ---
months = np.arange(1, 13)
plt.figure(figsize=(8,5))
plt.plot(months, unc_clim, marker='s', label='CMIP6 raw')
plt.plot(months, cor_clim, marker='^', label='CMIP6 QM+CNN-LSTM')
plt.plot(months, era_clim, marker='o', label='ERA5')
plt.xticks(months, ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'])
plt.xlabel('Month')
plt.ylabel('Temperature (K)')
plt.title('Average Seasonal Cycle of Maximum Temperature (2015-2025)')
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend()
plt.show()

from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# Select future time period (from 2015) to ensure residual prediction exists
start_eval = pd.Timestamp("2015")
mask_eval = dates_target >= start_eval

qm_trimmed = qm_future_all[mask_eval]
deep_corrected = future_corrected_all[mask_eval]

rmse = np.sqrt(mean_squared_error(qm_trimmed, deep_corrected))
mae = mean_absolute_error(qm_trimmed, deep_corrected)
r2 = r2_score(qm_trimmed, deep_corrected)

print("\n✅ Performance metrics: Deep Correction vs QM (Future):")
print(f"RMSE: {rmse:.4f} K")
print(f"MAE: {mae:.4f} K")
print(f"R²: {r2:.4f}")

# ========== Plot histogram of maximum temperature ==========
plt.figure(figsize=(10,6))
# CMIP6 raw
plt.hist(y_unc, bins=20, alpha=0.5, label='CMIP6 raw', density=True)

# CMIP6 QM+CNN-LSTM corrected
plt.hist(y_cor, bins=20, alpha=0.5, label='CMIP6 QM+CNN-LSTM', density=True)

# ERA5
plt.hist(y_era, bins=20, alpha=0.5, label='ERA5 (2015-2025)', density=True)

plt.xlabel("Maximum Temperature (K)")
plt.ylabel("Probability Density")
plt.title("Histogram of Monthly Maximum Temperature (2015-2025)")
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()

import matplotlib.pyplot as plt
import cartopy.crs as ccrs

# Compute spatial average for 2015-2025
future_sel_1525 = future_sel.sel({time_dim_future: slice("2015-01", "2025-12")})
future_original_mean = future_sel_1525.mean(dim=time_dim_future)

# QM + CNN-LSTM corrected mean
residuals_1525 = future_corrected_all[mask_fu] - qm_future_all[mask_fu]
residuals_mean = residuals_1525.mean()  # simplified example
future_corrected_mean = future_sel_1525.mean(dim='time')

# ERA5 2015-2025 mean spatial distribution
era5_sel_1525 = era5_sel.sel({time_dim_era5: slice("2015-01", "2025-12")})
era5_mean = era5_sel_1525.mean(dim=time_dim_era5)

# Create 1 row × 3 columns subplots
fig, axes = plt.subplots(
    1, 3, figsize=(18,6),
    subplot_kw={'projection': ccrs.PlateCarree()}
)

# Original future temperature
im0 = axes[0].pcolormesh(
    future_sel_1525.lon, future_sel_1525.lat,
    future_original_mean,
    cmap='coolwarm'
)
axes[0].coastlines()
axes[0].set_title("Original Future (2015-2025)")
plt.colorbar(im0, ax=axes[0], orientation='vertical', label='Temperature (K)')

# QM + CNN-LSTM corrected temperature
im1 = axes[1].pcolormesh(
    future_sel_1525.lon, future_sel_1525.lat,
    future_corrected_mean,
    cmap='coolwarm'
)
axes[1].coastlines()
axes[1].set_title("Corrected Future (2015-2025)")
plt.colorbar(im1, ax=axes[1], orientation='vertical', label='Temperature (K)')

# ERA5 temperature
im2 = axes[2].pcolormesh(
    era5_mean.lon, era5_mean.lat,
    era5_mean,
    cmap='coolwarm'
)
axes[2].coastlines()
axes[2].set_title("ERA5 (2015-2025)")
plt.colorbar(im2, ax=axes[2], orientation='vertical', label='Temperature (K)')

plt.tight_layout()
plt.show()
