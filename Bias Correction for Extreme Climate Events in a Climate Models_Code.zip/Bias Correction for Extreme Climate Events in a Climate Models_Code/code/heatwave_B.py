import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from matplotlib.colors import LinearSegmentedColormap
import matplotlib.ticker as mticker
from cartopy.mpl.ticker import LongitudeFormatter, LatitudeFormatter

# ========================================
# 1️⃣ Load CMIP6 data (2015–2049)
# ========================================
ds_tasmax = xr.open_dataset("tasmax_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc")
ds_tasmin = xr.open_dataset("tasmin_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc")
ds_rsds   = xr.open_dataset("rsds_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc")
ds_hurs   = xr.open_dataset("hurs_Amon_CanESM5_ssp245_r1i1p1f1_gn_20150116-20491216.nc")

# Select 2015–2049 period
tasmax = ds_tasmax['tasmax'].sel(time=slice('2015','2049')) - 273.15
tasmin = ds_tasmin['tasmin'].sel(time=slice('2015','2049')) - 273.15
rsds   = ds_rsds['rsds'].sel(time=slice('2015','2049'))
hurs   = ds_hurs['hurs'].sel(time=slice('2015','2049')).interp(
    lat=tasmax['lat'], lon=tasmax['lon']
).clip(0,100)

lat = tasmax['lat'].values
lon = tasmax['lon'].values

# ========================================
# 2️⃣ Align time
# ========================================
common_time = tasmax['time']
tasmin = tasmin.reindex(time=common_time, method='nearest', tolerance=np.timedelta64(1, 'D'))
hurs   = hurs.reindex(time=common_time, method='nearest', tolerance=np.timedelta64(1, 'D'))
rsds   = rsds.reindex(time=common_time, method='nearest', tolerance=np.timedelta64(1, 'D'))

# ========================================
# 3️⃣ WBGT calculation function
# ========================================
def calc_wbgt(tasmax, tasmin, hurs, rsds):
    Tmean = (tasmax + tasmin)/2
    Twb = Tmean * (hurs/100.0)**0.125
    wbgt = 0.7*Twb + 0.2*(rsds/100.0) + 0.1*Tmean
    return wbgt

wbgt = calc_wbgt(tasmax, tasmin, hurs, rsds)

# ========================================
# 4️⃣ Heatwave definition (WBGT ≥ 90th percentile)
# ========================================
wbgt_thresh = wbgt.quantile(0.9, dim='time', skipna=True)
if 'quantile' in wbgt_thresh.dims:
    wbgt_thresh = wbgt_thresh.sel(quantile=0.9)

# Keep WBGT values above the threshold, set others to NaN
heatwave_intensity = wbgt.where(wbgt >= wbgt_thresh)

# ========================================
# 5️⃣ Compute mean heatwave intensity (2015–2049)
# ========================================
heatwave_mean = heatwave_intensity.mean(dim='time')

# ========================================
# 6️⃣ Spatial distribution plotting function
# ========================================
def plot_spatial(data, lats, lons, title, unit='K', lon_min=None, lon_max=None, lat_min=None, lat_max=None):
    fig, ax = plt.subplots(figsize=(12, 6), subplot_kw={'projection': ccrs.PlateCarree()},
                           constrained_layout=True)

    # Temperature gradient colormap
    colors = [(0,0,1), (1,1,1), (1,0,0)]
    cmap = LinearSegmentedColormap.from_list("temp_cmap", colors)

    im = ax.pcolormesh(lons, lats, data, cmap=cmap, shading='auto', alpha=0.9)

    ax.coastlines(resolution='50m', linewidth=0.8)
    ax.add_feature(cfeature.BORDERS, linewidth=0.6, linestyle=':')
    try:
        ax.add_feature(cfeature.STATES, linewidth=0.4, alpha=0.5)
    except:
        pass

    if lon_min is not None and lon_max is not None and lat_min is not None and lat_max is not None:
        ax.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())

    gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                      linewidth=0.8, color='gray', alpha=0.5, linestyle='--')
    gl.top_labels = False
    gl.right_labels = False
    gl.xlocator = mticker.FixedLocator(np.arange(-180,181,20))
    gl.ylocator = mticker.FixedLocator(np.arange(-90,91,10))
    gl.xformatter = LongitudeFormatter()
    gl.yformatter = LatitudeFormatter()
    gl.xlabel_style = {'size':8}
    gl.ylabel_style = {'size':8}

    cbar = plt.colorbar(im, ax=ax, orientation='vertical', label=unit, shrink=0.85, aspect=15)
    cbar.ax.tick_params(labelsize=8)
    ax.set_title(title, fontsize=14, pad=10)
    plt.show()

# ========================================
# 7️⃣ Plot spatial distribution of average heatwave intensity (2015–2049)
# ========================================
lon_min, lon_max = -125, -66
lat_min, lat_max = 24, 50

plot_spatial(
    heatwave_mean.values, lat, lon,
    title="Average Heatwave Intensity (WBGT) 2015–2049 (USA)",
    unit="K", lon_min=lon_min, lon_max=lon_max, lat_min=lat_min, lat_max=lat_max
)
