import xarray as xr
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER

# ----------------------------
# Step 1: Load Data
# ----------------------------
# Filenames for maximum temperature datasets
ERA5_tasmax1 = 'mx2t_2.nc'
ERA5_tasmax2 = 'mx2t_1.nc'
CMIP6_tasmax = 'CMIP6_tasmax.nc'  # CMIP6 Tmax file (verify)

# Load ERA5 datasets and concatenate
ds1 = xr.open_dataset(ERA5_tasmax1, chunks={"time": 10})
ds2 = xr.open_dataset(ERA5_tasmax2, chunks={"time": 10})
ds_era5 = xr.concat([ds1, ds2], dim="valid_time").sortby("valid_time")
ds_era5 = ds_era5.chunk({'valid_time': 100})  # optimize chunking

# Load CMIP6 dataset
ds_cmip6 = xr.open_dataset(CMIP6_tasmax, chunks={"time": 10})

# Print time ranges
print("CMIP6 time range:", ds_cmip6.time.min().values, "to", ds_cmip6.time.max().values)
print("ERA5 time range:", ds_era5.valid_time.min().values, "to", ds_era5.valid_time.max().values)

# ----------------------------
# Step 2: Extract Variables and Convert Units (Maximum 2m Temperature)
# ----------------------------
# ERA5 mx2t in K → convert to °C
tasmax_era5 = ds_era5['mx2t'] - 273.15
# CMIP6 tasmax in K → convert to °C
tasmax_cmip6 = ds_cmip6['tasmax'] - 273.15

# ----------------------------
# Step 3: Data Preprocessing
# ----------------------------
# Standardize coordinates
tasmax_era5 = tasmax_era5.rename({
    'latitude': 'lat',
    'longitude': 'lon',
    'valid_time': 'time'
})

# Mask unreasonable values for the study region (25–50°N, -125–-66°W)
tasmax_cmip6 = tasmax_cmip6.where((tasmax_cmip6 >= -40) & (tasmax_cmip6 <= 45))
tasmax_era5 = tasmax_era5.where((tasmax_era5 >= -40) & (tasmax_era5 <= 45))

# ----------------------------
# Step 4: Crop Temporal and Spatial Range (1950-2014)
# ----------------------------
lat_min, lat_max = 25, 50
lon_min, lon_max = -125, -66
lon_min_conv, lon_max_conv = lon_min + 360, lon_max + 360  # convert to 0–360

# Crop CMIP6
cmip6_crop = tasmax_cmip6.sel(
    time=slice("1950", "2014"),
    lat=slice(lat_min, lat_max),
    lon=slice(lon_min_conv, lon_max_conv)
)

# Crop ERA5 (lat may be descending)
era5_crop = tasmax_era5.sel(
    time=slice("1950", "2014"),
    lat=slice(lat_max, lat_min),
    lon=slice(lon_min_conv, lon_max_conv)
)

# Check cropped data
print("\nCMIP6 Cropped Data Check:")
print(f"Valid data points: {cmip6_crop.count().values}")
print(f"Time range: {cmip6_crop.time.min().values} ~ {cmip6_crop.time.max().values}")
print(f"Latitude range: {cmip6_crop.lat.min().values} ~ {cmip6_crop.lat.max().values}")
print(f"Longitude range: {cmip6_crop.lon.min().values} ~ {cmip6_crop.lon.max().values}")

print("\nERA5 Cropped Data Check:")
print(f"Valid data points: {era5_crop.count().values}")
print(f"Time range: {era5_crop.time.min().values} ~ {era5_crop.time.max().values}")
print(f"Latitude range: {era5_crop.lat.min().values} ~ {era5_crop.lat.max().values}")
print(f"Longitude range: {era5_crop.lon.min().values} ~ {era5_crop.lon.max().values}")

# ----------------------------
# Step 5: Temporal Alignment (Year-Month Matching)
# ----------------------------
# Add year-month coordinate to align dates
cmip6_crop = cmip6_crop.assign_coords(
    year_month=cmip6_crop.time.dt.strftime('%Y-%m')
)
era5_crop = era5_crop.assign_coords(
    year_month=era5_crop.time.dt.strftime('%Y-%m')
)

# Find common year-months
common_years_months = np.intersect1d(
    cmip6_crop.year_month.values,
    era5_crop.year_month.values
)
print(f"\nNumber of common year-months: {len(common_years_months)}")

# Select only common months
cmip6_aligned = cmip6_crop.sel(
    time=[t for t, ym in zip(cmip6_crop.time.values, cmip6_crop.year_month.values)
          if ym in common_years_months]
)
era5_aligned = era5_crop.sel(
    time=[t for t, ym in zip(era5_crop.time.values, era5_crop.year_month.values)
          if ym in common_years_months]
)

print(f"CMIP6 aligned valid data: {cmip6_aligned.count().values}")
print(f"ERA5 aligned valid data: {era5_aligned.count().values}")

# ----------------------------
# Step 6: Spatial Alignment (Grid Matching)
# ----------------------------
print(f"\nCMIP6 grid: {len(cmip6_aligned.lat)} latitude points, {len(cmip6_aligned.lon)} longitude points")
print(f"ERA5 grid: {len(era5_aligned.lat)} latitude points, {len(era5_aligned.lon)} longitude points")

# Choose higher-resolution grid as target
if len(cmip6_aligned.lat) > len(era5_aligned.lat):
    target_lat = cmip6_aligned.lat
    target_lon = cmip6_aligned.lon
    era5_aligned = era5_aligned.interp(lat=target_lat, lon=target_lon, method='linear')
else:
    target_lat = era5_aligned.lat
    target_lon = era5_aligned.lon
    cmip6_aligned = cmip6_aligned.interp(lat=target_lat, lon=target_lon, method='linear')

print(f"Aligned grid: {len(target_lat)} latitude points, {len(target_lon)} longitude points")

# ----------------------------
# Step 7: Bias Correction
# ----------------------------
# Compute mean bias (CMIP6 - ERA5)
bias = cmip6_aligned.mean(dim='time') - era5_aligned.mean(dim='time')

# Apply bias correction
cmip6_corrected = cmip6_aligned - bias

# Compute time-averaged values for plotting
cmip6_mean = cmip6_aligned.mean(dim='time')
cmip6_corrected_mean = cmip6_corrected.mean(dim='time')
era5_mean = era5_aligned.mean(dim='time')

print("\nPlotting data statistics:")
print(f"CMIP6 mean Tmax: {cmip6_mean.min().values:.2f}~{cmip6_mean.max().values:.2f} ℃")
print(f"ERA5 mean Tmax: {era5_mean.min().values:.2f}~{era5_mean.max().values:.2f} ℃")

# ----------------------------
# Step 8: Spatial Distribution Plots (Separate colorbars)
# ----------------------------
plot_extent = [lon_min, lon_max, lat_min, lat_max]

fig = plt.figure(figsize=(16, 14))

# 1. Original CMIP6 mean Tmax
ax1 = fig.add_subplot(2, 2, 1, projection=ccrs.PlateCarree())
ax1.set_extent(plot_extent, crs=ccrs.PlateCarree())
im1 = ax1.contourf(
    cmip6_mean.lon - 360,
    cmip6_mean.lat,
    cmip6_mean,
    levels=np.linspace(-10, 35, 11),
    cmap='YlOrRd',
    extend='both'
)
ax1.coastlines(resolution='50m', linewidth=0.8)
ax1.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax1.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False
gl.right_labels = False
gl.xformatter = LONGITUDE_FORMATTER
gl.yformatter = LATITUDE_FORMATTER
ax1.set_title('(a) Original CMIP6 Mean Maximum Temperature (℃)', fontsize=12)
plt.colorbar(im1, ax=ax1, orientation='vertical', label='Temperature (℃)')

# 2. ERA5 observed mean Tmax
ax2 = fig.add_subplot(2, 2, 2, projection=ccrs.PlateCarree())
ax2.set_extent(plot_extent, crs=ccrs.PlateCarree())
im2 = ax2.contourf(
    era5_mean.lon - 360,
    era5_mean.lat,
    era5_mean,
    levels=np.linspace(-10, 35, 11),
    cmap='YlOrRd',
    extend='both'
)
ax2.coastlines(resolution='50m', linewidth=0.8)
ax2.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax2.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False
gl.right_labels = False
gl.xformatter = LONGITUDE_FORMATTER
gl.yformatter = LATITUDE_FORMATTER
ax2.set_title('(b) ERA5 Observed Mean Maximum Temperature (℃)', fontsize=12)
plt.colorbar(im2, ax=ax2, orientation='vertical', label='Temperature (℃)')

# 3. Bias map
ax3 = fig.add_subplot(2, 2, 3, projection=ccrs.PlateCarree())
ax3.set_extent(plot_extent, crs=ccrs.PlateCarree())
bias_min = np.nanmin(bias.values)
bias_max = np.nanmax(bias.values)
bias_levels = np.linspace(np.floor(bias_min), np.ceil(bias_max), 11)
im3 = ax3.contourf(
    bias.lon - 360,
    bias.lat,
    bias,
    levels=bias_levels,
    cmap='RdBu_r',
    extend='both'
)
ax3.coastlines(resolution='50m', linewidth=0.8)
ax3.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax3.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False
gl.right_labels = False
gl.xformatter = LONGITUDE_FORMATTER
gl.yformatter = LATITUDE_FORMATTER
ax3.set_title('(c) CMIP6 Bias (CMIP6 - ERA5) (℃)', fontsize=12)
plt.colorbar(im3, ax=ax3, orientation='vertical', label='Bias (℃)')

# 4. Bias-corrected CMIP6 mean Tmax
ax4 = fig.add_subplot(2, 2, 4, projection=ccrs.PlateCarree())
ax4.set_extent(plot_extent, crs=ccrs.PlateCarree())
im4 = ax4.contourf(
    cmip6_corrected_mean.lon - 360,
    cmip6_corrected_mean.lat,
    cmip6_corrected_mean,
    levels=np.linspace(-10, 35, 11),
    cmap='YlOrRd',
    extend='both'
)
ax4.coastlines(resolution='50m', linewidth=0.8)
ax4.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax4.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False
gl.right_labels = False
gl.xformatter = LONGITUDE_FORMATTER
gl.yformatter = LATITUDE_FORMATTER
ax4.set_title('(d) Bias-Corrected CMIP6 Mean Maximum Temperature (℃)', fontsize=12)
plt.colorbar(im4, ax=ax4, orientation='vertical', label='Temperature (℃)')

plt.tight_layout()
plt.savefig('cmip6_tasmax_bias_correction_1950-2014_colorbars.png', dpi=300, bbox_inches='tight')
plt.show()
