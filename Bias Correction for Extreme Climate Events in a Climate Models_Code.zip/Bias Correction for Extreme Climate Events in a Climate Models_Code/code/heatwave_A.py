import xarray as xr
import numpy as np
import torch
import torch.nn as nn
from scipy.interpolate import interp1d
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from tqdm import tqdm
import scipy.stats as stats

# ========================================
# 1️⃣ Load future climate data
# ========================================
ds_tasmax = xr.open_dataset("tasmax_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc")
ds_tasmin = xr.open_dataset("tasmin_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc")
ds_rsds = xr.open_dataset("rsds_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc")
ds_hurs = xr.open_dataset("hurs_Amon_CanESM5_ssp245_r1i1p1f1_gn_20150116-20491216.nc")

tasmax_raw = ds_tasmax['tasmax'].values - 273.15
tasmin_raw = ds_tasmin['tasmin'].values - 273.15
rsds_raw = ds_rsds['rsds'].values

# Regrid hurs to match tasmax grid
hurs_ds_interp = ds_hurs.interp(lat=ds_tasmax.lat, lon=ds_tasmax.lon)
hurs_raw = hurs_ds_interp['hurs'].values

latitudes = ds_tasmax['lat'].values
longitudes = ds_tasmax['lon'].values

time_len, lat_len, lon_len = tasmax_raw.shape

# ========================================
# 2️⃣ Generate example historical obs / sim for QM
# ========================================
np.random.seed(0)
N_hist = 1000
obs_vars = {
    'tasmax': np.random.normal(30, 5, N_hist),
    'tasmin': np.random.normal(20, 4, N_hist),
    'rsds': np.random.normal(200, 50, N_hist),
    'hurs': np.random.normal(60, 10, N_hist),
}
sim_vars = {k: obs_vars[k] + np.random.normal(0, 2 if 'tas' in k else 20 if k == 'rsds' else 5, N_hist)
            for k in obs_vars}

# ========================================
# 3️⃣ QM function
# ========================================
def quantile_mapping(obs, sim, target):
    quantiles = np.linspace(0, 1, 1001)
    obs_q = np.quantile(obs, quantiles)
    sim_q = np.quantile(sim, quantiles)
    sim_q_unique, idx = np.unique(sim_q, return_index=True)
    obs_q_unique = obs_q[idx]
    qm_func = interp1d(sim_q_unique, obs_q_unique, bounds_error=False, fill_value="extrapolate")
    return qm_func(target)

def qm_correct_all(obs_vars, sim_vars, future_vars):
    corrected = {}
    for key in obs_vars.keys():
        corrected[key] = quantile_mapping(obs_vars[key], sim_vars[key], future_vars[key])
    return corrected

# ========================================
# 4️⃣ CNN-LSTM model
# ========================================
class CNN_LSTM_Enhanced(nn.Module):
    def __init__(self, input_dim=4, cnn_channels=64, lstm_hidden=128, time_emb_dim=4, dropout=0.3):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv1d(input_dim, cnn_channels, kernel_size=3, padding=1),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Conv1d(cnn_channels, cnn_channels, kernel_size=3, padding=1),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.lstm = nn.LSTM(cnn_channels, lstm_hidden, batch_first=True)
        self.fc = nn.Sequential(
            nn.Linear(lstm_hidden + time_emb_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 4)
        )

    def forward(self, x, time_emb):
        x = x.permute(0, 2, 1)
        x = self.cnn(x).permute(0, 2, 1)
        _, (h_n, _) = self.lstm(x)
        h_last = h_n[-1]
        combined = torch.cat([h_last, time_emb], dim=1)
        return self.fc(combined)

# ========================================
# 5️⃣ Prepare residual training data (example)
# ========================================
def create_multivariate_sequences(data_dict, seq_len=30):
    keys = list(data_dict.keys())
    length = len(data_dict[keys[0]])
    X, y = [], []
    for i in range(length - seq_len):
        seq = np.stack([data_dict[k][i:i + seq_len] for k in keys], axis=1)
        target = np.array([data_dict[k][i + seq_len] for k in keys])
        X.append(seq)
        y.append(target)
    return np.array(X), np.array(y)

residuals = {k: obs_vars[k] - quantile_mapping(obs_vars[k], sim_vars[k], sim_vars[k])
             for k in obs_vars.keys()}
X_train, y_train = create_multivariate_sequences(residuals, seq_len=30)
time_emb_train = np.random.normal(0, 1, (X_train.shape[0], 4))

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
X_train = torch.tensor(X_train, dtype=torch.float32).to(device)
y_train = torch.tensor(y_train, dtype=torch.float32).to(device)
time_emb_train = torch.tensor(time_emb_train, dtype=torch.float32).to(device)

# ========================================
# 6️⃣ Train CNN-LSTM model
# ========================================
model = CNN_LSTM_Enhanced(input_dim=4).to(device)
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
model.train()
for epoch in range(5):
    optimizer.zero_grad()
    output = model(X_train, time_emb_train)
    loss = criterion(output, y_train)
    loss.backward()
    optimizer.step()
    print(f"Epoch {epoch + 1}, Loss={loss.item():.4f}")

# ========================================
# 7️⃣ Grid-wise QM + CNN-LSTM correction
# ========================================
seq_len = 30
qm_dl_grid = {key: np.zeros_like(tasmax_raw) for key in ['tasmax', 'tasmin', 'rsds', 'hurs']}

all_indices = [(i, j) for i in range(lat_len) for j in range(lon_len)]
batch_size = 50

for batch_start in tqdm(range(0, len(all_indices), batch_size), desc="Grid correction"):
    batch_indices = all_indices[batch_start:batch_start + batch_size]
    future_batch = {k: [] for k in ['tasmax', 'tasmin', 'rsds', 'hurs']}

    for i, j in batch_indices:
        point = {
            'tasmax': tasmax_raw[:, i, j],
            'tasmin': tasmin_raw[:, i, j],
            'rsds': rsds_raw[:, i, j],
            'hurs': hurs_raw[:, i, j]
        }
        corrected = qm_correct_all(obs_vars, sim_vars, point)
        for k in future_batch:
            future_batch[k].append(corrected[k])

    for k in future_batch:
        future_batch[k] = np.stack(future_batch[k], axis=1)

    # Create sequences for CNN-LSTM
    X_seq = []
    for t in range(seq_len, future_batch['tasmax'].shape[0]):
        seq = np.stack([future_batch[k][t - seq_len:t, :] for k in future_batch], axis=2)
        X_seq.append(seq)
    X_seq = np.stack(X_seq, axis=0)
    time_emb = np.random.normal(0, 1, (X_seq.shape[0], X_seq.shape[2], 4))

    B, S, N, V = X_seq.shape
    X_tensor = torch.tensor(X_seq.reshape(B * N, S, V), dtype=torch.float32).to(device)
    time_emb_tensor = torch.tensor(time_emb.reshape(B * N, 4), dtype=torch.float32).to(device)

    model.eval()
    with torch.no_grad():
        residuals_pred = model(X_tensor, time_emb_tensor).cpu().numpy()

    for idx, (i, j) in enumerate(batch_indices):
        for t_idx in range(B):
            for k_idx, k in enumerate(['tasmax', 'tasmin', 'rsds', 'hurs']):
                qm_dl_grid[k][seq_len + t_idx, i, j] = future_batch[k][seq_len + t_idx, idx] + residuals_pred[
                    t_idx * N + idx, k_idx]

# ========================================
# 8️⃣ Heatwave mask calculation
# ========================================
def calc_heatwave_mask_grid(tasmax, tasmin, hurs, rsds, threshold_tasmax=35, threshold_wbgt=32):
    Tmean = (tasmax + tasmin) / 2
    Twb = Tmean * (hurs / 100) ** 0.125
    wbgt = 0.7 * Twb + 0.2 * (rsds / 100) + 0.1 * Tmean
    return (tasmax > threshold_tasmax) | (wbgt > threshold_wbgt)

heatwave_raw_mean = np.mean(calc_heatwave_mask_grid(tasmax_raw, tasmin_raw, hurs_raw, rsds_raw), axis=0)
heatwave_corrected_mean = np.mean(calc_heatwave_mask_grid(qm_dl_grid['tasmax'], qm_dl_grid['tasmin'],
                                                          qm_dl_grid['hurs'], qm_dl_grid['rsds']), axis=0)

# ========================================
# 9️⃣ Plot spatial heatwave probability
# ========================================
def plot_heatwave_map(data, lats, lons, title):
    plt.figure(figsize=(12, 6))
    ax = plt.axes(projection=ccrs.PlateCarree())
    mesh = ax.pcolormesh(lons, lats, data, cmap='Reds', shading='auto')
    ax.coastlines()
    ax.add_feature(cfeature.BORDERS, linestyle=':')
    ax.set_title(title, fontsize=14)
    cbar = plt.colorbar(mesh, orientation='vertical', pad=0.02)
    cbar.set_label('Heatwave Probability (2015-2049)')
    plt.show()

plot_heatwave_map(heatwave_raw_mean, latitudes, longitudes, 'Heatwave Probability (Raw, 2015-2049)')
plot_heatwave_map(heatwave_corrected_mean, latitudes, longitudes, 'Heatwave Probability (QM + CNN-LSTM, 2015-2049)')