# ===============================
# Imports & Environment Setup
# ===============================
import numpy as np
import pandas as pd
import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import torch
import torch.nn as nn
import torch.optim as optim
from scipy.ndimage import gaussian_filter1d
from torch.utils.data import DataLoader, TensorDataset
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error
from scipy.stats import pearsonr
from scipy.interpolate import interp1d


def set_seed(seed=42):
    """Set random seeds for reproducibility across numpy and PyTorch."""
    torch.manual_seed(seed)
    np.random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)


set_seed()  # Initialize random seed

# ===============================
# Data Loading & Preprocessing
# ===============================
# Load datasets (CMIP6 precipitation and ERA5 total precipitation)
ds_cmip6 = xr.open_dataset("CMIP6_pr.nc", chunks={"time": 10})
ds_era5 = xr.open_dataset("ERA5_tp.nc", chunks={"time": 10})

# Unit conversion
cmip6_raw = ds_cmip6['pr'] * 86400  # Convert CMIP6 pr (kg/m²/s) to mm/day
era5 = ds_era5['tp'] * 1000  # Convert ERA5 tp (meters) to mm
era5 = era5.rename({'latitude': 'lat', 'longitude': 'lon'})  # Standardize coordinate names

# Outlier filtering
cmip6_raw = cmip6_raw.where(cmip6_raw != 1e20)  # Mask CMIP6 missing values (flagged as 1e20)
era5 = era5.where(era5 < 1e10)  # Mask extreme/outlier values in ERA5

# Temporal subsetting (focus on 1950-2014 period)
cmip6_raw = cmip6_raw.sel(time=slice("1950", "2014"))
era5 = era5.sel(valid_time=slice("1950", "2014"))

# Spatial subsetting (target region: e.g., CONUS)
lat_min, lat_max = 25, 50  # Latitude range (25°N to 50°N)
lon_min, lon_max = -125, -66  # Longitude range (-125°W to -66°W)
lon_min_conv, lon_max_conv = lon_min + 360, lon_max + 360  # Convert W to E longitude (0-360°)

cmip6_raw = cmip6_raw.sel(lat=slice(lat_min, lat_max), lon=slice(lon_min_conv, lon_max_conv))
era5 = era5.sel(lat=slice(lat_max, lat_min), lon=slice(lon_min_conv, lon_max_conv))  # ERA5 uses descending latitude

# Compute regional mean (spatial average) and resample to monthly frequency
cmip6_mon = cmip6_raw.mean(dim=['lat', 'lon']).resample(time="1MS").mean()  # "1MS" = month-start frequency
era5_mon = era5.mean(dim=['lat', 'lon']).resample(valid_time="1MS").mean()

# Smooth time series with Gaussian filter to reduce high-frequency noise
cmip6_mon.values = gaussian_filter1d(cmip6_mon.values, sigma=1)
era5_mon.values = gaussian_filter1d(era5_mon.values, sigma=1)


# ===============================
# Quantile Mapping (QM) Correction
# ===============================
def quantile_mapping(obs, sim, target):
    """
    Apply quantile mapping to correct simulated precipitation data.

    Parameters:
        obs: Observed precipitation values (1D array, e.g., ERA5)
        sim: Simulated precipitation values for calibration (1D array, e.g., raw CMIP6)
        target: Target simulated values to correct (1D array)

    Returns:
        corrected_target: QM-corrected target values (1D array)
    """
    quantiles = np.linspace(0, 1, 1001)  # Generate 1001 quantiles (0 to 1)
    obs_q = np.quantile(obs, quantiles)  # Observed quantile distribution
    sim_q = np.quantile(sim, quantiles)  # Simulated quantile distribution

    # Remove duplicate quantiles to avoid interpolation errors
    sim_q_unique, idx = np.unique(sim_q, return_index=True)
    obs_q_unique = obs_q[idx]

    # Create interpolation function (map simulated quantiles to observed)
    qm_func = interp1d(
        sim_q_unique, obs_q_unique,
        bounds_error=False,
        fill_value="extrapolate"  # Extrapolate for values outside calibration range
    )

    return qm_func(target)


# Apply QM to raw CMIP6 data
sim_raw = cmip6_mon.values  # Raw CMIP6 monthly precipitation
obs = era5_mon.values  # ERA5 observed monthly precipitation
sim_qm = quantile_mapping(obs, sim_raw, sim_raw)  # QM-corrected CMIP6
residuals = obs - sim_qm  # Residuals (observed - QM-corrected) for deep learning


# ===============================
# Time Embedding (Seasonal/Yearly Features)
# ===============================
def add_time_embedding(length, start_year="1950-01"):
    """
    Create time embedding features (sin/cos encoding for month/year) to capture temporal patterns.

    Parameters:
        length: Number of time steps (months)
        start_year: Start date of the time series (format: "YYYY-MM")

    Returns:
        time_emb: Time embedding array (shape: [length, 4], features: sin(month), cos(month), sin(year), cos(year))
    """
    dates = pd.date_range(start=start_year, periods=length, freq="MS")
    months = dates.month.values  # Month of each time step (1-12)
    years = dates.year.values - dates.year.values.min()  # Normalize year to start from 0

    # Sin/cos encoding to capture cyclic patterns (monthly and decadal)
    sin_month = np.sin(2 * np.pi * months / 12)
    cos_month = np.cos(2 * np.pi * months / 12)
    sin_year = np.sin(2 * np.pi * years / 10)  # Decadal cycle (10 years)
    cos_year = np.cos(2 * np.pi * years / 10)

    return np.stack([sin_month, cos_month, sin_year, cos_year], axis=1)


# ===============================
# Sequence Preparation for Deep Learning
# ===============================
def create_sequences(data, input_len=60, pred_len=1):
    """
    Convert 1D time series into input-output sequences for time-series forecasting.

    Parameters:
        data: 1D time series (residuals)
        input_len: Length of input sequence (number of past months)
        pred_len: Length of prediction (number of future months, default: 1)

    Returns:
        X: Input sequences (shape: [n_sequences, input_len])
        y: Target values (shape: [n_sequences, pred_len])
    """
    X, y = [], []
    # Iterate through time series to generate sequences
    for i in range(len(data) - input_len - pred_len + 1):
        X.append(data[i:i + input_len])  # Input: past 'input_len' months
        y.append(data[i + input_len:i + input_len + pred_len])  # Target: next 'pred_len' months
    return np.array(X), np.array(y)


# Generate sequences from residuals
input_len = 120  # Use past 120 months (10 years) to predict residual
X_np, y_np = create_sequences(residuals, input_len=input_len)

# Normalize data (z-score standardization) to stabilize training
mean_resid, std_resid = X_np.mean(), X_np.std()
X_np = (X_np - mean_resid) / std_resid  # Normalize inputs
y_mean, y_std = y_np.mean(), y_np.std()
y_np = (y_np - y_mean) / y_std  # Normalize targets

# Convert to PyTorch tensors (add channel dimension for CNN)
X_tensor = torch.tensor(X_np, dtype=torch.float32).unsqueeze(-1)  # Shape: [n_seq, input_len, 1]
y_tensor = torch.tensor(y_np, dtype=torch.float32)  # Shape: [n_seq, 1]

# Create time embedding features for each sequence
X_time = torch.tensor(add_time_embedding(len(X_np)), dtype=torch.float32)  # Shape: [n_seq, 4]

# Split into training and validation sets (80% train, 20% val)
X_train, X_val, Xt_train, Xt_val, y_train, y_val = train_test_split(
    X_tensor, X_time, y_tensor, test_size=0.2, random_state=42
)

# Create DataLoaders for batch processing
train_loader = DataLoader(TensorDataset(X_train, Xt_train, y_train), batch_size=64, shuffle=True)
val_loader = DataLoader(TensorDataset(X_val, Xt_val, y_val), batch_size=64)


# ===============================
# Enhanced CNN-LSTM Model Definition
# ===============================
class CNN_LSTM_Enhanced(nn.Module):
    """
    Hybrid CNN-LSTM model with time embedding for residual correction.
    Combines CNN (local temporal feature extraction) + LSTM (long-term dependencies) + time embedding (cyclic patterns).
    """

    def __init__(self, input_dim=1, cnn_channels=64, lstm_hidden=128, time_emb_dim=4, dropout=0.3):
        super().__init__()
        # CNN block: extract local temporal features
        self.cnn = nn.Sequential(
            nn.Conv1d(input_dim, cnn_channels, kernel_size=3, padding=1),  # 1D convolution
            nn.BatchNorm1d(cnn_channels),  # Batch normalization to stabilize training
            nn.ReLU(),  # Activation function
            nn.Dropout(dropout),  # Dropout for regularization
            nn.Conv1d(cnn_channels, cnn_channels, kernel_size=3, padding=1),  # Second convolution layer
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

        # LSTM block: capture long-term temporal dependencies
        self.lstm = nn.LSTM(cnn_channels, lstm_hidden, batch_first=True)  # batch_first=True: [batch, seq_len, hidden]

        # Fully connected block: combine LSTM output with time embedding
        self.fc = nn.Sequential(
            nn.Linear(lstm_hidden + time_emb_dim, 64),  # Concatenate LSTM hidden state + time embedding
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 1)  # Output: predicted residual
        )

    def forward(self, x, time_emb):
        """Forward pass of the model."""
        # CNN input requires shape: [batch, input_dim, seq_len] → permute from [batch, seq_len, input_dim]
        x = x.permute(0, 2, 1)
        x = self.cnn(x)  # CNN output: [batch, cnn_channels, seq_len]

        # LSTM input requires shape: [batch, seq_len, cnn_channels] → permute back
        x = x.permute(0, 2, 1)
        _, (h_n, _) = self.lstm(x)  # LSTM output: h_n (hidden state) → [1, batch, lstm_hidden]

        # Use only the last time step's hidden state
        h_last = h_n[-1]  # Shape: [batch, lstm_hidden]

        # Concatenate LSTM hidden state with time embedding
        combined = torch.cat([h_last, time_emb], dim=1)  # Shape: [batch, lstm_hidden + time_emb_dim]

        # Predict residual
        return self.fc(combined).squeeze(1)  # Remove extra dimension → [batch]


# ===============================
# Loss Function & Model Training
# ===============================
def correlation_loss(pred, target):
    """
    Custom loss function to maximize Pearson correlation between predictions and targets.
    Calculates 1 - correlation (minimizing this = maximizing correlation).
    """
    vx = pred - torch.mean(pred)  # Centered predictions
    vy = target - torch.mean(target)  # Centered targets
    # Pearson correlation formula (add 1e-8 to avoid division by zero)
    corr = torch.sum(vx * vy) / (torch.sqrt(torch.sum(vx ** 2)) * torch.sqrt(torch.sum(vy ** 2)) + 1e-8)
    return 1 - corr


# Device configuration (use GPU if available)
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
model = CNN_LSTM_Enhanced().to(device)  # Initialize model and move to device

# Training setup
criterion = nn.MSELoss()  # Mean Squared Error loss
optimizer = optim.AdamW(  # AdamW optimizer with weight decay (regularization)
    model.parameters(),
    lr=1e-4,  # Initial learning rate
    weight_decay=1e-5  # L2 regularization
)
# Learning rate scheduler: reduce LR if validation loss plateaus
scheduler = optim.lr_scheduler.ReduceLROnPlateau(
    optimizer, 'min', patience=15, factor=0.5, min_lr=1e-6
)
max_grad_norm = 5.0  # Gradient clipping to prevent exploding gradients
best_val_loss = float('inf')  # Track best validation loss for early stopping
patience = 0  # Counter for early stopping
max_patience = 50  # Stop training if no improvement for 50 epochs

# Training loop
for epoch in range(300):  # Maximum 300 epochs
    # Training phase
    model.train()
    train_losses = []
    for batch_x, batch_time, batch_y in train_loader:
        # Move data to device (GPU/CPU)
        batch_x, batch_time, batch_y = batch_x.to(device), batch_time.to(device), batch_y.to(device)

        optimizer.zero_grad()  # Reset gradients
        outputs = model(batch_x, batch_time)  # Forward pass
        # Total loss: MSE loss + 0.1 * correlation loss (balance between error and correlation)
        loss_mse = criterion(outputs, batch_y.squeeze())
        loss_corr = correlation_loss(outputs, batch_y.squeeze())
        loss = loss_mse + 0.1 * loss_corr

        loss.backward()  # Backpropagation
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)  # Clip gradients
        optimizer.step()  # Update model weights

        train_losses.append(loss.item())

    # Validation phase
    model.eval()
    val_losses = []
    with torch.no_grad():  # Disable gradient computation for validation
        for batch_x, batch_time, batch_y in val_loader:
            batch_x, batch_time, batch_y = batch_x.to(device), batch_time.to(device), batch_y.to(device)
            outputs = model(batch_x, batch_time)
            loss_mse = criterion(outputs, batch_y.squeeze())
            loss_corr = correlation_loss(outputs, batch_y.squeeze())
            val_loss = loss_mse + 0.1 * loss_corr
            val_losses.append(val_loss.item())

    # Calculate average losses
    train_loss = np.mean(train_losses)
    val_loss = np.mean(val_losses)

    # Update learning rate scheduler
    scheduler.step(val_loss)

    # Print training progress
    print(f"Epoch {epoch + 1:03d} | Train Loss: {train_loss:.6f} | Val Loss: {val_loss:.6f}")

    # Early stopping and model saving
    if val_loss < best_val_loss:
        best_val_loss = val_loss
        patience = 0
        torch.save(model.state_dict(), "best_cnn_lstm.pth")  # Save best model weights
    else:
        patience += 1
        if patience >= max_patience:
            print("Early stopping triggered (no validation loss improvement for {} epochs).".format(max_patience))
            break

# ===============================
# Residual Prediction & Final Correction
# ===============================
# Load best model weights for inference
model.load_state_dict(torch.load("best_cnn_lstm.pth"))
model.eval()  # Set model to evaluation mode

# Initialize arrays to store predicted residuals and count of predictions per time step
predicted_residuals = np.zeros_like(residuals)
count_matrix = np.zeros_like(residuals)

with torch.no_grad():  # Disable gradient computation
    # Iterate through time series to predict residuals
    for i in range(len(residuals) - input_len):
        # Extract input sequence (past 'input_len' residuals)
        seq = residuals[i:i + input_len]
        # Normalize sequence using precomputed mean/std
        seq_norm = (seq - mean_resid) / std_resid
        # Convert to tensor (add batch and channel dimensions)
        input_tensor = torch.tensor(seq_norm, dtype=torch.float32).unsqueeze(0).unsqueeze(-1).to(device)

        # Create time embedding for the current sequence's end date
        start_date = pd.to_datetime("1950-01") + pd.DateOffset(months=i)
        time_emb_np = add_time_embedding(1, start_year=start_date.strftime('%Y-%m'))[0]
        time_emb = torch.tensor(time_emb_np, dtype=torch.float32).unsqueeze(0).to(device)

        # Predict normalized residual and denormalize
        pred_norm = model(input_tensor, time_emb).cpu().numpy()
        pred = pred_norm * y_std + y_mean

        # Assign prediction to the corresponding time step
        predicted_residuals[i + input_len] += pred
        count_matrix[i + input_len] += 1

# Handle time steps with no predictions (set count to 1 to avoid division by zero)
count_matrix[count_matrix == 0] = 1
# Average predictions for time steps with multiple predictions (edge cases)
predicted_residuals /= count_matrix

# Final correction: QM-corrected data + CNN-LSTM predicted residuals
sim_corrected = sim_qm + predicted_residuals


# ===============================
# Model Evaluation
# ===============================
def evaluate(y_true, y_pred):
    """
    Calculate evaluation metrics for regression: RMSE, MAE, and Pearson correlation.

    Parameters:
        y_true: True values (observed data)
        y_pred: Predicted values (corrected data)

    Returns:
        rmse: Root Mean Squared Error
        mae: Mean Absolute Error
        corr: Pearson correlation coefficient
    """
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mae = mean_absolute_error(y_true, y_pred)
    corr, _ = pearsonr(y_true, y_pred)  # _ = p-value (not used here)
    return rmse, mae, corr


# Evaluate QM-only and QM+CNN-LSTM correction
rmse_qm, mae_qm, corr_qm = evaluate(obs, sim_qm)
rmse_corr, mae_corr, corr_corr = evaluate(obs, sim_corrected)

# Print evaluation results
print("\n=== Evaluation Metrics (1950-2014) ===")
print(f"QM Corrected       | RMSE: {rmse_qm:.3f}, MAE: {mae_qm:.3f}, Corr: {corr_qm:.3f}")
print(f"QM + CNN-LSTM Corrected | RMSE: {rmse_corr:.3f}, MAE: {mae_corr:.3f}, Corr: {corr_corr:.3f}")


# ===============================
# Visualization
# ===============================
# ===== Mean Seasonal Cycle Plot =====
def mean_seasonal_cycle(data, start_year="1950-01"):
    """Calculate mean seasonal cycle (average for each calendar month across years)."""
    dates = pd.date_range(start=start_year, periods=len(data), freq="MS")
    df = pd.DataFrame({'value': data}, index=dates)
    monthly_mean = df.groupby(df.index.month).mean()  # Group by month (1-12) and average
    return monthly_mean.values


# Compute seasonal cycles for raw, corrected, and observed data
sim_raw_cycle = mean_seasonal_cycle(sim_raw)
sim_corrected_cycle = mean_seasonal_cycle(sim_corrected)
obs_cycle = mean_seasonal_cycle(obs)

# Plot seasonal cycle
plt.figure(figsize=(10, 5))
plt.plot(np.arange(1, 13), sim_raw_cycle, label='CMIP6 Raw', marker='o', alpha=0.7)
plt.plot(np.arange(1, 13), sim_corrected_cycle, label='QM + CNN-LSTM Corrected', marker='o', linewidth=2)
plt.plot(np.arange(1, 13), obs_cycle, label='ERA5 Observed', marker='o', linewidth=2, color='orange')

# Customize plot
plt.xticks(np.arange(1, 13), ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
                              'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])
plt.xlabel("Month")
plt.ylabel("Precipitation (mm/day)")
plt.title("Mean Seasonal Cycle of Monthly Precipitation (1950-2014)")
plt.legend(loc='best')
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()

# ===== Precipitation Distribution Histogram =====
plt.figure(figsize=(12, 5))
n = len(obs)  # Ensure consistent length across datasets
# Plot histograms with transparency to compare distributions
plt.hist(sim_raw[:n].flatten(), bins=50, alpha=0.5, label='Raw CMIP6', color='blue')
plt.hist(sim_corrected[:n].flatten(), bins=50, alpha=0.5, label='QM+CNN-LSTM Corrected', color='green')
plt.hist(obs.flatten(), bins=50, alpha=0.5, label='ERA5 Observed', color='orange')

# Customize plot
plt.xlabel('Precipitation (mm/day)')
plt.ylabel('Frequency (Number of Months)')
plt.title("Distribution of Monthly Precipitation (1950-2014)")
plt.legend()
plt.tight_layout()
plt.show()

# ===== Simulated vs Observed Scatter Plot =====
plt.figure(figsize=(6, 6))
# Plot scatter points for raw, QM-only, and QM+CNN-LSTM data
plt.scatter(obs, sim_raw, alpha=0.3, label='Raw CMIP6', color='blue')
plt.scatter(obs, sim_qm, alpha=0.3, label='QM-Only', color='green')
plt.scatter(obs, sim_corrected, alpha=0.3, label='QM+CNN-LSTM', color='red')
# Add 1:1 line (perfect agreement between simulated and observed)
plt.plot([obs.min(), obs.max()], [obs.min(), obs.max()], 'k--', lw=2, label='1:1 Line')

# Customize plot
plt.xlabel('Observed Precipitation (mm/day)')
plt.ylabel('Simulated Precipitation (mm/day)')
plt.title('Simulated vs Observed Monthly Precipitation (1950-2014)')
plt.legend(loc='best')
plt.tight_layout()
plt.show()