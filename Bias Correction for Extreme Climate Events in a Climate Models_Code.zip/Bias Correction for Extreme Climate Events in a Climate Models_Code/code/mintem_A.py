import xarray as xr
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER

# ----------------------------
# Step 1: Load Data
# ----------------------------
# File paths
ERA5_tasmin1 = 'mn2t.nc'
ERA5_tasmin2 = 'mn2t_1.nc'
CMIP6_tasmin = 'CMIP6_tasmin.nc'

# Load ERA5 datasets
ds1 = xr.open_dataset(ERA5_tasmin1, chunks={'valid_time': 100})
ds2 = xr.open_dataset(ERA5_tasmin2, chunks={'valid_time': 100})

# Concatenate and sort ERA5 datasets along time dimension
ds_era5 = xr.concat([ds1, ds2], dim="valid_time")
ds_era5 = ds_era5.sortby("valid_time")

# Load CMIP6
ds_cmip6 = xr.open_dataset(CMIP6_tasmin, chunks={'time': 100})  # Note: CMIP6 time dimension is typically 'time'

# Print time ranges
print("CMIP6 time range:", ds_cmip6.time.min().values, "to", ds_cmip6.time.max().values)
print("ERA5 time range:", ds_era5.valid_time.min().values, "to", ds_era5.valid_time.max().values)

# ----------------------------
# Step 2: Extract variables and unit conversion
# ----------------------------
# Unit conversion: Kelvin (K) to Celsius (℃)
tasmin_era5 = ds_era5['mn2t'] - 273.15  # ERA5 minimum temperature variable
tasmin_cmip6 = ds_cmip6['tasmin'] - 273.15  # CMIP6 minimum temperature variable

# Print longitude ranges for verification
print("ERA5 lon range:", tasmin_era5.longitude.min().values, "to", tasmin_era5.longitude.max().values)
print("CMIP6 lon range:", tasmin_cmip6.lon.min().values, "to", tasmin_cmip6.lon.max().values)

# ----------------------------
# Step 3: Data Preprocessing
# ----------------------------
# Standardize coordinate names
tasmin_era5 = tasmin_era5.rename({
    'latitude': 'lat',
    'longitude': 'lon',
    'valid_time': 'time'
})

# Handle missing values and outliers (set reasonable range based on study area climate)
# Reasonable minimum temperature range for study area: -50℃ ~ 30℃
tasmin_cmip6 = tasmin_cmip6.where((tasmin_cmip6 >= -50) & (tasmin_cmip6 <= 30))
tasmin_era5 = tasmin_era5.where((tasmin_era5 >= -50) & (tasmin_era5 <= 30))

# ----------------------------
# Step 4: Temporal and Spatial Subsetting (1950-2014)
# ----------------------------
lat_min, lat_max = 25, 50
lon_min, lon_max = -125, -66
lon_min_conv, lon_max_conv = lon_min + 360, lon_max + 360  # Convert west longitude to east longitude

# Subset CMIP6 data
cmip6_crop = tasmin_cmip6.sel(
    time=slice("1950", "2014"),
    lat=slice(lat_min, lat_max),
    lon=slice(lon_min_conv, lon_max_conv)
)

# Subset ERA5 data (note: latitude may be in descending order)
era5_crop = tasmin_era5.sel(
    time=slice("1950", "2014"),
    lat=slice(lat_max, lat_min),  # Reverse latitude order for consistency
    lon=slice(lon_min_conv, lon_max_conv)
)

# Verify subsetted data
print("\nCMIP6 Subsetted Data Check:")
print(f"Number of valid data points: {cmip6_crop.count().values}")
print(f"Subsetted time range: {cmip6_crop.time.min().values} ~ {cmip6_crop.time.max().values}")
print(f"Subsetted latitude range: {cmip6_crop.lat.min().values} ~ {cmip6_crop.lat.max().values}")
print(f"Subsetted longitude range: {cmip6_crop.lon.min().values} ~ {cmip6_crop.lon.max().values}")

print("\nERA5 Subsetted Data Check:")
print(f"Number of valid data points: {era5_crop.count().values}")
print(f"Subsetted time range: {era5_crop.time.min().values} ~ {era5_crop.time.max().values}")
print(f"Subsetted latitude range: {era5_crop.lat.min().values} ~ {era5_crop.lat.max().values}")
print(f"Subsetted longitude range: {era5_crop.lon.min().values} ~ {era5_crop.lon.max().values}")

# ----------------------------
# Step 5: Temporal Alignment (by year-month)
# ----------------------------
# Add year-month identifier
cmip6_crop = cmip6_crop.assign_coords(
    year_month=cmip6_crop.time.dt.strftime('%Y-%m')
)
era5_crop = era5_crop.assign_coords(
    year_month=era5_crop.time.dt.strftime('%Y-%m')
)

# Find common year-months
common_years_months = np.intersect1d(
    cmip6_crop.year_month.values,
    era5_crop.year_month.values
)
print(f"\nNumber of common year-months: {len(common_years_months)}")

# Filter data by common year-months
cmip6_aligned = cmip6_crop.sel(
    time=[t for t, ym in zip(cmip6_crop.time.values, cmip6_crop.year_month.values)
          if ym in common_years_months]
)
era5_aligned = era5_crop.sel(
    time=[t for t, ym in zip(era5_crop.time.values, era5_crop.year_month.values)
          if ym in common_years_months]
)

# Verify aligned data
print(f"Valid data points after CMIP6 alignment: {cmip6_aligned.count().values}")
print(f"Valid data points after ERA5 alignment: {era5_aligned.count().values}")

# ----------------------------
# Step 6: Spatial Alignment
# ----------------------------
# Print grid information
print(f"\nCMIP6 grid: {len(cmip6_aligned.lat)} latitude points, {len(cmip6_aligned.lon)} longitude points")
print(f"ERA5 grid: {len(era5_aligned.lat)} latitude points, {len(era5_aligned.lon)} longitude points")

# Select high-resolution grid as target
if len(cmip6_aligned.lat) > len(era5_aligned.lat):
    target_lat = cmip6_aligned.lat
    target_lon = cmip6_aligned.lon
    era5_aligned = era5_aligned.interp(lat=target_lat, lon=target_lon, method='linear')
else:
    target_lat = era5_aligned.lat
    target_lon = era5_aligned.lon
    cmip6_aligned = cmip6_aligned.interp(lat=target_lat, lon=target_lon, method='linear')

print(f"Aligned grid: {len(target_lat)} latitude points, {len(target_lon)} longitude points")

# ----------------------------
# Step 7: Bias Correction
# ----------------------------
# Calculate time-averaged bias
bias = cmip6_aligned.mean(dim='time') - era5_aligned.mean(dim='time')

# Apply bias correction
cmip6_corrected = cmip6_aligned - bias

# Calculate time-averaged values for plotting
cmip6_mean = cmip6_aligned.mean(dim='time')
cmip6_corrected_mean = cmip6_corrected.mean(dim='time')
era5_mean = era5_aligned.mean(dim='time')

# Verify data range for plotting
print("\nPlotting Data Statistics:")
print(f"CMIP6 mean minimum temperature: {cmip6_mean.min().values:.2f}~{cmip6_mean.max().values:.2f} ℃")
print(f"ERA5 mean minimum temperature: {era5_mean.min().values:.2f}~{era5_mean.max().values:.2f} ℃")

# ----------------------------
# Step 8: Plot Spatial Distributions (each subplot has its own colorbar)
# ----------------------------
plot_extent = [lon_min, lon_max, lat_min, lat_max]

fig = plt.figure(figsize=(16, 14))

# 1. Original CMIP6 Mean Minimum Temperature
ax1 = fig.add_subplot(2, 2, 1, projection=ccrs.PlateCarree())
ax1.set_extent(plot_extent, crs=ccrs.PlateCarree())
im1 = ax1.contourf(
    cmip6_mean.lon - 360,  # Convert east longitude back to west longitude
    cmip6_mean.lat,
    cmip6_mean,
    levels=np.linspace(-20, 25, 11),
    cmap='YlOrRd',
    extend='both'
)
ax1.coastlines(resolution='50m', linewidth=0.8)
ax1.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax1.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False  # Hide top latitude labels
gl.right_labels = False  # Hide right longitude labels
gl.xformatter = LONGITUDE_FORMATTER  # Format longitude labels
gl.yformatter = LATITUDE_FORMATTER  # Format latitude labels
ax1.set_title('(a) Original CMIP6 Mean Minimum Temperature (℃)', fontsize=12)
plt.colorbar(im1, ax=ax1, orientation='vertical', label='Temperature (℃)')

# 2. ERA5 Observed Mean Minimum Temperature
ax2 = fig.add_subplot(2, 2, 2, projection=ccrs.PlateCarree())
ax2.set_extent(plot_extent, crs=ccrs.PlateCarree())
im2 = ax2.contourf(
    era5_mean.lon - 360,  # Convert east longitude back to west longitude
    era5_mean.lat,
    era5_mean,
    levels=np.linspace(-20, 25, 11),
    cmap='YlOrRd',
    extend='both'
)
ax2.coastlines(resolution='50m', linewidth=0.8)
ax2.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax2.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False
gl.right_labels = False
gl.xformatter = LONGITUDE_FORMATTER
gl.yformatter = LATITUDE_FORMATTER
ax2.set_title('(b) ERA5 Observed Mean Minimum Temperature (℃)', fontsize=12)
plt.colorbar(im2, ax=ax2, orientation='vertical', label='Temperature (℃)')

# 3. CMIP6 Bias
ax3 = fig.add_subplot(2, 2, 3, projection=ccrs.PlateCarree())
ax3.set_extent(plot_extent, crs=ccrs.PlateCarree())
bias_min = np.nanmin(bias.values)
bias_max = np.nanmax(bias.values)
bias_levels = np.linspace(np.floor(bias_min), np.ceil(bias_max), 11)
im3 = ax3.contourf(
    bias.lon - 360,  # Convert east longitude back to west longitude
    bias.lat,
    bias,
    levels=bias_levels,
    cmap='RdBu_r',
    extend='both'
)
ax3.coastlines(resolution='50m', linewidth=0.8)
ax3.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax3.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False
gl.right_labels = False
gl.xformatter = LONGITUDE_FORMATTER
gl.yformatter = LATITUDE_FORMATTER
ax3.set_title('(c) CMIP6 Bias (CMIP6 - ERA5) (℃)', fontsize=12)
plt.colorbar(im3, ax=ax3, orientation='vertical', label='Bias (℃)')

# 4. Bias-Corrected CMIP6 Mean Minimum Temperature
ax4 = fig.add_subplot(2, 2, 4, projection=ccrs.PlateCarree())
ax4.set_extent(plot_extent, crs=ccrs.PlateCarree())
im4 = ax4.contourf(
    cmip6_corrected_mean.lon - 360,  # Convert east longitude back to west longitude
    cmip6_corrected_mean.lat,
    cmip6_corrected_mean,
    levels=np.linspace(-20, 25, 11),
    cmap='YlOrRd',
    extend='both'
)
ax4.coastlines(resolution='50m', linewidth=0.8)
ax4.add_feature(cfeature.BORDERS, linewidth=0.6)
gl = ax4.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                   linewidth=0.5, color='gray', linestyle='--')
gl.top_labels = False
gl.right_labels = False
gl.xformatter = LONGITUDE_FORMATTER
gl.yformatter = LATITUDE_FORMATTER
ax4.set_title('(d) Bias-Corrected CMIP6 Mean Minimum Temperature (℃)', fontsize=12)
plt.colorbar(im4, ax=ax4, orientation='vertical', label='Temperature (℃)')

plt.tight_layout()
plt.savefig('cmip6_tasmin_bias_correction_1950-2014_colorbars.png', dpi=300, bbox_inches='tight')
plt.show()