import xarray as xr
import numpy as np
import torch
import torch.nn as nn
from scipy.interpolate import interp1d
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

# ========================================
# 1️⃣ Load future data (example single point)
# ========================================
ds_tasmax = xr.open_dataset("tasmax_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc")
ds_tasmin = xr.open_dataset("tasmin_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc")
ds_rsds   = xr.open_dataset("rsds_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc")
ds_hurs   = xr.open_dataset("hurs_Amon_CanESM5_ssp245_r1i1p1f1_gn_20150116-20491216.nc")

lat_sel, lon_sel = 30, 120

tasmax_future_K = ds_tasmax['tasmax'].sel(lat=lat_sel, lon=lon_sel, method='nearest').values
tasmin_future_K = ds_tasmin['tasmin'].sel(lat=lat_sel, lon=lon_sel, method='nearest').values
rsds_future     = ds_rsds['rsds'].sel(lat=lat_sel, lon=lon_sel, method='nearest').values
hurs_future     = ds_hurs['hurs'].sel(lat=lat_sel, lon=lon_sel, method='nearest').values

# Convert to Celsius
tasmax_future = tasmax_future_K - 273.15
tasmin_future = tasmin_future_K - 273.15

# ========================================
# 2️⃣ Generate sample historical obs / sim
# ========================================
np.random.seed(0)
N_hist = 1000

obs_vars = {
    'tasmax': np.random.normal(30, 5, N_hist),
    'tasmin': np.random.normal(20, 4, N_hist),
    'rsds':   np.random.normal(200, 50, N_hist),
    'hurs':   np.random.normal(60, 10, N_hist),
}

sim_vars = {
    'tasmax': obs_vars['tasmax'] + np.random.normal(0, 2, N_hist),
    'tasmin': obs_vars['tasmin'] + np.random.normal(0, 2, N_hist),
    'rsds':   obs_vars['rsds'] + np.random.normal(0, 20, N_hist),
    'hurs':   obs_vars['hurs'] + np.random.normal(0, 5, N_hist),
}

# ========================================
# 3️⃣ Quantile Mapping (QM)
# ========================================
def quantile_mapping(obs, sim, target):
    quantiles = np.linspace(0, 1, 1001)
    obs_q = np.quantile(obs, quantiles)
    sim_q = np.quantile(sim, quantiles)
    sim_q_unique, idx = np.unique(sim_q, return_index=True)
    obs_q_unique = obs_q[idx]
    qm_func = interp1d(sim_q_unique, obs_q_unique, bounds_error=False, fill_value="extrapolate")
    return qm_func(target)

def qm_correct_all(obs_vars, sim_vars, future_vars):
    corrected = {}
    for key in obs_vars.keys():
        corrected[key] = quantile_mapping(obs_vars[key], sim_vars[key], future_vars[key])
    return corrected

future_vars = {
    'tasmax': tasmax_future,
    'tasmin': tasmin_future,
    'rsds': rsds_future,
    'hurs': hurs_future
}

qm_corrected = qm_correct_all(obs_vars, sim_vars, future_vars)

# ========================================
# 4️⃣ CNN-LSTM Model
# ========================================
class CNN_LSTM_Enhanced(nn.Module):
    def __init__(self, input_dim=4, cnn_channels=64, lstm_hidden=128, time_emb_dim=4, dropout=0.3):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv1d(input_dim, cnn_channels, kernel_size=3, padding=1),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Conv1d(cnn_channels, cnn_channels, kernel_size=3, padding=1),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.lstm = nn.LSTM(cnn_channels, lstm_hidden, batch_first=True)
        self.fc = nn.Sequential(
            nn.Linear(lstm_hidden + time_emb_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 4)  # residuals for 4 variables
        )

    def forward(self, x, time_emb):
        x = x.permute(0, 2, 1)  # [B, input_dim, seq_len]
        x = self.cnn(x).permute(0, 2, 1)  # [B, seq_len, channels]
        _, (h_n, _) = self.lstm(x)
        h_last = h_n[-1]
        combined = torch.cat([h_last, time_emb], dim=1)
        return self.fc(combined)

# ========================================
# 5️⃣ Prepare residual training data
# ========================================
def create_multivariate_sequences(data_dict, seq_len=30):
    keys = list(data_dict.keys())
    length = len(data_dict[keys[0]])
    X, y = [], []
    for i in range(length - seq_len):
        seq = np.stack([data_dict[k][i:i+seq_len] for k in keys], axis=1)
        target = np.array([data_dict[k][i+seq_len] for k in keys])
        X.append(seq)
        y.append(target)
    return np.array(X), np.array(y)

residuals = {k: obs_vars[k] - quantile_mapping(obs_vars[k], sim_vars[k], sim_vars[k]) for k in obs_vars.keys()}

X_train, y_train = create_multivariate_sequences(residuals, seq_len=30)
time_emb_train = np.random.normal(0, 1, (X_train.shape[0], 4))

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
X_train = torch.tensor(X_train, dtype=torch.float32).to(device)
y_train = torch.tensor(y_train, dtype=torch.float32).to(device)
time_emb_train = torch.tensor(time_emb_train, dtype=torch.float32).to(device)

# ========================================
# 6️⃣ Train the model
# ========================================
model = CNN_LSTM_Enhanced(input_dim=4).to(device)
criterion = nn.MSELoss()
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)

model.train()
for epoch in range(5):
    optimizer.zero_grad()
    output = model(X_train, time_emb_train)
    loss = criterion(output, y_train)
    loss.backward()
    optimizer.step()
    print(f"Epoch {epoch+1}, Loss={loss.item():.4f}")

# ========================================
# 7️⃣ Predict future residuals and correct
# ========================================
X_future, _ = create_multivariate_sequences(qm_corrected, seq_len=30)
time_emb_future = np.random.normal(0, 1, (X_future.shape[0], 4))

X_future = torch.tensor(X_future, dtype=torch.float32).to(device)
time_emb_future = torch.tensor(time_emb_future, dtype=torch.float32).to(device)

model.eval()
with torch.no_grad():
    residuals_future = model(X_future, time_emb_future).cpu().numpy()

keys = list(qm_corrected.keys())
corrected_future = {}
for i, k in enumerate(keys):
    corrected_future[k] = qm_corrected[k][30:] + residuals_future[:, i]

# ========================================
# 8️⃣ Simplified WBGT calculation
# ========================================
def calc_wbgt(tasmax, tasmin, hurs, rsds):
    # Simple wet-bulb temperature: Twb ≈ Tmean * RH^0.125
    Tmean = (tasmax + tasmin) / 2
    Twb = Tmean * (hurs / 100) ** 0.125
    # Approximate WBGT
    wbgt = 0.7 * Twb + 0.2 * (rsds / 100) + 0.1 * Tmean
    return wbgt

wbgt = calc_wbgt(corrected_future['tasmax'], corrected_future['tasmin'],
                 corrected_future['hurs'], corrected_future['rsds'])

threshold_wbgt = 32
threshold_tasmax = 35

heatwave_days = (wbgt > threshold_wbgt) | (corrected_future['tasmax'] > threshold_tasmax)

max_streak, current_streak = 0, 0
for day in heatwave_days:
    if day:
        current_streak += 1
        max_streak = max(max_streak, current_streak)
    else:
        current_streak = 0

print(f"The maximum number of consecutive heatwave days in the future: {max_streak}")

# ========================================
# 9️⃣ Visualization
# ========================================
start_date = pd.to_datetime('2015-01-01')
periods = len(corrected_future['tasmax'])  # future data length
date_index = pd.date_range(start=start_date, periods=periods, freq='M')

# -------------- Heatwave streak histogram --------------
def calc_heatwave_streaks(heatwave_days):
    streaks = []
    current_streak = 0
    for day in heatwave_days:
        if day:
            current_streak += 1
        else:
            if current_streak > 0:
                streaks.append(current_streak)
            current_streak = 0
    if current_streak > 0:
        streaks.append(current_streak)
    return streaks

# Boolean array of future heatwave days
heatwave_days_array = heatwave_days  # (numpy bool array)

streaks_future = calc_heatwave_streaks(heatwave_days_array)


# -------------- Interannual Variation Plot --------------
# Infer years from monthly data
date_index_full = pd.date_range(start=start_date, periods=len(corrected_future['tasmax']), freq='M')
df_future = pd.DataFrame({
    'tasmax': corrected_future['tasmax'],
    'wbgt': wbgt,
    'heatwave': heatwave_days_array
}, index=date_index_full)

df_future['year'] = df_future.index.year

# Count annual heatwave days
annual_heatwave_days = df_future.groupby('year')['heatwave'].sum()

# Calculate annual maximum tasmax and WBGT
annual_max_tasmax = df_future.groupby('year')['tasmax'].max()
annual_max_wbgt = df_future.groupby('year')['wbgt'].max()

# ===============================
# 🔍 Heatwave Metrics Evaluation Function
# ===============================
def calculate_heatwave_metrics(tasmax, wbgt, threshold_tasmax=35, threshold_wbgt=32, min_duration=3):
    """
    Calculate heatwave-related metrics
    Heatwave condition: tasmax > threshold_tasmax OR wbgt > threshold_wbgt,
    lasting longer than min_duration days
    """
    heatwave_days = (tasmax > threshold_tasmax) | (wbgt > threshold_wbgt)
    heatwave_days = heatwave_days.astype(int)

    # Iterate through to calculate consecutive heatwave periods
    streaks = []
    streak_magnitudes = []
    current_streak = 0
    current_magnitude = 0

    for i in range(len(heatwave_days)):
        if heatwave_days[i] == 1:
            current_streak += 1
            current_magnitude += tasmax[i]  # Use tasmax to calculate intensity
        else:
            if current_streak >= min_duration:
                streaks.append(current_streak)
                streak_magnitudes.append(current_magnitude / current_streak)
            current_streak = 0
            current_magnitude = 0

    # If the last segment is a heatwave
    if current_streak >= min_duration:
        streaks.append(current_streak)
        streak_magnitudes.append(current_magnitude / current_streak)

    # Calculate metrics
    HWN = len(streaks)  # Number of heatwave events
    HWF = sum(streaks)  # Total heatwave days
    HWD = max(streaks) if streaks else 0  # Longest consecutive heatwave days
    HWM = np.mean(streak_magnitudes) if streak_magnitudes else 0  # Average intensity

    return {
        "HWN": HWN,
        "HWF": HWF,
        "HWD": HWD,
        "HWM": HWM
    }

# ===============================
# 🔄 Calculate Heatwave Metrics for QM and Deep Correction
# ===============================
metrics_qm = calculate_heatwave_metrics(
    tasmax=qm_corrected['tasmax'],
    wbgt=calc_wbgt(qm_corrected['tasmax'], qm_corrected['tasmin'], qm_corrected['hurs'], qm_corrected['rsds'])
)

metrics_dl = calculate_heatwave_metrics(
    tasmax=corrected_future['tasmax'],
    wbgt=wbgt
)

# ===============================
# 📊 Generate Comparison Table
# ===============================
df_heatwave_eval = pd.DataFrame([metrics_qm, metrics_dl], index=['QM', 'Deep Correction'])
print(df_heatwave_eval)

# ========================================
# 4.3.2.2 Duration and Seasonality - Before vs After Correction
# ========================================

# -------------------------------
# 1️⃣ Function: Extract heatwave duration and start month
def extract_heatwave_duration_season(df, bool_col='heatwave'):
    durations = []
    months = []

    heatwave_series = df[bool_col].values
    dates = df.index

    current_streak = 0
    start_idx = None

    for i, val in enumerate(heatwave_series):
        if val:
            if current_streak == 0:
                start_idx = i
            current_streak += 1
        else:
            if current_streak > 0:
                durations.append(current_streak)
                months.append(dates[start_idx].month)
                current_streak = 0
    if current_streak > 0:  # Last heatwave segment
        durations.append(current_streak)
        months.append(dates[start_idx].month)

    return np.array(durations), np.array(months)

# -------------------------------
# 2️⃣ Prepare DataFrames
# Raw future simulation data (before QM)
wbgt_raw = calc_wbgt(future_vars['tasmax'], future_vars['tasmin'],
                      future_vars['hurs'], future_vars['rsds'])
heatwave_days_raw = ((future_vars['tasmax'] > threshold_tasmax) |
                     (wbgt_raw > threshold_wbgt)).astype(int)
df_raw = pd.DataFrame({'heatwave': heatwave_days_raw},
                      index=pd.date_range(start=start_date, periods=len(future_vars['tasmax']), freq='M'))

# Corrected future data (QM + CNN-LSTM)
df_corrected = pd.DataFrame({'heatwave': heatwave_days_array},
                            index=pd.date_range(start=start_date + pd.DateOffset(months=30),
                                                periods=len(corrected_future['tasmax']), freq='M'))

# -------------------------------
# 3️⃣ Extract heatwave duration and month
dur_raw, month_raw = extract_heatwave_duration_season(df_raw)
dur_corrected, month_corrected = extract_heatwave_duration_season(df_corrected)

# -------------------------------
# 4️⃣ Plotting
fig, axes = plt.subplots(1, 2, figsize=(14,6))

# Duration distribution
sns.histplot(dur_raw, bins=range(1, max(dur_raw)+2), color='skyblue', label='Raw', stat='probability', ax=axes[0])
sns.histplot(dur_corrected, bins=range(1, max(dur_corrected)+2), color='tomato', label='QM + CNN-LSTM', stat='probability', ax=axes[0])
axes[0].set_xlabel('Heatwave Duration (months)')
axes[0].set_ylabel('Probability')
axes[0].set_title('Heatwave Duration Distribution')
axes[0].legend()

# Seasonality (distribution of heatwave occurrence months)
sns.histplot(month_raw, bins=np.arange(1,14)-0.5, color='skyblue', label='Raw', stat='probability', ax=axes[1])
sns.histplot(month_corrected, bins=np.arange(1,14)-0.5, color='tomato', label='QM + CNN-LSTM', stat='probability', ax=axes[1])
axes[1].set_xlabel('Month')
axes[1].set_ylabel('Probability')
axes[1].set_xticks(range(1,13))
axes[1].set_title('Heatwave Seasonality')
axes[1].legend()

plt.tight_layout()
plt.show()

import matplotlib.pyplot as plt
import scipy.stats as stats
import numpy as np
import pandas as pd

# ===============================
# 1️⃣ Construct DataFrame
# ===============================
# Raw data
wbgt_raw = calc_wbgt(future_vars['tasmax'], future_vars['tasmin'],
                      future_vars['hurs'], future_vars['rsds'])
df_raw = pd.DataFrame({
    'tasmax': future_vars['tasmax'],
    'wbgt': wbgt_raw
})
df_raw['year'] = pd.date_range(start='2015-01-01', periods=len(future_vars['tasmax']), freq='M').year

# QM data
df_qm = pd.DataFrame({
    'tasmax': qm_corrected['tasmax'],
    'wbgt': calc_wbgt(qm_corrected['tasmax'], qm_corrected['tasmin'], qm_corrected['hurs'], qm_corrected['rsds'])
})
df_qm['year'] = pd.date_range(start='2015-01-01', periods=len(qm_corrected['tasmax']), freq='M').year

# QM+CNN-LSTM data (original Deep Correction)
df_dl = pd.DataFrame({
    'tasmax': corrected_future['tasmax'],
    'wbgt': wbgt
})
df_dl['year'] = pd.date_range(start='2015-01-01', periods=len(corrected_future['tasmax']), freq='M').year

# ===============================
# 2️⃣ Extract annual maximum consecutive heatwave days
# ===============================
def annual_heatwave_max(df, threshold_tasmax=35, threshold_wbgt=32):
    years = df['year'].unique()
    hwd_per_year = []
    for y in years:
        dfy = df[df['year'] == y]
        heatwave_days = ((dfy['tasmax']>threshold_tasmax) | (dfy['wbgt']>threshold_wbgt)).astype(int).values
        max_streak = 0
        current_streak = 0
        for day in heatwave_days:
            if day:
                current_streak += 1
                max_streak = max(max_streak, current_streak)
            else:
                current_streak = 0
        hwd_per_year.append(max_streak)
    return np.array(hwd_per_year)

hwd_raw = annual_heatwave_max(df_raw)
hwd_qm = annual_heatwave_max(df_qm)
hwd_qmcnn = annual_heatwave_max(df_dl)  # QM+CNN-LSTM

# ===============================
# 3️⃣ Fit GEV
# ===============================
c_raw, loc_raw, scale_raw = stats.genextreme.fit(hwd_raw)
c_qm, loc_qm, scale_qm = stats.genextreme.fit(hwd_qm)
c_qmcnn, loc_qmcnn, scale_qmcnn = stats.genextreme.fit(hwd_qmcnn)

print(f"Raw GEV params: shape={c_raw:.4f}, loc={loc_raw:.2f}, scale={scale_raw:.2f}")
print(f"QM GEV params: shape={c_qm:.4f}, loc={loc_qm:.2f}, scale={scale_qm:.2f}")
print(f"QM+CNN-LSTM GEV params: shape={c_qmcnn:.4f}, loc={loc_qmcnn:.2f}, scale={scale_qmcnn:.2f}")

# ===============================
# 4️⃣ Plot PDF comparison
# ===============================
x = np.linspace(min(hwd_raw.min(), hwd_qm.min(), hwd_qmcnn.min())-1,
                max(hwd_raw.max(), hwd_qm.max(), hwd_qmcnn.max())+1, 200)

pdf_raw = stats.genextreme.pdf(x, c_raw, loc=loc_raw, scale=scale_raw)
pdf_qm  = stats.genextreme.pdf(x, c_qm, loc=loc_qm, scale=scale_qm)
pdf_qmcnn  = stats.genextreme.pdf(x, c_qmcnn, loc=loc_qmcnn, scale=scale_qmcnn)

plt.figure(figsize=(10,6))
plt.hist(hwd_raw, bins=range(0, max(hwd_raw)+2), density=True, alpha=0.4, color='grey', label='Raw')
plt.hist(hwd_qm, bins=range(0, max(hwd_qm)+2), density=True, alpha=0.4, color='skyblue', label='QM')
plt.hist(hwd_qmcnn, bins=range(0, max(hwd_qmcnn)+2), density=True, alpha=0.4, color='tomato', label='QM+CNN-LSTM')
plt.plot(x, pdf_raw, 'k-', lw=2, label='Raw GEV Fit')
plt.plot(x, pdf_qm, 'b-', lw=2, label='QM GEV Fit')
plt.plot(x, pdf_qmcnn, 'r-', lw=2, label='QM+CNN-LSTM GEV Fit')
plt.xlabel('Annual Maximum Heatwave Duration (monthly)')
plt.ylabel('Density')
plt.title('GEV Fit Comparison of Heatwave Duration: Raw / QM / QM+CNN-LSTM (2015-2049)')
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)
plt.show()

# ===============================
# 5️⃣ Plot QQ plot
# ===============================
plt.figure(figsize=(6,6))

# Raw QQ
theoretical_q_raw = stats.genextreme.ppf(np.linspace(0.01,0.99,len(hwd_raw)), c_raw, loc=loc_raw, scale=scale_raw)
empirical_q_raw = np.quantile(hwd_raw, np.linspace(0.01,0.99,len(hwd_raw)))
plt.scatter(theoretical_q_raw, empirical_q_raw, color='grey', alpha=0.7, label='Raw')

# QM QQ
theoretical_q_qm = stats.genextreme.ppf(np.linspace(0.01,0.99,len(hwd_qm)), c_qm, loc=loc_qm, scale=scale_qm)
empirical_q_qm = np.quantile(hwd_qm, np.linspace(0.01,0.99,len(hwd_qm)))
plt.scatter(theoretical_q_qm, empirical_q_qm, color='blue', alpha=0.7, label='QM')

# QM+CNN-LSTM QQ
theoretical_q_qmcnn = stats.genextreme.ppf(np.linspace(0.01,0.99,len(hwd_qmcnn)), c_qmcnn, loc=loc_qmcnn, scale=scale_qmcnn)
empirical_q_qmcnn = np.quantile(hwd_qmcnn, np.linspace(0.01,0.99,len(hwd_qmcnn)))
plt.scatter(theoretical_q_qmcnn, empirical_q_qmcnn, color='red', alpha=0.7, label='QM+CNN-LSTM')

# 1:1 reference line
min_val = min(theoretical_q_raw.min(), theoretical_q_qm.min(), theoretical_q_qmcnn.min())
max_val = max(theoretical_q_raw.max(), theoretical_q_qm.max(), theoretical_q_qmcnn.max())
plt.plot([min_val, max_val], [min_val, max_val], 'k--', lw=2)
plt.xlabel('Theoretical Quantiles (GEV)')
plt.ylabel('Empirical Quantiles (Annual Max Heatwave Duration)')
plt.title('QQ Plot: Heatwave Duration - Raw / QM / QM+CNN-LSTM')
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)
plt.show()
