# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import xarray as xr
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from scipy.interpolate import interp1d
import calendar  # Added for month abbreviation handling


# =========================
# Utility Functions: Time and Calendar Handling
# =========================
def detect_time_dim(da: xr.DataArray) -> str:
    """Detect the time dimension name (common names: 'time' or 'valid_time')."""
    if "time" in da.dims:
        return "time"
    if "valid_time" in da.dims:
        return "valid_time"
    for d in da.dims:
        if "time" in d:
            return d
    raise ValueError(f"Time dimension not found. Dimensions available: {da.dims}")


def to_datetime_index(da: xr.DataArray, dim: str) -> pd.DatetimeIndex:
    """
    Convert the time dimension of an xarray DataArray to a pandas DatetimeIndex.
    Automatically handles cftime → standard calendar; uses align_on='date' for 360-day calendars.
    """
    # First attempt: Convert directly from existing index
    try:
        idx = da.indexes[dim]
        try:
            return pd.DatetimeIndex(idx.to_datetimeindex())
        except Exception:
            pass  # Fall back to calendar conversion if direct conversion fails
    except Exception:
        pass  # No existing index; proceed to calendar conversion

    # Check calendar type (for cftime adjustment)
    cal = None
    try:
        cal = getattr(da[dim].dt, "calendar", None)
    except Exception:
        pass  # Calendar attribute not available

    # Convert to standard calendar (handle 360-day calendar specifically)
    if cal == "360_day":
        da2 = da.convert_calendar("standard", use_cftime=False, dim=dim, align_on="date")
    else:
        da2 = da.convert_calendar("standard", use_cftime=False, dim=dim)

    # Convert to pandas DatetimeIndex
    return pd.to_datetime(da2[dim].values)


# =========================
# Monthly Seasonal Quantile Mapping (QM)
# =========================
def seasonal_qm_fit_apply(obs_vals, obs_dates, sim_vals, sim_dates, target_vals, target_dates, n_q=1001):
    """
    Fit monthly seasonal quantile mapping (QM) using overlapping ERA5 (observations) and
    future CMIP6 (simulations) data (2015–2025), then apply the QM correction to the full
    future CMIP6 period (2015–2049).

    Parameters:
        obs_vals: ERA5 observation values (1D array)
        obs_dates: DatetimeIndex for ERA5 observations
        sim_vals: CMIP6 simulation values (overlap period: 2015–2025)
        sim_dates: DatetimeIndex for CMIP6 overlap period
        target_vals: Full CMIP6 target values (2015–2049)
        target_dates: DatetimeIndex for full CMIP6 period
        n_q: Number of quantiles to use (default: 1001)

    Returns:
        out: QM-corrected full CMIP6 values (1D array)
    """
    out = np.empty_like(target_vals, dtype=float)
    # Apply QM separately for each calendar month (1–12)
    for m in range(1, 13):
        # Extract data for the current month
        o = np.asarray(obs_vals[obs_dates.month == m], float)  # ERA5 for month m
        s = np.asarray(sim_vals[sim_dates.month == m], float)  # CMIP6 overlap for month m
        t = np.asarray(target_vals[target_dates.month == m], float)  # Full CMIP6 for month m

        # Calculate quantiles (0 to 1)
        q = np.linspace(0, 1, n_q)
        o_q = np.quantile(o, q)  # Observed quantiles (ERA5)
        s_q = np.quantile(s, q)  # Simulated quantiles (CMIP6 overlap)

        # Remove duplicate quantiles to avoid interpolation errors
        s_q_u, idx = np.unique(s_q, return_index=True)
        o_q_u = o_q[idx]

        # Create interpolation function (map CMIP6 quantiles to ERA5 quantiles)
        f = interp1d(
            s_q_u, o_q_u,
            bounds_error=False,
            fill_value=(o_q_u[0], o_q_u[-1])  # Extrapolate with min/max for out-of-bounds values (more robust)
        )

        # Apply QM correction to the current month of target data
        out[target_dates.month == m] = f(t)
    return out


def make_sequences(arr, L=60):
    """
    Convert a 1D time series into input sequences for LSTM training.

    Parameters:
        arr: 1D time series array
        L: Length of each input sequence (default: 60 time steps)

    Returns:
        sequences: 2D array of shape (n_sequences, L)
    """
    arr = np.asarray(arr, float)
    return np.array([arr[i:i + L] for i in range(len(arr) - L)])


# =========================
# Simple CNN-LSTM Model
# =========================
class CNNLSTM(nn.Module):
    """Hybrid CNN-LSTM model for residual correction of QM-corrected precipitation data."""

    def __init__(self, input_len):
        super().__init__()
        # 1D CNN layer (extract local temporal features)
        self.conv1 = nn.Conv1d(1, 16, kernel_size=3, padding=1)
        self.relu = nn.ReLU()  # ReLU activation function
        # LSTM layer (capture long-term temporal dependencies)
        self.lstm = nn.LSTM(16, 32, batch_first=True)  # 16 input channels, 32 hidden units
        # Fully connected layer (output residual prediction)
        self.fc = nn.Linear(32, 1)
        self.input_len = input_len  # Length of input sequences

    def forward(self, x):
        """Forward pass of the CNN-LSTM model.

        Input shape: [batch_size, 1, input_len] (channel-first format)
        Output shape: [batch_size] (predicted residual for each batch sample)
        """
        # CNN layer: [batch_size, 1, input_len] → [batch_size, 16, input_len]
        x = self.relu(self.conv1(x))
        # Permute for LSTM: [batch_size, input_len, 16] (required for batch_first=True)
        x = x.permute(0, 2, 1)
        # LSTM layer: output shape → [batch_size, input_len, 32]
        x, _ = self.lstm(x)
        # Use only the last time step of LSTM output for prediction
        y = self.fc(x[:, -1, :])  # [batch_size, 1]
        return y.squeeze(1)  # Remove extra dimension → [batch_size]


# =========================
# Data Loading and Preprocessing (ERA5: 2015–2025; CMIP6 Future: 2015–2049)
# =========================
# Load datasets
era5_ds = xr.open_dataset("ERA5_tp.nc", chunks={'time': 10})  # ERA5 total precipitation
future_ds = xr.open_dataset("pr_20150115-20491215.nc", chunks={'time': 10})  # CMIP6 future precipitation

# Unit conversion
era5 = era5_ds["tp"] * 1000.0  # Convert ERA5 tp (meters) to mm/day
future = future_ds["pr"] * 86400.0  # Convert CMIP6 pr (kg m⁻² s⁻¹) to mm/day

# Standardize coordinate names and handle missing values/outliers
if "latitude" in era5.coords:
    era5 = era5.rename({"latitude": "lat", "longitude": "lon"})  # Align with CMIP6 coordinate names

# Mask missing values and extreme outliers
era5 = era5.where(np.isfinite(era5) & (era5 < 1e10))
future = future.where(np.isfinite(future) & (future < 1e10))

# Spatial subsetting (convert west longitude to east longitude: 0–360°)
lat_min, lat_max = 25, 50  # Latitude range (25°N to 50°N)
lon_min, lon_max = -125, -66  # Longitude range (-125°W to -66°W)
lon_min_c, lon_max_c = lon_min + 360, lon_max + 360  # Convert to 0–360°E

# Subset data (note: ERA5 latitude may be in descending order)
era5 = era5.sel(lat=slice(lat_max, lat_min), lon=slice(lon_min_c, lon_max_c))  # Reverse lat for ERA5
future = future.sel(lat=slice(lat_min, lat_max), lon=slice(lon_min_c, lon_max_c))

# Temporal subsetting
t_era5 = detect_time_dim(era5)  # Get ERA5 time dimension name
era5_2015_2025 = era5.sel({t_era5: slice("2015", "2025")})  # ERA5: 2015–2025
future_2015_2049 = future.sel(time=slice("2015", "2049"))  # CMIP6: 2015–2049

# Compute regional mean (spatial average) and resample to monthly frequency
era5_mon = era5_2015_2025.mean(dim=["lat", "lon"]).resample({t_era5: "1MS"}).mean()  # "1MS" = month-start
future_mon = future_2015_2049.mean(dim=["lat", "lon"]).resample(time="1MS").mean()

# Convert time coordinates to pandas DatetimeIndex
dates_era5 = to_datetime_index(era5_mon, t_era5)  # ERA5: 2015–2025
dates_future = to_datetime_index(future_mon, "time")  # CMIP6: 2015–2049

# Extract numerical values
obs_vals = era5_mon.values  # ERA5 monthly precipitation (2015–2025)
target_vals = future_mon.values  # CMIP6 monthly precipitation (2015–2049)

# CMIP6 subset for QM fitting (overlap period: 2015–2025)
future_mon_1525 = future_mon.sel(time=slice("2015", "2025"))
sim_vals = future_mon_1525.values  # CMIP6 overlap values
sim_dates = to_datetime_index(future_mon_1525, "time")  # CMIP6 overlap dates

# Safety check: Ensure overlap data exists
if len(obs_vals) == 0 or len(sim_vals) == 0:
    raise RuntimeError(
        "Insufficient monthly data for ERA5 or CMIP6 in the 2015–2025 overlap period. Cannot perform correction.")

# =========================
# Step 1: Monthly Seasonal QM (Fit: 2015–2025; Apply: 2015–2049)
# =========================
qm_future_all = seasonal_qm_fit_apply(
    obs_vals=obs_vals, obs_dates=dates_era5,
    sim_vals=sim_vals, sim_dates=sim_dates,
    target_vals=target_vals, target_dates=dates_future,
    n_q=1001
)
# Clip to non-negative values (precipitation cannot be negative)
qm_future_all = np.clip(qm_future_all, 0, None)

# =========================
# Step 2: Train CNN-LSTM on 2015–2025 Residuals, Apply to 2015–2049
# =========================
# Extract QM-corrected data for the overlap period (2015–2025)
mask_overlap = (dates_future >= dates_era5.min()) & (dates_future <= dates_era5.max())
qm_overlap = qm_future_all[mask_overlap]
dates_overlap = dates_future[mask_overlap]

# Calculate residuals (target: ERA5 - QM-corrected CMIP6)
# Align ERA5 and QM data by date (handle potential misalignment)
if len(qm_overlap) != len(obs_vals):
    # Inner join to align dates
    df_obs = pd.DataFrame({"date": dates_era5, "obs": obs_vals}).set_index("date")
    df_qm = pd.DataFrame({"date": dates_overlap, "qm": qm_overlap}).set_index("date")
    joined = df_obs.join(df_qm, how="inner")  # Keep only dates present in both
    obs_tr = joined["obs"].values  # Aligned ERA5 values
    qm_tr = joined["qm"].values  # Aligned QM values
else:
    # Dates are already aligned
    obs_tr = obs_vals
    qm_tr = qm_overlap

# Residuals: Observed (ERA5) - QM-corrected (CMIP6)
residuals_train = (obs_tr - qm_tr).astype(float)

# Generate training sequences
input_len = 60  # 5-year window (monthly data); increase if longer data is available (e.g., 120 for 10 years)
X_np = make_sequences(qm_tr, L=input_len)  # Input: QM-corrected sequences
y_np = residuals_train[input_len:]  # Target: Residual at next time step (after sequence)

# Normalize data (using only training data statistics to avoid data leakage)
x_mean, x_std = X_np.mean(), X_np.std() + 1e-8  # Add 1e-8 to avoid division by zero
Xn = (X_np - x_mean) / x_std  # Normalized inputs
y_mean, y_std = y_np.mean(), y_np.std() + 1e-8
yn = (y_np - y_mean) / y_std  # Normalized targets

# Convert to PyTorch tensors (add channel dimension for CNN)
X_tensor = torch.tensor(Xn, dtype=torch.float32).unsqueeze(1)  # Shape: [n_sequences, 1, input_len]
y_tensor = torch.tensor(yn, dtype=torch.float32)  # Shape: [n_sequences]

# Split into training (80%) and validation (20%) sets
n = len(X_tensor)
ntr = max(int(0.8 * n), 1)  # Ensure at least 1 training sample
X_tr, X_va = X_tensor[:ntr], X_tensor[ntr:]
y_tr, y_va = y_tensor[:ntr], y_tensor[ntr:]

# Create DataLoaders for batch processing
train_loader = DataLoader(TensorDataset(X_tr, y_tr), batch_size=64, shuffle=True)
val_loader = DataLoader(TensorDataset(X_va, y_va), batch_size=64) if len(X_va) > 0 else None

# Initialize model, optimizer, and loss function
model = CNNLSTM(input_len=input_len)
optimizer = optim.AdamW(
    model.parameters(),
    lr=1e-3,  # Initial learning rate
    weight_decay=1e-5  # L2 regularization to prevent overfitting
)
criterion = nn.MSELoss()  # Mean Squared Error for regression tasks

# Train model with early stopping
best_val_loss = np.inf  # Track the best validation loss
patience = 0  # Counter for early stopping
max_patience = 30  # Stop if no improvement for 30 epochs
num_epochs = 300  # Maximum number of epochs

for ep in range(num_epochs):
    # Training phase
    model.train()
    train_losses = []
    for bx, by in train_loader:
        optimizer.zero_grad()  # Reset gradients
        pred = model(bx)  # Forward pass
        loss = criterion(pred, by)  # Calculate loss
        loss.backward()  # Backpropagation
        # Gradient clipping to prevent exploding gradients
        nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()  # Update model weights
        train_losses.append(loss.item())

    # Validation phase
    if val_loader is not None:
        model.eval()
        val_losses = []
        with torch.no_grad():  # Disable gradient computation
            for bx, by in val_loader:
                val_losses.append(criterion(model(bx), by).item())
        val_loss = np.mean(val_losses)
    else:
        # No validation set: use training loss as proxy
        val_loss = np.mean(train_losses)

    train_loss = np.mean(train_losses)
    print(f"Epoch {ep + 1:03d} | Train Loss: {train_loss:.6f} | Val Loss: {val_loss:.6f}")

    # Save best model and check for early stopping
    if val_loss < best_val_loss - 1e-6:  # Improvement threshold (1e-6)
        best_val_loss = val_loss
        patience = 0
        torch.save(model.state_dict(), "best_cnn_lstm.pth")  # Save best weights
    else:
        patience += 1
        if patience >= max_patience:
            print("Early stopping triggered (no validation loss improvement).")
            break

# Load best model weights for inference
model.load_state_dict(torch.load("best_cnn_lstm.pth", map_location="cpu"))
model.eval()  # Set model to evaluation mode


def predict_residuals_on_series(qm_series, L, x_mean, x_std, y_mean, y_std, mdl):
    """
    Predict residuals for a full QM-corrected time series using the trained CNN-LSTM model.

    Parameters:
        qm_series: QM-corrected time series (1D array)
        L: Input sequence length (same as training)
        x_mean/x_std: Normalization parameters for inputs
        y_mean/y_std: Normalization parameters for outputs
        mdl: Trained CNN-LSTM model

    Returns:
        res: Predicted residuals (1D array, same length as qm_series)
    """
    qm_series = np.asarray(qm_series, float)
    res = np.zeros_like(qm_series)  # Store predicted residuals
    cnt = np.zeros_like(qm_series)  # Count predictions per time step (for averaging)

    with torch.no_grad():  # Disable gradient computation
        for i in range(len(qm_series) - L):
            # Extract input window
            window = qm_series[i:i + L]
            # Normalize window
            win_n = (window - x_mean) / x_std
            # Convert to tensor (add batch and channel dimensions)
            x = torch.tensor(win_n, dtype=torch.float32).unsqueeze(0).unsqueeze(1)  # [1, 1, L]
            # Predict normalized residual
            pred_n = mdl(x).cpu().numpy()[0]
            # Denormalize to original scale
            pred = pred_n * y_std + y_mean
            # Assign to the time step immediately after the window
            res[i + L] += pred
            cnt[i + L] += 1

    # Handle time steps with no predictions (set count to 1 to avoid division by zero)
    cnt[cnt == 0] = 1
    return res / cnt  # Average predictions (for overlapping windows, if any)


# Predict residuals for the full QM-corrected CMIP6 period (2015–2049)
pred_res_1549 = predict_residuals_on_series(
    qm_future_all, input_len, x_mean, x_std, y_mean, y_std, model
)

# Final correction: QM-corrected data + CNN-LSTM predicted residuals (clip to non-negative)
future_corrected_all = np.clip(qm_future_all + pred_res_1549, 0, None)

# =========================
# Plotting: 2015–2025 Comparison (ERA5 / Uncorrected CMIP6 / Corrected CMIP6)
# =========================
# Define time range for plotting (2015–2025)
start, end = pd.Timestamp("2015-01-01"), pd.Timestamp("2025-12-31")

# Extract ERA5 data (2015–2025)
mask_era = (dates_era5 >= start) & (dates_era5 <= end)
x_era, y_era = dates_era5[mask_era], obs_vals[mask_era]

# Extract uncorrected CMIP6 data (2015–2025)
mask_fu = (dates_future >= start) & (dates_future <= end)
x_unc, y_unc = dates_future[mask_fu], target_vals[mask_fu]

# Extract corrected CMIP6 data (2015–2025)
y_cor = future_corrected_all[mask_fu]


# ===== Calculate Mean Seasonal Cycle =====
def mean_seasonal_cycle(values, dates):
    """Calculate the average value for each calendar month (across years). Returns a 12-element array."""
    df = pd.DataFrame({"val": values}, index=dates)
    return df.groupby(df.index.month).mean().values


# Compute seasonal cycles for all three datasets
era5_cycle = mean_seasonal_cycle(y_era, x_era)
unc_cycle = mean_seasonal_cycle(y_unc, x_unc)
cor_cycle = mean_seasonal_cycle(y_cor, x_unc)  # Use x_unc (same dates as corrected data)

# Prepare month labels (Jan–Dec)
months = np.arange(1, 13)
month_names = [calendar.month_abbr[m] for m in months]  # 3-letter month abbreviations

# ===== Plot Mean Seasonal Cycle =====
plt.figure(figsize=(10, 5))
plt.plot(months, unc_cycle, label="CMIP6 Uncorrected", marker='o', alpha=0.7)
plt.plot(months, cor_cycle, label="CMIP6 Corrected (QM + CNN-LSTM)", marker='o', linewidth=2)
plt.plot(months, era5_cycle, label="ERA5 Observations", marker='o', linewidth=2, color='orange')

# Customize plot
plt.xticks(months, month_names)
plt.xlabel("Month")
plt.ylabel("Precipitation [mm/month]")
plt.title("Mean Seasonal Cycle of Monthly Precipitation (2015–2025)")
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend(loc='best')
plt.tight_layout()  # Adjust layout to prevent label cutoff
plt.show()

# ===== Plot Precipitation Distribution Histogram =====
plt.figure(figsize=(12, 5))

# Ensure all datasets have the same length (safety check)
n = len(obs_vals)
sim_raw = y_unc[:n].flatten()  # Uncorrected CMIP6
sim_corrected = y_cor[:n].flatten()  # Corrected CMIP6
obs = y_era.flatten()  # ERA5

# Plot histograms with transparency
plt.hist(sim_raw, bins=50, alpha=0.5, label='CMIP6 Uncorrected', color='blue')
plt.hist(sim_corrected, bins=50, alpha=0.7, label='CMIP6 Corrected (QM + CNN-LSTM)', color='green')
plt.hist(obs, bins=50, alpha=0.5, label='ERA5 Observations', color='orange')

# Customize plot
plt.xlabel('Precipitation (mm/month)')
plt.ylabel('Frequency (Number of Months)')
plt.title("Distribution of Monthly Precipitation (2015–2025)")
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend(loc='upper right')
plt.tight_layout()
plt.show()