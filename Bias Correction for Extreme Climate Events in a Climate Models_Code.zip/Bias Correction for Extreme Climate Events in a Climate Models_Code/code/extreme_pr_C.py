import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER
import pandas as pd


# ----------------------------
# 1. Data Loading and Preprocessing
# ----------------------------
def load_and_align_data():
    # Load datasets
    future_ds = xr.open_dataset("pr_20150115-20491215.nc", chunks={"time": 10})  # Future model data
    era5 = xr.open_dataset("ERA5_tp.nc", chunks={"time": 10})  # ERA5 observational data

    # Unit conversion
    future_raw = future_ds['pr'] * 86400  # Convert from kg/m²/s to mm/day
    era5_pr = era5['tp'] * 1000  # Convert from m to mm

    # Standardize coordinate names
    era5_pr = era5_pr.rename({
        'latitude': 'lat',
        'longitude': 'lon',
        'valid_time': 'time'
    })

    # Load your actual QM+CNN-LSTM corrected data here
    # For example:
    # corrected_ds = xr.open_dataset("qm_cnn_lstm_corrected.nc")
    # future_corrected = corrected_ds['pr_corrected']

    # Temporary placeholder - replace with your actual corrected data
    future_corrected = future_raw.copy()

    # Spatial domain (U.S. region)
    lat_min, lat_max = 25, 50
    lon_min_west, lon_max_west = -125, -66  # Western longitude
    lon_min = lon_min_west + 360  # Convert to eastern longitude for model compatibility
    lon_max = lon_max_west + 360

    # Time period: Use overlapping period between ERA5 and future data
    start_year = '2015'

    # Fixed time handling - extract scalar values properly
    future_max_time = future_raw.time.max().item()  # Get scalar value from array
    era5_max_time = era5_pr.time.max().item()  # Get scalar value from array

    end_year = min(
        pd.Timestamp(future_max_time).strftime('%Y'),
        pd.Timestamp(era5_max_time).strftime('%Y')
    )

    # Crop data to spatial and temporal domain
    # Raw model data
    future_raw_crop = future_raw.sel(
        time=slice(start_year, end_year),
        lat=slice(lat_min, lat_max),
        lon=slice(lon_min, lon_max)
    ).assign_coords(lon=(future_raw.lon % 360) - 360).sortby('lon')  # Convert to western longitude

    # Corrected data
    future_corrected_crop = future_corrected.sel(
        time=slice(start_year, end_year),
        lat=slice(lat_min, lat_max),
        lon=slice(lon_min, lon_max)
    ).assign_coords(lon=(future_corrected.lon % 360) - 360).sortby('lon')

    # ERA5 data
    era5_crop = era5_pr.sel(
        time=slice(start_year, end_year),
        lat=slice(lat_max, lat_min),  # Reverse latitude (ERA5 often in descending order)
        lon=slice(lon_min_west, lon_max_west)
    )

    # Spatial alignment: Interpolate ERA5 to model grid
    target_lat = future_raw_crop.lat
    target_lon = future_raw_crop.lon
    era5_align = era5_crop.interp(lat=target_lat, lon=target_lon, method='linear')

    return (future_raw_crop, future_corrected_crop, era5_align,
            (lon_min_west, lon_max_west, lat_min, lat_max), start_year, end_year)


# ----------------------------
# 2. Statistical Calculations
# ----------------------------
def calculate_stats(data, stat_type='extreme', quantiles=[0.95, 0.99]):
    """Calculate statistics: extreme quantiles or temporal mean"""
    if stat_type == 'extreme':
        # Calculate extreme quantiles for each grid point
        stats = {}
        for q in quantiles:
            stats[f'{int(q * 100)}th'] = data.quantile(q, dim='time', skipna=True)
        return stats
    elif stat_type == 'mean':
        # Calculate temporal mean
        return {'mean': data.mean(dim='time', skipna=True)}


# ----------------------------
# 3. Plot Comparison
# ----------------------------
def plot_comparison(raw_stat, corrected_stat, era5_stat, extent, period, stat_name):
    """Plot comparison of Raw, QM+CNN-LSTM, and ERA5 data"""
    lon_min, lon_max, lat_min, lat_max = extent
    proj = ccrs.PlateCarree()  # Map projection

    fig = plt.figure(figsize=(18, 6))

    # 1. Raw model data
    ax1 = fig.add_subplot(1, 3, 1, projection=proj)
    ax1.set_extent([lon_min, lon_max, lat_min, lat_max], crs=proj)
    im1 = ax1.contourf(
        raw_stat.lon, raw_stat.lat, raw_stat,
        levels=np.linspace(0, np.nanmax(raw_stat.values), 11),
        cmap='Blues', extend='max'
    )
    ax1.add_feature(cfeature.COASTLINE, linewidth=0.8)
    ax1.add_feature(cfeature.STATES, linewidth=0.5, edgecolor='gray')
    gl = ax1.gridlines(crs=proj, draw_labels=True, linestyle='--', alpha=0.7)
    gl.top_labels = gl.right_labels = False
    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    ax1.set_title(f'(a) Raw Model Data ({period})', fontsize=12)

    # 2. QM+CNN-LSTM corrected data
    ax2 = fig.add_subplot(1, 3, 2, projection=proj)
    ax2.set_extent([lon_min, lon_max, lat_min, lat_max], crs=proj)
    im2 = ax2.contourf(
        corrected_stat.lon, corrected_stat.lat, corrected_stat,
        levels=np.linspace(0, np.nanmax(raw_stat.values), 11),  # Consistent color scale
        cmap='Blues', extend='max'
    )
    ax2.add_feature(cfeature.COASTLINE, linewidth=0.8)
    ax2.add_feature(cfeature.STATES, linewidth=0.5, edgecolor='gray')
    gl = ax2.gridlines(crs=proj, draw_labels=True, linestyle='--', alpha=0.7)
    gl.top_labels = gl.right_labels = False
    gl.xformatter = LONGITUDE_FORMATTER
    ax2.set_title(f'(b) QM+CNN-LSTM Corrected Data ({period})', fontsize=12)

    # 3. ERA5 observational data
    ax3 = fig.add_subplot(1, 3, 3, projection=proj)
    ax3.set_extent([lon_min, lon_max, lat_min, lat_max], crs=proj)
    im3 = ax3.contourf(
        era5_stat.lon, era5_stat.lat, era5_stat,
        levels=np.linspace(0, np.nanmax(raw_stat.values), 11),  # Consistent color scale
        cmap='Blues', extend='max'
    )
    ax3.add_feature(cfeature.COASTLINE, linewidth=0.8)
    ax3.add_feature(cfeature.STATES, linewidth=0.5, edgecolor='gray')
    gl = ax3.gridlines(crs=proj, draw_labels=True, linestyle='--', alpha=0.7)
    gl.top_labels = gl.right_labels = False
    gl.xformatter = LONGITUDE_FORMATTER
    ax3.set_title(f'(c) ERA5 Observations ({period})', fontsize=12)

    # Add shared colorbar
    cbar = fig.colorbar(im3, ax=[ax1, ax2, ax3], orientation='horizontal', pad=0.05, aspect=40)
    cbar.set_label(f'{stat_name} Precipitation (mm/day)')

    plt.tight_layout()
    return fig


# ----------------------------
# Main Workflow
# ----------------------------
if __name__ == "__main__":
    # Load and align data
    print("Loading and aligning data...")
    future_raw, future_corrected, era5, extent, start, end = load_and_align_data()
    period = f'{start}-{end}'  # Comparison period
    lon_min, lon_max, lat_min, lat_max = extent

    # Calculate statistics (choose 'extreme' or 'mean')
    stat_type = 'extreme'  # 'extreme' for quantiles, 'mean' for average
    if stat_type == 'extreme':
        # Extreme precipitation quantiles (95th and 99th)
        raw_stats = calculate_stats(future_raw, stat_type='extreme')
        corrected_stats = calculate_stats(future_corrected, stat_type='extreme')
        era5_stats = calculate_stats(era5, stat_type='extreme')

        # Plot each quantile comparison
        for q in ['95th', '99th']:
            print(f"Plotting {q} quantile comparison...")
            fig = plot_comparison(
                raw_stats[q],
                corrected_stats[q],
                era5_stats[q],
                extent,
                period,
                f'{q} Quantile'
            )
            fig.savefig(f'precipitation_comparison_{q}_{period}.png', dpi=300, bbox_inches='tight')
            plt.show()
    else:
        # Average precipitation
        raw_mean = calculate_stats(future_raw, stat_type='mean')['mean']
        corrected_mean = calculate_stats(future_corrected, stat_type='mean')['mean']
        era5_mean = calculate_stats(era5, stat_type='mean')['mean']

        print("Plotting mean precipitation comparison...")
        fig = plot_comparison(
            raw_mean,
            corrected_mean,
            era5_mean,
            extent,
            period,
            'Mean'
        )
        fig.savefig(f'precipitation_comparison_mean_{period}.png', dpi=300, bbox_inches='tight')
        plt.show()

    print("Comparison plots generated successfully!")
