import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER
import matplotlib.ticker as mticker
import numpy as np

# -----------------------------
# Open datasets
# -----------------------------
era5_ds = xr.open_dataset("ERA5_tp.nc", chunks={'time': 10})
future_ds = xr.open_dataset("pr_20150115-20491215.nc", chunks={'time': 10})

# Unit conversion
era5 = era5_ds['tp'] * 1000  # m -> mm
future = future_ds['pr'] * 86400  # kg/m2/s -> mm/day

# Rename coordinates
era5 = era5.rename({'latitude': 'lat', 'longitude': 'lon'})

# -----------------------------
# Subset region
# -----------------------------
lat_min, lat_max = 25, 50
lon_min, lon_max = -125, -66
lon_min_c, lon_max_c = lon_min + 360, lon_max + 360  # convert to 0-360

# Select 2015-2025
era5_2015_2025 = era5.sel(lat=slice(lat_max, lat_min),
                          lon=slice(lon_min_c, lon_max_c),
                          valid_time=slice("2015", "2025"))
future_2015_2025 = future.sel(lat=slice(lat_min, lat_max),
                              lon=slice(lon_min_c, lon_max_c),
                              time=slice("2015", "2025"))

# -----------------------------
# Calculate time mean
# -----------------------------
era5_mean = era5_2015_2025.mean(dim='valid_time')
future_mean = future_2015_2025.mean(dim='time')

# -----------------------------
# Ensure latitude ascending and extract coordinates
# -----------------------------
# ERA5 data
if era5_mean.lat[0] > era5_mean.lat[-1]:
    era5_mean = era5_mean.reindex(lat=era5_mean.lat[::-1])
era5_lats = era5_mean.lat.values
era5_lons = era5_mean.lon.values

# Future data
if future_mean.lat[0] > future_mean.lat[-1]:
    future_mean = future_mean.reindex(lat=future_mean.lat[::-1])
future_lats = future_mean.lat.values
future_lons = future_mean.lon.values

# -----------------------------
# Calculate 95th and 99th percentiles
# -----------------------------
era5_95 = era5_2015_2025.quantile(0.95, dim='valid_time')
era5_99 = era5_2015_2025.quantile(0.99, dim='valid_time')
future_95 = future_2015_2025.quantile(0.95, dim='time')
future_99 = future_2015_2025.quantile(0.99, dim='time')

# Ensure latitude order is consistent
if era5_95.lat[0] > era5_95.lat[-1]:
    era5_95 = era5_95.reindex(lat=era5_95.lat[::-1])
if era5_99.lat[0] > era5_99.lat[-1]:
    era5_99 = era5_99.reindex(lat=era5_99.lat[::-1])

if future_95.lat[0] > future_95.lat[-1]:
    future_95 = future_95.reindex(lat=future_95.lat[::-1])
if future_99.lat[0] > future_99.lat[-1]:
    future_99 = future_99.reindex(lat=future_99.lat[::-1])

# Handle potential NaN values
era5_95 = np.nan_to_num(era5_95.values)
era5_99 = np.nan_to_num(era5_99.values)
future_95 = np.nan_to_num(future_95.values)
future_99 = np.nan_to_num(future_99.values)


# -----------------------------
# Improved plotting function
# -----------------------------
def plot_spatial(data, lats, lons, title):
    # Adjust figure size and layout
    fig, ax = plt.subplots(figsize=(9, 6), subplot_kw={'projection': ccrs.PlateCarree()},
                           constrained_layout=True)

    # Softer colormap
    im = ax.pcolormesh(lons, lats, data, cmap='BuPu', shading='auto', alpha=0.9)

    # Add geographic features
    ax.coastlines(resolution='50m', linewidth=0.8)
    ax.add_feature(cfeature.BORDERS, linewidth=0.6, linestyle=':')
    ax.add_feature(cfeature.STATES, linewidth=0.4, alpha=0.5)

    # Set map extent
    ax.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())

    # Add gridlines and labels
    gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                      linewidth=0.8, color='gray', alpha=0.5, linestyle='--')

    gl.top_labels = False
    gl.right_labels = False
    gl.xlocator = mticker.FixedLocator(range(-120, -60, 10))  # longitude step
    gl.ylocator = mticker.FixedLocator(range(30, 55, 5))  # latitude step
    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    gl.xlabel_style = {'size': 8}
    gl.ylabel_style = {'size': 8}

    # Add colorbar
    cbar = plt.colorbar(im, ax=ax, orientation='vertical', label='Precipitation (mm/day)',
                        shrink=0.85, aspect=15)
    cbar.ax.tick_params(labelsize=8)

    # Title
    ax.set_title(title, fontsize=10, pad=10)

    plt.show()


# -----------------------------
# Plot mean precipitation
# -----------------------------
plot_spatial(era5_mean.values, era5_lats, era5_lons, "ERA5 2015-2025 Mean Precipitation")
plot_spatial(future_mean.values, future_lats, future_lons, "Future 2015-2025 Mean Precipitation")

# -----------------------------
# Plot percentiles
# -----------------------------
plot_spatial(era5_95, era5_lats, era5_lons, "ERA5 2015-2025 95th Percentile")
plot_spatial(era5_99, era5_lats, era5_lons, "ERA5 2015-2025 99th Percentile")
plot_spatial(future_95, future_lats, future_lons, "Future 2015-2025 95th Percentile")
plot_spatial(future_99, future_lats, future_lons, "Future 2015-2025 99th Percentile")
