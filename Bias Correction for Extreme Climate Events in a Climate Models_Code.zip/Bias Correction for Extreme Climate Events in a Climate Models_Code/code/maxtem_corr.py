# ===============================
# Imports & Environment
# ===============================
import numpy as np
import pandas as pd
import xarray as xr
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
from scipy.ndimage import gaussian_filter1d
from torch.utils.data import DataLoader, TensorDataset

from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, mean_absolute_error
from scipy.stats import pearsonr
from scipy.interpolate import interp1d

# ------------------------------
# Set seed for reproducibility
# ------------------------------
def set_seed(seed=42):
    torch.manual_seed(seed)
    np.random.seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed(seed)
        torch.cuda.manual_seed_all(seed)
set_seed()

# ===============================
# Data Preprocessing
# ===============================
ERA5_tasmax1 = 'mx2t_2.nc'
ERA5_tasmax2 = 'mx2t_1.nc'
CMIP6_tasmax = 'CMIP6_tasmax.nc'

def load_data():
    ds_cmip6 = xr.open_dataset(CMIP6_tasmax, chunks={'time': 10})

    ds_era1 = xr.open_dataset(ERA5_tasmax1, chunks={'valid_time': 100})
    ds_era2 = xr.open_dataset(ERA5_tasmax2, chunks={'valid_time': 100})

    cmip6 = ds_cmip6['tasmax'] - 273.15
    era5_1 = ds_era1['mx2t'] - 273.15
    era5_2 = ds_era2['mx2t'] - 273.15
    era5 = xr.concat([era5_1, era5_2], dim="valid_time")
    era5 = era5.rename({'latitude': 'lat', 'longitude': 'lon', 'valid_time': 'time'})

    cmip6 = cmip6.where(cmip6 != 1e20)
    era5 = era5.where(era5 < 1e10)

    cmip6 = cmip6.sel(time=slice("1950", "2014"))
    era5 = era5.sel(time=slice("1950", "2014"))

    lat_min, lat_max = 25, 50
    lon_min, lon_max = -125, -66
    lon_min_conv, lon_max_conv = lon_min + 360, lon_max + 360

    cmip6 = cmip6.sel(lat=slice(lat_min, lat_max), lon=slice(lon_min_conv, lon_max_conv))
    era5 = era5.sel(lat=slice(lat_max, lat_min), lon=slice(lon_min_conv, lon_max_conv))

    cmip6_mon = cmip6.mean(dim=["lat", "lon"]).resample(time="1MS").mean()
    era5_mon = era5.mean(dim=["lat", "lon"]).resample(time="1MS").mean()

    cmip6_mon.values = gaussian_filter1d(cmip6_mon.values, sigma=1)
    era5_mon.values = gaussian_filter1d(era5_mon.values, sigma=1)

    return cmip6_mon.values, era5_mon.values

sim, obs = load_data()

# ===============================
# Quantile Mapping
# ===============================
def quantile_mapping(obs, sim, target):
    quantiles = np.linspace(0, 1, 1001)
    obs_q = np.quantile(obs, quantiles)
    sim_q = np.quantile(sim, quantiles)
    sim_q_unique, idx = np.unique(sim_q, return_index=True)
    obs_q_unique = obs_q[idx]
    qm_func = interp1d(sim_q_unique, obs_q_unique, bounds_error=False, fill_value="extrapolate")
    return qm_func(target)

sim_qm = quantile_mapping(obs, sim, sim)
residuals = obs - sim_qm

# ===============================
# Time Embedding
# ===============================
def add_time_embedding(length, start_year="1950-01"):
    dates = pd.date_range(start=start_year, periods=length, freq="MS")
    months = dates.month.values
    years = dates.year.values - dates.year.values.min()

    sin_month = np.sin(2 * np.pi * months / 12)
    cos_month = np.cos(2 * np.pi * months / 12)
    sin_year = np.sin(2 * np.pi * years / 10)
    cos_year = np.cos(2 * np.pi * years / 10)

    return np.stack([sin_month, cos_month, sin_year, cos_year], axis=1)

# ===============================
# Sequence Preparation
# ===============================
def create_sequences(data, input_len=60, pred_len=1):
    X, y = [], []
    for i in range(len(data) - input_len - pred_len + 1):
        X.append(data[i:i+input_len])
        y.append(data[i+input_len:i+input_len+pred_len])
    return np.array(X), np.array(y)

input_len = 120
X_np, y_np = create_sequences(residuals, input_len=input_len)

mean_resid, std_resid = X_np.mean(), X_np.std()
X_np = (X_np - mean_resid) / std_resid

y_mean, y_std = y_np.mean(), y_np.std()
y_np = (y_np - y_mean) / y_std

X_tensor = torch.tensor(X_np, dtype=torch.float32).unsqueeze(-1)
y_tensor = torch.tensor(y_np, dtype=torch.float32)
X_time = torch.tensor(add_time_embedding(len(X_np)), dtype=torch.float32)

X_train, X_val, Xt_train, Xt_val, y_train, y_val = train_test_split(X_tensor, X_time, y_tensor, test_size=0.2, random_state=42)
train_loader = DataLoader(TensorDataset(X_train, Xt_train, y_train), batch_size=64, shuffle=True)
val_loader = DataLoader(TensorDataset(X_val, Xt_val, y_val), batch_size=64)

# ===============================
# Model Definition
# ===============================
class CNN_LSTM_Enhanced(nn.Module):
    def __init__(self, input_dim=1, cnn_channels=64, lstm_hidden=128, time_emb_dim=4, dropout=0.3):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv1d(input_dim, cnn_channels, kernel_size=3, padding=1),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Conv1d(cnn_channels, cnn_channels, kernel_size=3, padding=1),
            nn.BatchNorm1d(cnn_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
        )
        self.lstm = nn.LSTM(cnn_channels, lstm_hidden, batch_first=True, bidirectional=False)
        self.fc = nn.Sequential(
            nn.Linear(lstm_hidden + time_emb_dim, 64),
            nn.ReLU(),
            nn.Dropout(0.2),
            nn.Linear(64, 1)
        )

    def forward(self, x, time_emb):
        x = x.permute(0, 2, 1)
        x = self.cnn(x).permute(0, 2, 1)
        _, (h_n, _) = self.lstm(x)
        h_last = h_n[-1]
        combined = torch.cat([h_last, time_emb], dim=1)
        return self.fc(combined).squeeze(1)

# ===============================
# Loss Function with Correlation
# ===============================
def correlation_loss(pred, target):
    vx = pred - torch.mean(pred)
    vy = target - torch.mean(target)
    corr = torch.sum(vx * vy) / (torch.sqrt(torch.sum(vx**2)) * torch.sqrt(torch.sum(vy**2)) + 1e-8)
    return 1 - corr

# ===============================
# Training Loop
# ===============================
device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
print(f"Using device: {device}")

model = CNN_LSTM_Enhanced().to(device)
criterion = nn.MSELoss()
optimizer = optim.AdamW(model.parameters(), lr=1e-4, weight_decay=1e-5)
scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, 'min', patience=15, factor=0.5, min_lr=1e-6)

max_grad_norm = 5.0
best_val_loss = float('inf')
patience = 15
wait = 0

for epoch in range(1, 101):
    model.train()
    total_loss = 0
    for xb, tb, yb in train_loader:
        xb, tb, yb = xb.to(device), tb.to(device), yb.to(device)
        optimizer.zero_grad()
        preds = model(xb, tb)
        loss = criterion(preds, yb.squeeze(1)) + 0.3 * correlation_loss(preds, yb.squeeze(1))
        loss.backward()
        torch.nn.utils.clip_grad_norm_(model.parameters(), max_grad_norm)
        optimizer.step()
        total_loss += loss.item()

    model.eval()
    val_loss = 0
    val_preds, val_targets = [], []
    with torch.no_grad():
        for xb, tb, yb in val_loader:
            xb, tb, yb = xb.to(device), tb.to(device), yb.to(device)
            preds = model(xb, tb)
            loss = criterion(preds, yb.squeeze(1)) + 0.3 * correlation_loss(preds, yb.squeeze(1))
            val_loss += loss.item()
            val_preds.append(preds.cpu().numpy())
            val_targets.append(yb.cpu().numpy())

    val_preds = np.concatenate(val_preds)
    val_targets = np.concatenate(val_targets)
    corr, _ = pearsonr(val_preds.flatten(), val_targets.flatten())

    print(f"Epoch {epoch} | Train Loss: {total_loss / len(train_loader):.4f} "
          f"| Val Loss: {val_loss / len(val_loader):.4f} | Val Corr: {corr:.4f}")

    scheduler.step(val_loss / len(val_loader))
    if val_loss < best_val_loss:
        best_val_loss = val_loss
        wait = 0
        torch.save(model.state_dict(), "cnn_lstm_tasmax.pth")
    else:
        wait += 1
        if wait >= patience:
            print("Early stopping triggered.")
            break

# ===============================
# Inference & Evaluation
# ===============================
model.eval()
with torch.no_grad():
    preds = model(X_tensor.to(device), X_time.to(device)).cpu().numpy()
    preds = preds * y_std + y_mean

deep_residuals = np.concatenate([np.zeros(input_len), preds])[:len(obs)]
sim_qm_deep = sim_qm + deep_residuals

dates = pd.date_range("1950-01", periods=len(sim_qm_deep), freq="MS")

plt.figure(figsize=(14, 6))
plt.plot(dates, sim[:len(dates)], label='CMIP6 Raw', alpha=0.6)
plt.plot(dates, sim_qm_deep, label='QM + CNN-LSTM', alpha=0.8)
plt.plot(dates, obs[:len(dates)], label='ERA5 Observed', linewidth=1.5)
plt.xlabel("Year")
plt.ylabel("Temperature (°C")
plt.title("Monthly Maximum Temperature Time Series")
plt.legend()
plt.tight_layout()
plt.show()

# ===============================
# Plot: CMIP6 Raw vs QM+CNN-LSTM vs ERA5 (Monthly Cycle with markers)
# ===============================
dates_full = pd.date_range(start="1950-01", periods=len(obs), freq="MS")
df = pd.DataFrame({
    'CMIP6_Raw': sim[:len(dates_full)],
    'QM_Corrected': sim_qm_deep,
    'ERA5_Obs': obs[:len(dates_full)]
}, index=dates_full)

# 按月份计算均值
df_monthly = df.groupby(df.index.month).mean()
months = range(1, 13)

plt.figure(figsize=(12,6))

# 绘制每条曲线并加圆点
plt.plot(months, df_monthly['CMIP6_Raw'], label='CMIP6 Raw', color='blue', marker='o', alpha=0.7)
plt.plot(months, df_monthly['QM_Corrected'], label='QM + CNN-LSTM Corrected', color='orange', marker='o', linewidth=2)
plt.plot(months, df_monthly['ERA5_Obs'], label='ERA5 Observed', color='green', marker='o', linewidth=2)

plt.xticks(months, ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'])
plt.xlabel("Month")
plt.ylabel("Temperature (°C)")
plt.title("Mean Seasonal Cycle of Monthly Maximum Temperature")
plt.legend()
plt.grid(True, alpha=0.3)
plt.tight_layout()
plt.show()


# ===============================
# Metrics & Histogram
# ===============================
def print_metrics(obs, pred, name=""):
    rmse = np.sqrt(mean_squared_error(obs, pred))
    mae = mean_absolute_error(obs, pred)
    corr, _ = pearsonr(obs, pred)
    print(f"{name} RMSE: {rmse:.4f}, MAE: {mae:.4f}, Corr: {corr:.4f}")

print("\n===== Evaluation Metrics =====")
print_metrics(obs, sim, "Raw")
print_metrics(obs, sim_qm, "QM")
print_metrics(obs, sim_qm_deep, "QM+Deep")

plt.figure(figsize=(12, 5))
n = len(obs)
plt.hist(sim[:n].flatten(), bins=50, alpha=0.5, label='Raw CMIP6')
plt.hist(sim_qm_deep[:n].flatten(), bins=50, alpha=0.5, label='QM+CNN-LSTM Corrected')
plt.hist(obs.flatten(), bins=50, alpha=0.5, label='ERA5')
plt.xlabel('Temperature (°C)')
plt.ylabel('Frequency')
plt.title("Distribution of Monthly Maximum Temperature")
plt.legend()
plt.tight_layout()
plt.show()

plt.figure(figsize=(6, 6))
plt.scatter(obs, sim, alpha=0.3, label='Raw')
plt.scatter(obs, sim_qm, alpha=0.3, label='QM')
plt.scatter(obs, sim_qm_deep, alpha=0.3, label='QM+CNN-LSTM')
plt.plot([obs.min(), obs.max()], [obs.min(), obs.max()], 'k--', lw=2)
plt.xlabel('Observed Temperature (°C)')
plt.ylabel('Simulated Temperature (°C)')
plt.legend()
plt.title('Scatter Maximum TemperaturePlot: Simulated vs Observed (tasmax)')
plt.tight_layout()
plt.show()
