import xarray as xr
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import scipy.stats as stats
from scipy.interpolate import interp1d
import torch
import torch.nn as nn

# ========================================
# 1️⃣ Load CMIP6 data
# ========================================
cmip6_tasmax = xr.open_dataset("tasmax_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc")['tasmax'].sel(time=slice("2015-01","2025-12"))
cmip6_tasmin = xr.open_dataset("tasmin_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc")['tasmin'].sel(time=slice("2015-01","2025-12"))
cmip6_rsds   = xr.open_dataset("rsds_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc")['rsds'].sel(time=slice("2015-01","2025-12"))
cmip6_hurs   = xr.open_dataset("hurs_Amon_CanESM5_ssp245_r1i1p1f1_gn_20150116-20491216.nc")['hurs'].sel(time=slice("2015-01","2025-12"))

# ========================================
# 2️⃣ Load ERA5 data
# ========================================
def preprocess_era5(da):
    # Rename coordinates
    rename_dict = {'valid_time': 'time', 'latitude': 'lat', 'longitude': 'lon'}
    da = da.rename({k: v for k, v in rename_dict.items() if k in da.dims})

    # Drop extra dimension (e.g., pressure_level) if present
    if 'pressure_level' in da.dims:
        da = da.isel(pressure_level=0)

    return da

# Load ERA5 and rename dimensions
era5_tasmax = xr.open_dataset("mx2t_1.nc", chunks={'valid_time': 100})['mx2t'] \
    .sel(valid_time=slice("2015","2025")) \
    .rename({'valid_time':'time', 'latitude':'lat', 'longitude':'lon'})

era5_tasmin = xr.open_dataset("mn2t.nc", chunks={'valid_time': 100})['mn2t'] \
    .sel(valid_time=slice("2015","2025")) \
    .rename({'valid_time':'time', 'latitude':'lat', 'longitude':'lon'})

era5_rsds = xr.open_dataset("ERA5_ssr.nc", chunks={'valid_time': 100})['ssr'] \
    .sel(valid_time=slice("2015","2025")) \
    .rename({'valid_time':'time', 'latitude':'lat', 'longitude':'lon'})

era5_hurs = xr.open_dataset("ERA5_r.nc", chunks={'valid_time': 100})['r'] \
    .sel(valid_time=slice("2015","2025")) \
    .rename({'valid_time':'time', 'latitude':'lat', 'longitude':'lon'})

# ========================================
# 3️⃣ U.S. regional average
# ========================================
def select_us_avg(da):
    return da.sel(lat=slice(24,50), lon=slice(-125,-66)).mean(dim=['lat','lon']).values

sim_tasmax = select_us_avg(cmip6_tasmax)
sim_tasmin = select_us_avg(cmip6_tasmin)
sim_rsds   = select_us_avg(cmip6_rsds)
sim_hurs   = select_us_avg(cmip6_hurs)

obs_tasmax = select_us_avg(era5_tasmax)
obs_tasmin = select_us_avg(era5_tasmin)
obs_rsds   = select_us_avg(era5_rsds)
obs_hurs   = select_us_avg(era5_hurs)

# ========================================
# 4️⃣ Quantile Mapping (QM) correction
# ========================================
def quantile_mapping(obs, sim, target):
    q = np.linspace(0,1,1001)
    obs_q = np.quantile(obs,q)
    sim_q = np.quantile(sim,q)
    sim_q_unique, idx = np.unique(sim_q, return_index=True)
    obs_q_unique = obs_q[idx]
    f = interp1d(sim_q_unique, obs_q_unique, bounds_error=False, fill_value="extrapolate")
    return f(target)

# Aggregate monthly (take monthly mean)
era5_tasmax_monthly = era5_tasmax.resample(time='ME').mean(dim=['lat','lon'])
era5_tasmin_monthly = era5_tasmin.resample(time='ME').mean(dim=['lat','lon'])
era5_rsds_monthly   = era5_rsds.resample(time='ME').mean(dim=['lat','lon'])
era5_hurs_monthly   = era5_hurs.resample(time='ME').mean(dim=['lat','lon'])

# Convert to numpy arrays
tasmax_vals = era5_tasmax_monthly.values
tasmin_vals = era5_tasmin_monthly.values
rsds_vals   = era5_rsds_monthly.values
hurs_vals   = era5_hurs_monthly.values

# CMIP6 already monthly, take U.S. regional average
sim_tasmax = cmip6_tasmax.sel(lat=slice(24,50), lon=slice(-125,-66)).mean(dim=['lat','lon']).values
sim_tasmin = cmip6_tasmin.sel(lat=slice(24,50), lon=slice(-125,-66)).mean(dim=['lat','lon']).values
sim_rsds   = cmip6_rsds.sel(lat=slice(24,50), lon=slice(-125,-66)).mean(dim=['lat','lon']).values
sim_hurs   = cmip6_hurs.sel(lat=slice(24,50), lon=slice(-125,-66)).mean(dim=['lat','lon']).values

sim_qm = {
    'tasmax': quantile_mapping(obs_tasmax, sim_tasmax, sim_tasmax),
    'tasmin': quantile_mapping(obs_tasmin, sim_tasmin, sim_tasmin),
    'rsds':   quantile_mapping(obs_rsds, sim_rsds, sim_rsds),
    'hurs':   quantile_mapping(obs_hurs, sim_hurs, sim_hurs)
}

# ========================================
# 5️⃣ CNN-LSTM Deep Residual Correction (toy example)
# ========================================
class CNN_LSTM(nn.Module):
    def __init__(self, input_dim=4, cnn_ch=16, lstm_h=32, time_emb=4):
        super().__init__()
        self.cnn = nn.Sequential(
            nn.Conv1d(input_dim, cnn_ch, 3, padding=1),
            nn.ReLU(),
            nn.Conv1d(cnn_ch, cnn_ch, 3, padding=1),
            nn.ReLU()
        )
        self.lstm = nn.LSTM(cnn_ch, lstm_h, batch_first=True)
        self.fc = nn.Linear(lstm_h+time_emb, input_dim)
    def forward(self,x,time_emb):
        x = x.permute(0,2,1)
        x = self.cnn(x).permute(0,2,1)
        _,(h,_) = self.lstm(x)
        h = h[-1]
        out = self.fc(torch.cat([h,time_emb],dim=1))
        return out

def create_sequences(data, seq_len=12):
    X,y=[],[]
    keys=list(data.keys())
    N=len(data[keys[0]])
    for i in range(N-seq_len):
        seq = np.stack([data[k][i:i+seq_len] for k in keys],axis=1)
        tgt = np.array([data[k][i+seq_len] for k in keys])
        X.append(seq)
        y.append(tgt)
    return np.array(X), np.array(y)

# Simplified residuals
residuals = {k: obs_tasmax - sim_qm[k] if k=='tasmax' else sim_qm[k]-sim_qm[k] for k in sim_qm.keys()}
X_train,y_train = create_sequences(residuals)
time_emb_train = np.random.normal(0,1,(X_train.shape[0],4))

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
X_train = torch.tensor(X_train,dtype=torch.float32).to(device)
y_train = torch.tensor(y_train,dtype=torch.float32).to(device)
time_emb_train = torch.tensor(time_emb_train,dtype=torch.float32).to(device)

model = CNN_LSTM().to(device)
optimizer = torch.optim.Adam(model.parameters(), lr=0.001)
criterion = nn.MSELoss()
model.train()
for _ in range(3):  # small epoch test
    optimizer.zero_grad()
    out = model(X_train,time_emb_train)
    loss = criterion(out,y_train)
    loss.backward()
    optimizer.step()

# Predict future residuals and correct
X_future,_ = create_sequences(sim_qm)
time_emb_future = np.random.normal(0,1,(X_future.shape[0],4))
X_future = torch.tensor(X_future,dtype=torch.float32).to(device)
time_emb_future = torch.tensor(time_emb_future,dtype=torch.float32).to(device)
model.eval()
with torch.no_grad():
    residuals_future = model(X_future,time_emb_future).cpu().numpy()

corrected_future = {}
for i,k in enumerate(sim_qm.keys()):
    corrected_future[k] = sim_qm[k][12:] + residuals_future[:,i]

# ========================================
# 6️⃣ WBGT & Annual Maximum Consecutive Heatwave Function
# ========================================
def calc_wbgt(tasmax,tasmin,hurs,rsds):
    Tmean=(tasmax+tasmin)/2
    Twb=Tmean*(hurs/100)**0.125
    return 0.7*Twb + 0.2*(rsds/100) + 0.1*Tmean

threshold_tasmax=35
threshold_wbgt=32
def annual_max_streak(tasmax,tasmin,rsds,hurs):
    wbgt=calc_wbgt(tasmax,tasmin,hurs,rsds)
    hw=(tasmax>threshold_tasmax)|(wbgt>threshold_wbgt)
    max_streak=0
    current=0
    for v in hw:
        if v:
            current+=1
            max_streak=max(max_streak,current)
        else:
            current=0
    return max_streak

years = pd.date_range('2015-01','2025-12',freq='MS').year
def compute_annual_max(data_dict):
    arrs = [data_dict['tasmax'], data_dict['tasmin'], data_dict['rsds'], data_dict['hurs']]
    N=len(arrs[0])
    annual_max=[]
    for y in np.unique(years):
        mask=(years==y)
        annual_max.append(annual_max_streak(arrs[0][mask],arrs[1][mask],arrs[2][mask],arrs[3][mask]))
    return np.array(annual_max)

annual_raw = compute_annual_max({'tasmax':sim_tasmax,'tasmin':sim_tasmin,'rsds':sim_rsds,'hurs':sim_hurs})
annual_qm  = compute_annual_max({'tasmax':sim_qm['tasmax'],'tasmin':sim_qm['tasmin'],'rsds':sim_qm['rsds'],'hurs':sim_qm['hurs']})
annual_dl  = compute_annual_max(corrected_future)

# ========================================
# 7️⃣ GEV fit & plotting
# ========================================
c_raw,loc_raw,scale_raw=stats.genextreme.fit(annual_raw)
c_qm,loc_qm,scale_qm=stats.genextreme.fit(annual_qm)
c_dl,loc_dl,scale_dl=stats.genextreme.fit(annual_dl)

x=np.linspace(0,max(max(annual_raw),max(annual_qm),max(annual_dl))+1,200)
pdf_raw=stats.genextreme.pdf(x,c_raw,loc=loc_raw,scale=scale_raw)
pdf_qm=stats.genextreme.pdf(x,c_qm,loc=loc_qm,scale=scale_qm)
pdf_dl=stats.genextreme.pdf(x,c_dl,loc=loc_dl,scale=scale_dl)

plt.figure(figsize=(10,6))
plt.hist(annual_raw,bins=range(0,max(annual_raw)+2),density=True,alpha=0.4,color='skyblue',label='CMIP6 Raw')
plt.hist(annual_qm,bins=range(0,max(annual_qm)+2),density=True,alpha=0.4,color='orange',label='CMIP6 QM Corrected')
plt.hist(annual_dl,bins=range(0,max(annual_dl)+2),density=True,alpha=0.4,color='tomato',label='CMIP6 QM+CNN-LSTM')
plt.plot(x,pdf_raw,'b-',lw=2,label='Raw GEV Fit')
plt.plot(x,pdf_qm,'orange',lw=2,label='QM GEV Fit')
plt.plot(x,pdf_dl,'r-',lw=2,label='Deep Correction GEV Fit')
plt.xlabel('Annual Maximum Heatwave Duration (months)')
plt.ylabel('Density')
plt.title('GEV Fit Comparison: CMIP6 2015–2025')
plt.legend()
plt.grid(True,linestyle='--',alpha=0.5)
plt.show()
