import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

# ----------------------------
# Step 1: Load Data
# ----------------------------
# Filenames for maximum temperature datasets
ERA5_tasmax1 = 'mx2t_2.nc'
ERA5_tasmax2 = 'mx2t_1.nc'
CMIP6_tasmax = 'CMIP6_tasmax.nc'  # CMIP6 Tmax file (verify)

# Load datasets
# Load ERA5 datasets
ds1 = xr.open_dataset(ERA5_tasmax1, chunks={"time": 10})
ds2 = xr.open_dataset(ERA5_tasmax2, chunks={"time": 10})
# Concatenate and sort by time
ds_era5 = xr.concat([ds1, ds2], dim="valid_time").sortby("valid_time")
ds_era5 = ds_era5.chunk({'valid_time': 100})

# Load CMIP6 dataset
ds_cmip6 = xr.open_dataset(CMIP6_tasmax, chunks={"time": 10})

# Print time ranges
print("CMIP6 time range:", ds_cmip6.time.min().values, "to", ds_cmip6.time.max().values)
print("ERA5 time range:", ds_era5.valid_time.min().values, "to", ds_era5.valid_time.max().values)

# ----------------------------
# Step 2: Extract Variables (Maximum 2m Temperature)
# ----------------------------
tasmax_era5 = ds_era5['mx2t']      # ERA5 maximum temperature variable
tasmax_cmip6 = ds_cmip6['tasmax']  # CMIP6 maximum temperature variable

# ----------------------------
# Step 3: Handle Missing Values
# ----------------------------
tasmax_cmip6 = tasmax_cmip6.where(tasmax_cmip6 != 1e20)
tasmax_era5 = tasmax_era5.where(tasmax_era5 < 1e10)

# ----------------------------
# Step 4: Crop Region (e.g., CONUS)
# ----------------------------
lat_min, lat_max = 24.5, 49.4
lon_min, lon_max = -125, -67
lon_min_conv = lon_min + 360
lon_max_conv = lon_max + 360

# Rename ERA5 coordinates
tasmax_era5 = tasmax_era5.rename({'latitude': 'lat', 'longitude': 'lon'})

# Convert ERA5 longitude to 0-360 if necessary
if (tasmax_era5.lon < 0).any():
    tasmax_era5['lon'] = tasmax_era5['lon'] % 360

# Crop datasets
tasmax_era5_cropped = tasmax_era5.sel(
    valid_time=slice("1950", "2014"),
    lat=slice(lat_max, lat_min),
    lon=slice(lon_min_conv, lon_max_conv)
)
tasmax_cmip6_cropped = tasmax_cmip6.sel(
    time=slice("1950", "2014"),
    lat=slice(lat_min, lat_max),
    lon=slice(lon_min_conv, lon_max_conv)
)

# ----------------------------
# Step 5: Compute Time Means
# ----------------------------
tasmax_era5_mean = tasmax_era5_cropped.mean(dim='valid_time')
tasmax_cmip6_mean = tasmax_cmip6_cropped.mean(dim='time')

# ----------------------------
# Step 6: Interpolate ERA5 to CMIP6 Grid
# ----------------------------
tasmax_era5_interp = tasmax_era5_mean.interp(
    lat=tasmax_cmip6_mean.lat,
    lon=tasmax_cmip6_mean.lon,
    method="nearest"  # Faster
)

# ----------------------------
# Step 7: Compute Differences (ERA5 - CMIP6)
# ----------------------------
diff_tasmax = tasmax_era5_interp - tasmax_cmip6_mean

# ----------------------------
# Step 8: Plotting Function
# ----------------------------
def plot_map(ax, data, title, cmap, vmin=None, vmax=None, extend='both'):
    im = data.plot.pcolormesh(
        ax=ax,
        transform=ccrs.PlateCarree(),
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        add_colorbar=False,
        shading='auto'
    )
    ax.set_title(title, fontsize=12)
    ax.coastlines()
    ax.add_feature(cfeature.BORDERS, linewidth=0.5)
    ax.add_feature(cfeature.STATES.with_scale('50m'), linewidth=0.3)
    ax.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())
    return im

# ----------------------------
# Step 9: Plot Three Maps
# ----------------------------
fig, axs = plt.subplots(1, 3, figsize=(21, 6), subplot_kw={'projection': ccrs.PlateCarree()})

titles = [
    'CMIP6 Mean Maximum Temperature (K)',
    'ERA5 Interpolated Maximum Temperature (K)',
    'Difference (ERA5 - CMIP6) (K)'
]
cmaps = ['YlGnBu', 'YlOrRd', 'RdBu_r']

# Use 2% and 98% percentiles to reduce extreme values
tasmax_min = float(np.nanpercentile([tasmax_cmip6_mean, tasmax_era5_interp], 2))
tasmax_max = float(np.nanpercentile([tasmax_cmip6_mean, tasmax_era5_interp], 98))
diff_absmax = float(np.nanmax(np.abs(diff_tasmax)))

data_list = [tasmax_cmip6_mean, tasmax_era5_interp, diff_tasmax]
vmin_list = [tasmax_min, tasmax_min, -diff_absmax]
vmax_list = [tasmax_max, tasmax_max, diff_absmax]

for ax, data, title, cmap, vmin, vmax in zip(axs, data_list, titles, cmaps, vmin_list, vmax_list):
    im = plot_map(ax, data, title, cmap, vmin, vmax)
    cb = fig.colorbar(im, ax=ax, orientation='vertical', shrink=0.75, pad=0.02)
    cb.set_label('K')

plt.tight_layout()
plt.show()

# ----------------------------
# Step 10: Monthly Mean Time Series Plot
# ----------------------------
tas_era5_monthly = tasmax_era5_cropped.resample(valid_time='1MS').mean(dim='valid_time')
tas_cmip6_monthly = tasmax_cmip6_cropped.resample(time='1MS').mean(dim='time')

# Spatial mean to get time series
tas_era5_series = tas_era5_monthly.mean(dim=['lat', 'lon'])
tas_cmip6_series = tas_cmip6_monthly.mean(dim=['lat', 'lon'])

# Extract time
era5_time = tas_era5_series.valid_time.values
cmip6_time = tas_cmip6_series.time.values

# Convert units: ERA5 is in K, convert to °C
tas_era5_series = tas_era5_series - 273.15
tas_cmip6_series = tas_cmip6_series - 273.15

# Plot time series
plt.figure(figsize=(12, 5))
plt.plot(era5_time, tas_era5_series, label='ERA5', color='blue')
plt.plot(cmip6_time, tas_cmip6_series, label='CMIP6', color='red')
plt.title("Monthly Mean Maximum Temperature Time Series")
plt.ylabel("Temperature (°C)")
plt.xlabel("Time")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

# ----------------------------
# Step 11: 95th Percentile Tmax Spatial Map
# ----------------------------
tasmax_era5_p95 = tasmax_era5_cropped.quantile(0.95, dim='valid_time')
tasmax_cmip6_p95 = tasmax_cmip6_cropped.quantile(0.95, dim='time')

# Interpolate ERA5 to CMIP6 grid
tasmax_era5_p95_interp = tasmax_era5_p95.interp(
    lat=tasmax_cmip6_p95.lat,
    lon=tasmax_cmip6_p95.lon
)

# Compute difference
diff_p95 = tasmax_era5_p95_interp - tasmax_cmip6_p95

# Plot maps
fig, axs = plt.subplots(1, 3, figsize=(21, 6), subplot_kw={'projection': ccrs.PlateCarree()})

titles = [
    'CMIP6 95th Percentile of Tmax (K)',
    'ERA5 95th Percentile of Tmax (K)',
    'Difference (ERA5 - CMIP6) (K)'
]
cmaps = ['YlGnBu', 'YlOrRd', 'RdBu_r']

vmin = float(np.nanpercentile([tasmax_cmip6_p95, tasmax_era5_p95_interp], 2))
vmax = float(np.nanpercentile([tasmax_cmip6_p95, tasmax_era5_p95_interp], 98))
diff_max = float(np.nanmax(np.abs(diff_p95)))

data_list = [tasmax_cmip6_p95, tasmax_era5_p95_interp, diff_p95]
vmin_list = [vmin, vmin, -diff_max]
vmax_list = [vmax, vmax, diff_max]

for ax, data, title, cmap, vmin_, vmax_ in zip(axs, data_list, titles, cmaps, vmin_list, vmax_list):
    im = plot_map(ax, data, title, cmap, vmin=vmin_, vmax=vmax_)
    cb = fig.colorbar(im, ax=ax, orientation='vertical', shrink=0.75, pad=0.02)
    cb.set_label("K")

plt.tight_layout()
plt.show()
