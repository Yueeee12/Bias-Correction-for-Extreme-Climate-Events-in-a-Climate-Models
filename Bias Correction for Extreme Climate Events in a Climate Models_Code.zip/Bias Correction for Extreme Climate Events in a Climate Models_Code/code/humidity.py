import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

# ----------------------------
# Step 1: Load Data
# ----------------------------
ds_era5_rh = xr.open_dataset('ERA5_r.nc', chunks={'time': 10})
ds_cmip6_hur = xr.open_dataset('CMIP6_hurs.nc')

print("CMIP6 time range:", ds_cmip6_hur.time.min().values, "to", ds_cmip6_hur.time.max().values)
print("ERA5 time range:", ds_era5_rh.valid_time.min().values, "to", ds_era5_rh.valid_time.max().values)

rh_era5 = ds_era5_rh['r']          # ERA5 uses lat/lon naming: latitude, longitude
hur_cmip6 = ds_cmip6_hur['hurs']  # CMIP6 uses latitude/longitude

# ----------------------------
# Step 2: Handle Missing Values
# ----------------------------
rh_era5 = rh_era5.where(rh_era5 < 1e10)
hur_cmip6 = hur_cmip6.where(hur_cmip6 < 1e10)

# ----------------------------
# Step 3: Coordinate alignment
# ----------------------------
if 'latitude' in rh_era5.dims:
    rh_era5 = rh_era5.rename({'latitude': 'lat', 'longitude': 'lon'})

if 'latitude' in ds_era5_rh.coords:
    ds_era5_rh = ds_era5_rh.rename({'latitude': 'lat', 'longitude': 'lon'})

# ----------------------------
# Step 4: Crop CONUS Region
# ----------------------------
lat_min_raw, lat_max_raw = 24.5, 49.25
lon_min, lon_max = -125, -67
lon_min_360, lon_max_360 = lon_min + 360, lon_max + 360

# ERA5 longitude is 0-360, latitude decreasing order, so slice accordingly
rh_era5_cropped = rh_era5.sel(
    valid_time=slice("1950", "2014"),
    lat=slice(lat_max_raw, lat_min_raw),  # ERA5 lat descending order
    lon=slice(lon_min_360, lon_max_360)
)

if (hur_cmip6.lon < 0).any():
    hur_cmip6 = hur_cmip6.assign_coords(lon=(hur_cmip6.lon % 360))
    hur_cmip6 = hur_cmip6.sortby('lon')

hur_cmip6_cropped = hur_cmip6.sel(
    time=slice("1950", "2014"),
    lat=slice(lat_min_raw, lat_max_raw),  # CMIP6 lat ascending order
    lon=slice(lon_min_360, lon_max_360)
)

# ----------------------------
# Step 5: Compute Time Average
# ----------------------------
rh_era5_mean = rh_era5_cropped.mean(dim='valid_time')
hur_cmip6_mean = hur_cmip6_cropped.mean(dim='time')

# ----------------------------
# Step 6: Regrid CMIP6 to ERA5 grid
# ----------------------------
era5_lat_min = hur_cmip6_mean.lat.min().values
era5_lat_max = hur_cmip6_mean.lat.max().values

# 把ERA5平均数据裁剪到CMIP6有效纬度范围
rh_era5_mean_cropped2 = rh_era5_mean.sel(lat=slice(era5_lat_max, era5_lat_min))

# ----------------------------
# Step 7: 插值CMIP6到ERA5（裁剪后）网格
# ----------------------------
hur_cmip6_interp = hur_cmip6_mean.interp(
    lat=rh_era5_mean_cropped2.lat,
    lon=rh_era5_mean_cropped2.lon
)

# ----------------------------
# Step 7: Difference
# ----------------------------
diff = rh_era5_mean_cropped2 - hur_cmip6_interp
diff_filled = diff.fillna(0)

lat_min, lat_max = era5_lat_min, era5_lat_max

# ----------------------------
# Step 8: Plotting Relative Humidity Maps
# ----------------------------
fig, axs = plt.subplots(1, 3, figsize=(20, 6), subplot_kw={'projection': ccrs.PlateCarree()})

titles = [
    'CMIP6 Mean Relative Humidity (Interpolated)',
    'ERA5 Mean Relative Humidity',
    'Difference (ERA5 - CMIP6)'
]
cmaps = ['YlGnBu', 'YlOrRd', 'RdBu_r']

vmin_rh = min(float(rh_era5_mean.min()), float(hur_cmip6_interp.min()))
vmax_rh = max(float(rh_era5_mean.max()), float(hur_cmip6_interp.max()))
diff_absmax = max(abs(diff_filled.min().values), abs(diff_filled.max().values))

vmins = [vmin_rh, vmin_rh, -diff_absmax]
vmaxs = [vmax_rh, vmax_rh, diff_absmax]

data_list = [hur_cmip6_interp, rh_era5_mean, diff_filled]

for ax, data, title, cmap, vmin, vmax in zip(axs, data_list, titles, cmaps, vmins, vmaxs):
    im = data.plot(ax=ax, transform=ccrs.PlateCarree(), cmap=cmap,
                   vmin=vmin, vmax=vmax, add_colorbar=False)
    ax.set_title(title, fontsize=12)
    ax.coastlines('50m', linewidth=0.8)
    ax.add_feature(cfeature.BORDERS.with_scale('50m'), linewidth=0.5)
    ax.add_feature(cfeature.STATES.with_scale('50m'), linewidth=0.3)
    ax.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())
    cb = fig.colorbar(im, ax=ax, orientation='vertical', shrink=0.75, pad=0.02)
    cb.set_label('Relative Humidity (%)')

plt.tight_layout()
plt.show()

# ----------------------------
# Step 9: Monthly Mean Time Series Plot
# ----------------------------

# Resample ERA5 and CMIP6 data to monthly frequency (1st day of each month, "1MS")
# and compute monthly mean (relative humidity)
rh_era5_monthly = rh_era5_cropped.resample(valid_time='1MS').mean(dim='valid_time')
hur_cmip6_monthly = hur_cmip6_cropped.resample(time='1MS').mean(dim='time')

# Compute regional mean to obtain monthly mean time series
rh_era5_series = rh_era5_monthly.mean(dim=['lat', 'lon'])
hur_cmip6_series = hur_cmip6_monthly.mean(dim=['lat', 'lon'])

# Extract time coordinates
era5_time = rh_era5_series.valid_time.values
cmip6_time = hur_cmip6_series.time.values

# Plotting
plt.figure(figsize=(12, 5))
plt.plot(era5_time, rh_era5_series, label='ERA5', color='blue')
plt.plot(cmip6_time, hur_cmip6_series, label='CMIP6', color='red')
plt.title("Monthly Mean Relative Humidity Time Series")
plt.ylabel("Relative Humidity (%)")
plt.xlabel("Time")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
