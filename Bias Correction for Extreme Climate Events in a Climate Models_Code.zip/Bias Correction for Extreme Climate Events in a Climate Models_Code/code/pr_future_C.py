import torch
import numpy as np
import xarray as xr
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from torch import nn
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import pandas as pd


# -----------------------------
# Define CNN + LSTM Architecture
# -----------------------------
class CNNLSTM(nn.Module):
    def __init__(self, input_len):
        super(CNNLSTM, self).__init__()
        # 1D CNN layer (extracts local temporal features from input sequences)
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=16, kernel_size=3, padding=1)
        self.relu = nn.ReLU()  # ReLU activation function for non-linearity
        # LSTM layer (captures long-term temporal dependencies)
        self.lstm = nn.LSTM(input_size=16, hidden_size=32,
                            batch_first=True)  # batch_first=True: [batch, seq_len, features]
        # Fully connected layer (maps LSTM output to residual prediction)
        self.fc = nn.Linear(32, 1)

    def forward(self, x):
        # Input shape: [batch_size, 1, input_len] (channel-first format)
        x = self.relu(self.conv1(x))  # CNN forward pass → [batch_size, 16, input_len]
        x = x.permute(0, 2, 1)  # Reshape for LSTM → [batch_size, input_len, 16]
        x, _ = self.lstm(x)  # LSTM forward pass → [batch_size, input_len, 32]
        x = self.fc(x[:, -1, :])  # Use only last time step for prediction → [batch_size, 1]
        return x


# -----------------------------
# Quantile Mapping Function
# -----------------------------
def quantile_mapping(obs, sim, sim_future):
    """
    Apply quantile mapping (QM) to correct future CMIP6 precipitation data using historical observations.

    Parameters:
        obs: Historical observed precipitation (1D array, e.g., ERA5 1950–2014)
        sim: Historical simulated precipitation (1D array, e.g., CMIP6 1950–2014)
        sim_future: Future simulated precipitation to correct (1D array, e.g., CMIP6 2015–2049)

    Returns:
        qm_corrected: QM-corrected future precipitation (1D array)
    """
    # Calculate quantiles (0 to 1, 1001 evenly spaced points for smooth mapping)
    quantiles = np.linspace(0, 1, 1001)
    obs_q = np.quantile(obs, quantiles)  # Quantile distribution of observations
    sim_q = np.quantile(sim, quantiles)  # Quantile distribution of historical simulations

    # Remove duplicate quantiles to avoid interpolation errors
    sim_q_unique, idx = np.unique(sim_q, return_index=True)
    obs_q_unique = obs_q[idx]

    # Create interpolation function (maps simulated quantiles to observed quantiles)
    qm_func = interp1d(
        sim_q_unique, obs_q_unique,
        bounds_error=False,
        fill_value=(obs_q_unique[0], obs_q_unique[-1])  # Extrapolate with min/max for out-of-bounds values
    )

    # Apply QM to future simulated data
    return qm_func(sim_future)


# -----------------------------
# Load Historical and Future Data
# -----------------------------
# Load datasets (ERA5: observations; CMIP6: historical simulations; future_ds: future simulations)
era5 = xr.open_dataset("ERA5_tp.nc", chunks={'time': 10})
cmip6 = xr.open_dataset("CMIP6_pr.nc", chunks={'time': 10})
future_ds = xr.open_dataset("pr_20150115-20491215.nc", chunks={'time': 10})

# Unit conversion to mm/day
era5 = era5['tp'] * 1000  # ERA5 'tp' (total precipitation) is in meters → convert to mm
cmip6 = cmip6['pr'] * 86400  # CMIP6 'pr' (precipitation flux) is in kg/m²/s → convert to mm/day
future = future_ds['pr'] * 86400  # Future CMIP6 data: same unit conversion as historical

# Coordinate standardization and data cleaning
era5 = era5.rename({'latitude': 'lat', 'longitude': 'lon'})  # Align ERA5 coordinates with CMIP6
cmip6 = cmip6.where(cmip6 != 1e20)  # Mask missing values in CMIP6 (flagged as 1e20)
era5 = era5.where(era5 < 1e10)  # Mask extreme outliers in ERA5

# Spatial and temporal subsetting (target region: e.g., CONUS; time: 1950–2014 for historical)
lat_min, lat_max = 25, 50  # Latitude range (25°N to 50°N)
lon_min, lon_max = -125, -66  # Longitude range (-125°W to -66°W)
lon_min_c, lon_max_c = lon_min + 360, lon_max + 360  # Convert W to E longitude (0–360°)

# Subset historical data (1950–2014)
era5 = era5.sel(
    lat=slice(lat_max, lat_min),  # Reverse latitude for ERA5 (descending order)
    lon=slice(lon_min_c, lon_max_c),
    valid_time=slice("1950", "2014")  # ERA5 time dimension: 'valid_time'
)
cmip6 = cmip6.sel(
    lat=slice(lat_min, lat_max),
    lon=slice(lon_min_c, lon_max_c),
    time=slice("1950", "2014")  # CMIP6 time dimension: 'time'
)

# Subset future data (no temporal slice → uses full 2015–2049 period from file)
future = future.sel(
    lat=slice(lat_min, lat_max),
    lon=slice(lon_min_c, lon_max_c)
)

# Compute regional mean (spatial average) and resample to monthly frequency
obs = era5.mean(dim=['lat', 'lon']).resample(valid_time='1MS').mean().values  # ERA5: monthly mean
sim_hist = cmip6.mean(dim=['lat', 'lon']).resample(time='1MS').mean().values  # CMIP6 historical: monthly mean
sim_future_raw = future.mean(dim=['lat', 'lon']).values  # Future CMIP6: raw (uncorrected) values

# -----------------------------
# Step 1: Apply Quantile Mapping (QM)
# -----------------------------
# Correct future CMIP6 data using QM (trained on 1950–2014 historical data)
qm_corrected = quantile_mapping(obs, sim_hist, sim_future_raw)


# -----------------------------
# Step 2: Use CNN-LSTM to Predict Residuals
# -----------------------------
def create_sequences(data, input_len=30):
    """
    Convert a 1D time series into input sequences for LSTM training/prediction.

    Parameters:
        data: 1D time series (e.g., QM-corrected future precipitation)
        input_len: Length of each input sequence (default: 30 time steps = 2.5 years)

    Returns:
        sequences: 2D array of shape (n_sequences, input_len)
    """
    return np.array([data[i:i + input_len] for i in range(len(data) - input_len)])


# Generate input sequences from QM-corrected data
input_len = 30
X_seq = create_sequences(qm_corrected, input_len)

# Convert sequences to PyTorch tensor (add channel dimension for CNN)
X_tensor = torch.tensor(X_seq, dtype=torch.float32).unsqueeze(1)  # Shape: [n_sequences, 1, input_len]

# Load pre-trained CNN-LSTM model and predict residuals
model = CNNLSTM(input_len)
model.load_state_dict(torch.load("cnn_lstm_residual_model.pth"))  # Load saved model weights
model.eval()  # Set model to evaluation mode

# Predict residuals (disable gradient computation for efficiency)
with torch.no_grad():
    residuals = model(X_tensor).squeeze().numpy()  # Squeeze to 1D array of residuals

# Trim QM-corrected data to match residual length (residuals start after first 'input_len' steps)
qm_trimmed = qm_corrected[input_len:]

# Final corrected precipitation: QM-corrected data + CNN-LSTM predicted residuals
deep_corrected = qm_trimmed + residuals

# -----------------------------
# Prepare Data for Comparison (Raw vs Corrected)
# -----------------------------
# Ensure raw and corrected data have the same length (trim raw data to match)
sim_future_raw_trimmed = sim_future_raw[input_len:]

# Create DataFrame for organized analysis (add date and temporal metadata)
full_dates = pd.date_range("2015-01", periods=len(deep_corrected), freq='MS')  # 'MS' = month-start frequency
df_comparison = pd.DataFrame({
    'date': full_dates,
    'raw': sim_future_raw_trimmed,  # Raw future CMIP6
    'corrected': deep_corrected  # QM + CNN-LSTM corrected future CMIP6
})
df_comparison['month'] = df_comparison['date'].dt.month  # Extract month (1–12)
df_comparison['year'] = df_comparison['date'].dt.year  # Extract year

# -----------------------------
# Define Extreme Precipitation Thresholds Using Historical Observations
# -----------------------------
# Use 95th and 99th percentiles of historical ERA5 (1950–2014) as extreme thresholds
threshold_95 = np.percentile(obs, 95)  # 95th percentile (moderate extreme)
threshold_99 = np.percentile(obs, 99)  # 99th percentile (severe extreme)

# Flag extreme events in raw and corrected data
df_comparison['extreme95_raw'] = df_comparison['raw'] > threshold_95
df_comparison['extreme99_raw'] = df_comparison['raw'] > threshold_99
df_comparison['extreme95_corrected'] = df_comparison['corrected'] > threshold_95
df_comparison['extreme99_corrected'] = df_comparison['corrected'] > threshold_99


# -----------------------------
# Helper Function: Calculate Duration of Consecutive Extreme Events
# -----------------------------
def calc_duration_series(extreme_series):
    """
    Calculate the duration of consecutive extreme events from a boolean time series.

    Parameters:
        extreme_series: 1D boolean array (True = extreme event, False = non-extreme)

    Returns:
        durations: List of consecutive extreme event durations (in months)
    """
    durations = []
    count = 0  # Track current consecutive event length
    for val in extreme_series:
        if val:
            count += 1  # Increment count if current month is extreme
        else:
            if count > 0:
                durations.append(count)  # Save duration if non-extreme month ends the sequence
            count = 0  # Reset count for non-extreme month
    # Save duration if sequence ends with extreme events
    if count > 0:
        durations.append(count)
    return durations


# -----------------------------
# 1. Comparison of Extreme Event Durations (Raw vs Corrected)
# -----------------------------
# Calculate consecutive extreme event durations for 95th and 99th percentiles
durations_95_raw = calc_duration_series(df_comparison['extreme95_raw'].values)
durations_95_corrected = calc_duration_series(df_comparison['extreme95_corrected'].values)
durations_99_raw = calc_duration_series(df_comparison['extreme99_raw'].values)
durations_99_corrected = calc_duration_series(df_comparison['extreme99_corrected'].values)

# Define histogram parameters (focus on durations up to 6 months)
max_duration = 6  # Maximum duration to visualize (longer durations are rare)
bins = np.arange(1, max_duration + 2) - 0.5  # Bins: [0.5, 1.5, ..., 6.5] → centers at 1–6

# Compute frequency histograms for durations
hist_95_raw, _ = np.histogram(durations_95_raw, bins=bins)
hist_95_corrected, _ = np.histogram(durations_95_corrected, bins=bins)
hist_99_raw, _ = np.histogram(durations_99_raw, bins=bins)
hist_99_corrected, _ = np.histogram(durations_99_corrected, bins=bins)

# Plot duration histograms (2 subplots: 95th and 99th percentiles)
plt.figure(figsize=(12, 6))

# Subplot 1: 95th Percentile Extreme Events
plt.subplot(1, 2, 1)
x = np.arange(1, max_duration + 1)  # X-axis: duration (1–6 months)
# Bar plot for raw vs corrected data
plt.bar(x - 0.2, hist_95_raw, width=0.4, label='Raw Data', color='lightgray', edgecolor='black')
plt.bar(x + 0.2, hist_95_corrected, width=0.4, label='Corrected Data', color='steelblue', edgecolor='black')
# Customize plot
plt.xlabel("Duration of Consecutive Extreme Months")
plt.ylabel("Frequency")
plt.title("95th Percentile Extreme Events")
plt.xticks(x)
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)

# Subplot 2: 99th Percentile Extreme Events
plt.subplot(1, 2, 2)
plt.bar(x - 0.2, hist_99_raw, width=0.4, label='Raw Data', color='lightgray', edgecolor='black')
plt.bar(x + 0.2, hist_99_corrected, width=0.4, label='Corrected Data', color='indianred', edgecolor='black')
# Customize plot
plt.xlabel("Duration of Consecutive Extreme Months")
plt.ylabel("Frequency")
plt.title("99th Percentile Extreme Events")
plt.xticks(x)
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)

# Add main title and adjust layout
plt.suptitle("Distribution of Extreme Precipitation Event Durations (2015–2049)", y=1.02)
plt.tight_layout()
plt.show()

# -----------------------------
# 2. Seasonal Distribution of Extreme Events (Raw vs Corrected)
# -----------------------------
# Count extreme events per month (1–12) for raw and corrected data
monthly_95_raw = df_comparison.groupby('month')['extreme95_raw'].sum()
monthly_95_corrected = df_comparison.groupby('month')['extreme95_corrected'].sum()
monthly_99_raw = df_comparison.groupby('month')['extreme99_raw'].sum()
monthly_99_corrected = df_comparison.groupby('month')['extreme99_corrected'].sum()

# Plot seasonal distribution (2 subplots: 95th and 99th percentiles)
plt.figure(figsize=(12, 6))
width = 0.35  # Bar width
x = np.arange(1, 13)  # X-axis: month (1–12)

# Subplot 1: 95th Percentile Extreme Events
plt.subplot(1, 2, 1)
plt.bar(x - width / 2, monthly_95_raw, width, label='Raw Data', color='lightgray', edgecolor='black')
plt.bar(x + width / 2, monthly_95_corrected, width, label='Corrected Data', color='steelblue', edgecolor='black')
# Customize plot
plt.xlabel("Month")
plt.ylabel("Number of Extreme Events")
plt.title("95th Percentile Extreme Events")
plt.xticks(x, ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
               'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5, axis='y')  # Horizontal grid only

# Subplot 2: 99th Percentile Extreme Events
plt.subplot(1, 2, 2)
plt.bar(x - width / 2, monthly_99_raw, width, label='Raw Data', color='lightgray', edgecolor='black')
plt.bar(x + width / 2, monthly_99_corrected, width, label='Corrected Data', color='indianred', edgecolor='black')
# Customize plot
plt.xlabel("Month")
plt.ylabel("Number of Extreme Events")
plt.title("99th Percentile Extreme Events")
plt.xticks(x, ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
               'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5, axis='y')

# Add main title and adjust layout
plt.suptitle("Seasonal Distribution of Extreme Precipitation Events (2015–2049)", y=1.02)
plt.tight_layout()
plt.show()

# -----------------------------
# Analysis Results Summary
# -----------------------------
print("=== Extreme Precipitation Event Duration Analysis ===")
# Calculate and print average durations
print(f"95th Percentile Threshold:")
print(f"  Raw Data Average Duration: {np.mean(durations_95_raw):.2f} months")
print(f"  Corrected Data Average Duration: {np.mean(durations_95_corrected):.2f} months")
print(f"99th Percentile Threshold:")
print(f"  Raw Data Average Duration: {np.mean(durations_99_raw):.2f} months")
print(f"  Corrected Data Average Duration: {np.mean(durations_99_corrected):.2f} months")


# Identify seasonal peak months (month with maximum extreme events)
def find_peak_month(monthly_data):
    """Return the month (1–12) with the maximum number of extreme events."""
    return monthly_data.idxmax()


print("\n=== Seasonal Peak Analysis ===")
print(f"95th Percentile Threshold:")
print(f"  Raw Data Peak Month: {find_peak_month(monthly_95_raw)}")
print(f"  Corrected Data Peak Month: {find_peak_month(monthly_95_corrected)}")
print(f"99th Percentile Threshold:")
print(f"  Raw Data Peak Month: {find_peak_month(monthly_99_raw)}")
print(f"  Corrected Data Peak Month: {find_peak_month(monthly_99_corrected)}")

# Interpret results and draw conclusions
print("\n=== Analysis Conclusions ===")
# Evaluate duration improvement
if np.mean(durations_95_corrected) < np.mean(durations_95_raw) and np.mean(durations_99_corrected) < np.mean(
        durations_99_raw):
    print(
        "✓ Machine learning correction effectively reduced the average duration of extreme precipitation events, improving the 'excessively long precipitation' bias.")
else:
    print(
        "✗ Machine learning correction failed to effectively improve the 'excessively long precipitation' bias; further model optimization is needed.")

# Evaluate seasonal peak consistency
if (find_peak_month(monthly_95_corrected) == find_peak_month(monthly_95_raw) and
        find_peak_month(monthly_99_corrected) == find_peak_month(monthly_99_raw)):
    print("✓ Corrected data maintained the same seasonal peak as raw data, with no significant seasonal shift.")
else:
    print(
        "✗ Corrected data showed a seasonal peak shift; the model's ability to learn seasonal patterns should be inspected.")