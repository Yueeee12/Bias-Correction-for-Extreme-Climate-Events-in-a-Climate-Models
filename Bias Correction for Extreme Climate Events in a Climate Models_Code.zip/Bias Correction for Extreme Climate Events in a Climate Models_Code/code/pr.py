import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

# ----------------------------
# Step 1: Load and preprocess data
# ----------------------------
cmip6 = xr.open_dataset("CMIP6_pr.nc")
era5 = xr.open_dataset("ERA5_tp.nc", chunks={"time": 10})

# Print time range for each dataset
print("CMIP6 time range:", cmip6.time.min().values, "to", cmip6.time.max().values)
print("ERA5 time range:", era5.valid_time.min().values, "to", era5.valid_time.max().values)

# Unit conversion: kg/m²/s -> mm/day; m -> mm
cmip6_daily = cmip6['pr'] * 86400  # Convert CMIP6 precipitation (kg/m²/s) to mm/day
era5_daily = era5['tp'] * 1000     # Convert ERA5 total precipitation (m) to mm

# Standardize coordinate names
era5_daily = era5_daily.rename({'latitude': 'lat', 'longitude': 'lon'})

# Handle missing values
cmip6_daily = cmip6_daily.where(cmip6_daily != 1e20)  # Mask CMIP6 missing values
era5_daily = era5_daily.where(era5_daily < 1e10)      # Mask ERA5 extreme/outlier values

# ----------------------------
# Step 2: Temporal and spatial subsetting
# ----------------------------
lat_min, lat_max = 25, 50          # Latitude range (25°N to 50°N)
lon_min, lon_max = -125, -66       # Longitude range (-125°W to -66°W)
lon_min_conv, lon_max_conv = lon_min + 360, lon_max + 360  # Convert W to E longitude (0-360°)

# Subset CMIP6 data (1950-2014)
cmip6_crop = cmip6_daily.sel(
    time=slice("1950", "2014"),
    lat=slice(lat_min, lat_max),
    lon=slice(lon_min_conv, lon_max_conv)
)

# Subset ERA5 data (1950-2014) - note reversed latitude order for ERA5
era5_crop = era5_daily.sel(
    valid_time=slice("1950", "2014"),
    lat=slice(lat_max, lat_min),  # ERA5 often uses descending latitude
    lon=slice(lon_min_conv, lon_max_conv)
)

# Apply 3-day moving average to reduce short-term anomalies
cmip6_crop = cmip6_crop.rolling(time=3, center=True).mean()
era5_crop = era5_crop.rolling(valid_time=3, center=True).mean()


# ----------------------------
# Step 3: Spatial distribution of mean precipitation
# ----------------------------
# Calculate temporal means
mean_cmip6 = cmip6_crop.mean(dim='time')
mean_era5 = era5_crop.mean(dim='valid_time')

# Interpolate CMIP6 to ERA5 grid for direct comparison
mean_cmip6_interp = mean_cmip6.interp(lat=mean_era5.lat, lon=mean_era5.lon)

# Calculate difference (ERA5 - CMIP6)
diff_mean = mean_era5 - mean_cmip6_interp

# Create plots
fig, axs = plt.subplots(1, 3, figsize=(20, 6), subplot_kw={'projection': ccrs.PlateCarree()})

# Plot parameters
titles = [
    'CMIP6 Mean Precipitation (mm/day)',
    'ERA5 Mean Precipitation (mm/day)',
    'Difference (ERA5 - CMIP6)'
]
cmaps = ['Blues', 'Greens', 'RdBu_r']
vmin_list = [0, 0, -np.nanmax(np.abs(diff_mean))]  # Symmetric range for difference plot
vmax_list = [
    np.nanpercentile(mean_cmip6_interp, 99),  # 99th percentile to exclude extreme outliers
    np.nanpercentile(mean_era5, 99),
    -vmin_list[2]  # Symmetric max for difference
]

# Plot each map
for ax, data, title, cmap, vmin, vmax in zip(
    axs, [mean_cmip6_interp, mean_era5, diff_mean], titles, cmaps, vmin_list, vmax_list
):
    im = data.plot(
        ax=ax,
        transform=ccrs.PlateCarree(),
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        add_colorbar=False
    )
    ax.set_title(title, fontsize=12)
    ax.coastlines()  # Add coastlines
    ax.add_feature(cfeature.BORDERS, linewidth=0.5)  # Add country borders
    ax.add_feature(cfeature.STATES.with_scale('50m'), linewidth=0.3)  # Add state borders
    ax.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())  # Set map extent
    # Add colorbar
    cb = fig.colorbar(im, ax=ax, orientation='vertical', shrink=0.75, pad=0.02)
    cb.set_label('mm/day')

plt.tight_layout()
plt.show()

# ----------------------------
# Step 4: Monthly mean time series
# ----------------------------
# Calculate monthly climatology (average for each calendar month)
cmip6_monthly = cmip6_crop.mean(dim=["lat", "lon"]).groupby("time.month").mean()
era5_monthly = era5_crop.mean(dim=["lat", "lon"]).groupby("valid_time.month").mean()

# Create plot
plt.figure(figsize=(10, 5))
plt.plot(cmip6_monthly.month, cmip6_monthly, label='CMIP6', marker='o')
plt.plot(era5_monthly.month, era5_monthly, label='ERA5', marker='s')
plt.title('Monthly Mean Precipitation Comparison (mm/day)', fontsize=14)
plt.xlabel('Month')
plt.ylabel('Precipitation (mm/day)')
plt.xticks(
    np.arange(1, 13),
    ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
     'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
)
plt.grid(True, linestyle='--', alpha=0.6)
plt.legend()
plt.tight_layout()
plt.show()

# ----------------------------
# Step 5: Spatial distribution of 95th percentile precipitation intensity
# ----------------------------
# Calculate 95th percentile (extreme precipitation threshold)
cmip6_p95 = cmip6_crop.quantile(0.95, dim="time", skipna=True)
era5_p95 = era5_crop.quantile(0.95, dim="valid_time", skipna=True)

# Interpolate CMIP6 to ERA5 grid
cmip6_p95_interp = cmip6_p95.interp(lat=era5_p95.lat, lon=era5_p95.lon)

# Calculate difference (ERA5 - CMIP6)
diff_p95 = era5_p95 - cmip6_p95_interp

# Create plots
fig, axs = plt.subplots(1, 3, figsize=(20, 6), subplot_kw={'projection': ccrs.PlateCarree()})

# Plot parameters
titles = [
    'CMIP6 95th Percentile (mm/day)',
    'ERA5 95th Percentile (mm/day)',
    'Difference (ERA5 - CMIP6)'
]
cmaps = ['YlOrBr', 'YlGnBu', 'RdBu_r']
vmin_list = [0, 0, -np.nanmax(np.abs(diff_p95))]  # Symmetric range for difference
vmax_list = [
    np.nanpercentile(cmip6_p95_interp, 99),
    np.nanpercentile(era5_p95, 99),
    -vmin_list[2]  # Symmetric max for difference
]

# Plot each map
for ax, data, title, cmap, vmin, vmax in zip(
    axs, [cmip6_p95_interp, era5_p95, diff_p95], titles, cmaps, vmin_list, vmax_list
):
    im = data.plot(
        ax=ax,
        transform=ccrs.PlateCarree(),
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        add_colorbar=False
    )
    ax.set_title(title, fontsize=12)
    ax.coastlines()
    ax.add_feature(cfeature.BORDERS, linewidth=0.5)
    ax.add_feature(cfeature.STATES.with_scale('50m'), linewidth=0.3)
    ax.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())
    # Add colorbar
    cb = fig.colorbar(im, ax=ax, orientation='vertical', shrink=0.75, pad=0.02)
    cb.set_label('mm/day')

plt.tight_layout()
plt.show()