import xarray as xr
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

# ----------------------------
# Step 1: Load Data
# ----------------------------
# Future CMIP6 maximum temperature data
ds_tasmax_future = xr.open_dataset("tasmax_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc", chunks={'time': 10})
future_tasmax = ds_tasmax_future['tasmax']  # Future CMIP6 maximum temperature variable (Unit: K)

# ERA5 maximum temperature data
era5_ds = xr.open_dataset("mx2t_1.nc", chunks={'time': 10})
era5_tasmax = era5_ds['mx2t']  # ERA5 maximum temperature variable (Assumed unit: K)

# Output time ranges
print("CMIP6 future time range:", ds_tasmax_future.time.min().values, "to", ds_tasmax_future.time.max().values)
print("ERA5 time range:", era5_ds.valid_time.min().values, "to", era5_ds.valid_time.max().values)

# ----------------------------
# Step 2: Handle Missing Values
# ----------------------------
future_tasmax = future_tasmax.where(future_tasmax != 1e20)
era5_tasmax = era5_tasmax.where(era5_tasmax < 1e10)

# ----------------------------
# Step 3: Crop Region (CONUS)
# ----------------------------
lat_min, lat_max = 24.5, 49.4
lon_min, lon_max = -125, -67
lon_min_conv = lon_min + 360
lon_max_conv = lon_max + 360

# Rename ERA5 coordinates
if 'latitude' in era5_tasmax.dims:
    era5_tasmax = era5_tasmax.rename({'latitude': 'lat', 'longitude': 'lon'})

# Convert ERA5 longitude to 0~360 range
if (era5_tasmax.lon < 0).any():
    era5_tasmax['lon'] = era5_tasmax['lon'] % 360

# Crop data to target region & time period
era5_tasmax_cropped = era5_tasmax.sel(
    valid_time=slice("2015", "2025"),
    lat=slice(lat_max, lat_min),
    lon=slice(lon_min_conv, lon_max_conv)
)
future_tasmax_cropped = future_tasmax.sel(
    time=slice("2015", "2025"),
    lat=slice(lat_min, lat_max),
    lon=slice(lon_min_conv, lon_max_conv)
)

# ----------------------------
# Step 4: Calculate 95th Percentile
# ----------------------------
future_tasmax_p95 = future_tasmax_cropped.quantile(0.95, dim='time')
era5_tasmax_p95 = era5_tasmax_cropped.quantile(0.95, dim='valid_time')

# Interpolate ERA5 to CMIP6 grid
era5_tasmax_p95_interp = era5_tasmax_p95.interp(
    lat=future_tasmax_p95.lat,
    lon=future_tasmax_p95.lon
)

# ----------------------------
# Step 5: Bias Correction (Mean-Based)
# ----------------------------
future_tasmax_mean = future_tasmax_cropped.mean(dim='time')
era5_tasmax_mean = era5_tasmax_cropped.mean(dim='valid_time')

# Interpolate ERA5 mean to CMIP6 grid
era5_tasmax_mean_interp = era5_tasmax_mean.interp(
    lat=future_tasmax_mean.lat,
    lon=future_tasmax_mean.lon
)

# Calculate bias (ERA5 - CMIP6)
bias = era5_tasmax_mean_interp - future_tasmax_mean

# Apply bias correction to CMIP6 95th percentile
future_tasmax_p95_corrected = future_tasmax_p95 + bias

# ----------------------------
# Step 6: Mapping Function
# ----------------------------
def plot_map(ax, data, title, cmap, vmin=None, vmax=None, extend='both'):
    im = data.plot.pcolormesh(
        ax=ax,
        transform=ccrs.PlateCarree(),
        cmap=cmap,
        vmin=vmin,
        vmax=vmax,
        add_colorbar=False,
        shading='auto'
    )
    ax.set_title(title, fontsize=12)
    ax.coastlines()
    ax.add_feature(cfeature.BORDERS, linewidth=0.5)
    ax.add_feature(cfeature.STATES.with_scale('50m'), linewidth=0.3)
    ax.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())
    return im

# ----------------------------
# Step 7: Plot Three Maps (Raw CMIP6, Corrected CMIP6, ERA5)
# ----------------------------
fig, axs = plt.subplots(1, 3, figsize=(21, 6), subplot_kw={'projection': ccrs.PlateCarree()})

titles = [
    'CMIP6 Future Heatwave (Raw) (K) 2015-2025',
    'CMIP6 Future Heatwave (Bias Corrected) (K) 2015-2025',
    'ERA5 Heatwave (K) 2015-2025'
]
cmaps = ['YlOrRd', 'YlOrRd', 'YlOrRd']

# Global unified color scale range
vmin_global = float(np.nanmin([future_tasmax_p95, future_tasmax_p95_corrected, era5_tasmax_p95_interp]))
vmax_global = float(np.nanmax([future_tasmax_p95, future_tasmax_p95_corrected, era5_tasmax_p95_interp]))

data_list = [future_tasmax_p95, future_tasmax_p95_corrected, era5_tasmax_p95_interp]

for ax, data, title, cmap in zip(axs, data_list, titles, cmaps):
    im = plot_map(ax, data, title, cmap, vmin=vmin_global, vmax=vmax_global)
    cb = fig.colorbar(im, ax=ax, orientation='vertical', shrink=0.75, pad=0.02)
    cb.set_label("K")

plt.tight_layout()
plt.show()

# ----------------------------
# Step 8: Crop Data for 2015-2049 Period
# ----------------------------
future_tasmax_cropped_long = future_tasmax.sel(
    time=slice("2015", "2049"),
    lat=slice(lat_min, lat_max),
    lon=slice(lon_min_conv, lon_max_conv)
)

# Calculate long-term mean maximum temperature
future_tasmax_mean_long = future_tasmax_cropped_long.mean(dim='time')

# Apply bias correction
future_tasmax_corrected_long = future_tasmax_mean_long + bias

# ----------------------------
# Step 9: Plot Raw vs Corrected Comparison Maps
# ----------------------------
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

fig, axs = plt.subplots(1, 2, figsize=(18, 6), subplot_kw={'projection': ccrs.PlateCarree()})

titles = ['CMIP6 Future Heatwave (Raw) 2015-2049 (K)',
          'CMIP6 Future Heatwave (Bias Corrected) 2015-2049 (K)']

data_list = [future_tasmax_mean_long, future_tasmax_corrected_long]

# Global unified color scale range
vmin_global = float(np.nanmin([future_tasmax_mean_long, future_tasmax_corrected_long]))
vmax_global = float(np.nanmax([future_tasmax_mean_long, future_tasmax_corrected_long]))

for ax, data, title in zip(axs, data_list, titles):
    im = data.plot.pcolormesh(
        ax=ax,
        transform=ccrs.PlateCarree(),
        cmap='YlOrRd',
        vmin=vmin_global,
        vmax=vmax_global,
        add_colorbar=False,
        shading='auto'
    )
    ax.coastlines()
    ax.add_feature(cfeature.BORDERS, linewidth=0.5)
    ax.add_feature(cfeature.STATES.with_scale('50m'), linewidth=0.3)
    ax.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())
    ax.set_title(title, fontsize=12)

# Add shared colorbar
cb = fig.colorbar(im, ax=axs, orientation='vertical', shrink=0.8, pad=0.02)
cb.set_label("K")

plt.tight_layout()
plt.show()


# ----------------------------
# Step 8: Crop Data for 2015-2049 Period (Duplicate Step, Retained as in Original)
# ----------------------------
future_tasmax_cropped_long = future_tasmax.sel(
    time=slice("2015", "2049"),
    lat=slice(lat_min, lat_max),
    lon=slice(lon_min_conv, lon_max_conv)
)

# Calculate long-term mean maximum temperature
future_tasmax_mean_long = future_tasmax_cropped_long.mean(dim='time')

# Apply bias correction
future_tasmax_corrected_long = future_tasmax_mean_long + bias

# ----------------------------
# Step 9: Plot Raw vs Corrected Comparison Maps (Separate Colorbars for Each Map)
# ----------------------------
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

fig, axs = plt.subplots(1, 2, figsize=(18, 6), subplot_kw={'projection': ccrs.PlateCarree()})

titles = ['CMIP6 Future Heatwave (Raw) 2015-2049 (K)',
          'CMIP6 Future Heatwave (Bias Corrected) 2015-2049 (K)']

data_list = [future_tasmax_mean_long, future_tasmax_corrected_long]

for ax, data, title in zip(axs, data_list, titles):
    im = data.plot.pcolormesh(
        ax=ax,
        transform=ccrs.PlateCarree(),
        cmap='YlOrRd',
        add_colorbar=False,
        shading='auto'
    )
    ax.coastlines()
    ax.add_feature(cfeature.BORDERS, linewidth=0.5)
    ax.add_feature(cfeature.STATES.with_scale('50m'), linewidth=0.3)
    ax.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())
    ax.set_title(title, fontsize=12)

    # Add separate colorbar for each subplot
    cb = fig.colorbar(im, ax=ax, orientation='vertical', shrink=0.8, pad=0.02)
    cb.set_label("K")

plt.tight_layout()
plt.show()