import torch
import numpy as np
import xarray as xr
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from torch import nn
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import pandas as pd
import matplotlib.ticker as mticker
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER


# -----------------------------
# Define CNN + LSTM architecture
# -----------------------------
class CNNLSTM(nn.Module):
    def __init__(self, input_len):
        super(CNNLSTM, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=16, kernel_size=3, padding=1)
        self.relu = nn.ReLU()
        self.lstm = nn.LSTM(input_size=16, hidden_size=32, batch_first=True)
        self.fc = nn.Linear(32, 1)

    def forward(self, x):
        x = self.relu(self.conv1(x))         # [batch, 16, seq]
        x = x.permute(0, 2, 1)               # [batch, seq, 16]
        x, _ = self.lstm(x)                  # [batch, seq, 32]
        x = self.fc(x[:, -1, :])             # [batch, 1]
        return x

# -----------------------------
# Quantile Mapping function
# -----------------------------
def quantile_mapping(obs, sim, sim_future):
    quantiles = np.linspace(0, 1, 1001)
    obs_q = np.quantile(obs, quantiles)
    sim_q = np.quantile(sim, quantiles)
    sim_q_unique, idx = np.unique(sim_q, return_index=True)
    obs_q_unique = obs_q[idx]
    qm_func = interp1d(sim_q_unique, obs_q_unique, bounds_error=False,
                       fill_value=(obs_q_unique[0], obs_q_unique[-1]))
    return qm_func(sim_future)

# -----------------------------
# Load historical and future data
# -----------------------------
era5 = xr.open_dataset("ERA5_tp.nc", chunks={'time': 10})
cmip6 = xr.open_dataset("CMIP6_pr.nc", chunks={'time': 10})
future_ds = xr.open_dataset("pr_20150115-20491215.nc", chunks={'time': 10})

# Convert units to mm/day
era5 = era5['tp'] * 1000
cmip6 = cmip6['pr'] * 86400
future = future_ds['pr'] * 86400

# Coordinate and regional cropping
era5 = era5.rename({'latitude': 'lat', 'longitude': 'lon'})
cmip6 = cmip6.where(cmip6 != 1e20)
era5 = era5.where(era5 < 1e10)

lat_min, lat_max = 25, 50
lon_min, lon_max = -125, -66
lon_min_c, lon_max_c = lon_min + 360, lon_max + 360

era5 = era5.sel(lat=slice(lat_max, lat_min), lon=slice(lon_min_c, lon_max_c),
                valid_time=slice("1950", "2014"))
cmip6 = cmip6.sel(lat=slice(lat_min, lat_max), lon=slice(lon_min_c, lon_max_c),
                  time=slice("1950", "2014"))
future = future.sel(lat=slice(lat_min, lat_max), lon=slice(lon_min_c, lon_max_c))

# Mean time series
obs = era5.mean(dim=['lat', 'lon']).resample(valid_time='1MS').mean().values
sim_hist = cmip6.mean(dim=['lat', 'lon']).resample(time='1MS').mean().values
sim_future = future.mean(dim=['lat', 'lon']).values

# -----------------------------
# Step 1: Apply Quantile Mapping
# -----------------------------
qm_corrected = quantile_mapping(obs, sim_hist, sim_future)

# -----------------------------
# Step 2: Use CNN-LSTM to predict residuals
# -----------------------------
def create_sequences(data, input_len=30):
    return np.array([data[i:i+input_len] for i in range(len(data)-input_len)])

input_len = 30
X_seq = create_sequences(qm_corrected, input_len)
X_tensor = torch.tensor(X_seq, dtype=torch.float32).unsqueeze(1)

# Load model and predict residuals
model = CNNLSTM(input_len)
model.load_state_dict(torch.load("cnn_lstm_residual_model.pth"))
model.eval()

with torch.no_grad():
    residuals = model(X_tensor).squeeze().numpy()

# Trim QM-corrected series
qm_trimmed = qm_corrected[input_len:]

# Final deep corrected precipitation
deep_corrected = qm_trimmed + residuals

# -----------------------------
# Combine historical and corrected future series (1950-2049)
# -----------------------------
full_precip = np.concatenate([obs, deep_corrected])
full_dates = pd.date_range("1950-01", periods=len(full_precip), freq='MS')

# Convert to DataFrame for analysis and plotting
df_full = pd.DataFrame({
    'date': full_dates,
    'precip': full_precip
})
df_full['year'] = df_full['date'].dt.year

# -----------------------------
# Define extreme thresholds using historical observations
# -----------------------------
threshold_95 = np.percentile(obs, 95)
threshold_99 = np.percentile(obs, 99)
obs_max = np.max(obs)

# Identify extreme events
df_full['extreme95'] = df_full['precip'] > threshold_95
df_full['extreme99'] = df_full['precip'] > threshold_99
df_full['beyond_hist_max'] = df_full['precip'] > obs_max

from scipy.stats import genextreme
import numpy as np
import matplotlib.pyplot as plt

# -----------------------------
# Define years for short and long periods
# -----------------------------
years_short = np.arange(2015, 2026)   # 2015-2025
years_long = np.arange(2015, 2050)    # 2015-2049

# -----------------------------
# Helper function to compute annual maxima safely
# -----------------------------
def annual_max_from_monthly(data, years, months_per_year=12):
    annual_max = []
    total_months = len(years) * months_per_year
    data_trimmed = data[:total_months]  # Trim to available length
    start_idx = 0
    for _ in years:
        end_idx = start_idx + months_per_year
        if end_idx > len(data_trimmed):
            break
        annual_max.append(data_trimmed[start_idx:end_idx].max())
        start_idx = end_idx
    return np.array(annual_max)

# -----------------------------
# Compute annual maxima
# -----------------------------
# Short period 2015-2025
era5_annual_max = df_full[(df_full['year'] >= 2015) & (df_full['year'] <= 2025)].groupby('year')['precip'].max().values
raw_annual_max = annual_max_from_monthly(sim_future, years_short)
qm_annual_max = annual_max_from_monthly(qm_corrected, years_short)
deep_annual_max = annual_max_from_monthly(deep_corrected, years_short)

# Long period 2015-2049
raw_annual_max_long = annual_max_from_monthly(sim_future, years_long)
qm_annual_max_long = annual_max_from_monthly(qm_corrected, years_long)
deep_annual_max_long = annual_max_from_monthly(deep_corrected, years_long)

# -----------------------------
# Fit GEV
# -----------------------------
def fit_gev(data):
    c, loc, scale = genextreme.fit(data)
    return c, loc, scale

# Short period
c_era5, loc_era5, scale_era5 = fit_gev(era5_annual_max)
c_raw, loc_raw, scale_raw = fit_gev(raw_annual_max)
c_qm, loc_qm, scale_qm = fit_gev(qm_annual_max)
c_deep, loc_deep, scale_deep = fit_gev(deep_annual_max)

# Long period
c_raw_long, loc_raw_long, scale_raw_long = fit_gev(raw_annual_max_long)
c_qm_long, loc_qm_long, scale_qm_long = fit_gev(qm_annual_max_long)
c_deep_long, loc_deep_long, scale_deep_long = fit_gev(deep_annual_max_long)

# -----------------------------
# Compute return levels
# -----------------------------
return_periods = np.array([2, 5, 10, 20, 50, 100])
def gev_return_level(c, loc, scale, T):
    return genextreme.ppf(1 - 1/np.array(T), c, loc=loc, scale=scale)

# Short period
rl_era5 = gev_return_level(c_era5, loc_era5, scale_era5, return_periods)
rl_raw = gev_return_level(c_raw, loc_raw, scale_raw, return_periods)
rl_qm = gev_return_level(c_qm, loc_qm, scale_qm, return_periods)
rl_deep = gev_return_level(c_deep, loc_deep, scale_deep, return_periods)

# Long period
rl_raw_long = gev_return_level(c_raw_long, loc_raw_long, scale_raw_long, return_periods)
rl_qm_long = gev_return_level(c_qm_long, loc_qm_long, scale_qm_long, return_periods)
rl_deep_long = gev_return_level(c_deep_long, loc_deep_long, scale_deep_long, return_periods)

# -----------------------------
# Plot short period 2015-2025
# -----------------------------
plt.figure(figsize=(8,6))
plt.plot(return_periods, rl_era5, 'o-', label='ERA5 (2015-2025)', color='green')
plt.plot(return_periods, rl_raw, '^-', label='Raw CMIP6 (2015-2025)', color='gray')
plt.plot(return_periods, rl_qm, 's-', label='QM (2015-2025)', color='skyblue')
plt.plot(return_periods, rl_deep, 'd-', label='QM + CNN-LSTM (2015-2025)', color='salmon')
plt.xlabel('Return Period (years)')
plt.ylabel('Return Level (mm/day)')
plt.title('GEV Return Level Plot (2015-2025)')
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend()
plt.tight_layout()
plt.show()

# -----------------------------
# Plot long period 2015-2049
# -----------------------------
plt.figure(figsize=(8,6))
plt.plot(return_periods, rl_raw_long, '^-', label='Raw CMIP6 (2015-2049)', color='gray')
plt.plot(return_periods, rl_qm_long, 's-', label='QM (2015-2049)', color='skyblue')
plt.plot(return_periods, rl_deep_long, 'd-', label='QM + CNN-LSTM (2015-2049)', color='salmon')
plt.xlabel('Return Period (years)')
plt.ylabel('Return Level (mm/day)')
plt.title('GEV Return Level Plot (2015-2049)')
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend()
plt.tight_layout()
plt.show()

# -----------------------------
# Print GEV parameters
# -----------------------------
print("✅ GEV parameters (2015-2025):")
print(f"ERA5: shape={c_era5:.3f}, loc={loc_era5:.3f}, scale={scale_era5:.3f}")
print(f"Raw CMIP6: shape={c_raw:.3f}, loc={loc_raw:.3f}, scale={scale_raw:.3f}")
print(f"QM: shape={c_qm:.3f}, loc={loc_qm:.3f}, scale={scale_qm:.3f}")
print(f"QM + CNN-LSTM: shape={c_deep:.3f}, loc={loc_deep:.3f}, scale={scale_deep:.3f}")

print("\n✅ GEV parameters (2015-2049):")
print(f"Raw CMIP6: shape={c_raw_long:.3f}, loc={loc_raw_long:.3f}, scale={scale_raw_long:.3f}")
print(f"QM: shape={c_qm_long:.3f}, loc={loc_qm_long:.3f}, scale={scale_qm_long:.3f}")
print(f"QM + CNN-LSTM: shape={c_deep_long:.3f}, loc={loc_deep_long:.3f}, scale={scale_deep_long:.3f}")
