# -*- coding: utf-8 -*-
import numpy as np
import pandas as pd
import xarray as xr
import matplotlib.pyplot as plt
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from scipy.interpolate import interp1d

# =========================
# Utility functions: Time & calendar
# =========================
def detect_time_dim(da: xr.DataArray) -> str:
    if "time" in da.dims:
        return "time"
    if "valid_time" in da.dims:
        return "valid_time"
    for d in da.dims:
        if "time" in d:
            return d
    raise ValueError(f"Time dimension not found, dims={da.dims}")

def to_datetime_index(da: xr.DataArray, dim: str) -> pd.DatetimeIndex:
    try:
        idx = da.indexes[dim]
        try:
            return pd.DatetimeIndex(idx.to_datetimeindex())
        except Exception:
            pass
    except Exception:
        pass
    cal = None
    try:
        cal = getattr(da[dim].dt, "calendar", None)
    except Exception:
        pass
    if cal == "360_day":
        da2 = da.convert_calendar("standard", use_cftime=False, dim=dim, align_on="date")
    else:
        da2 = da.convert_calendar("standard", use_cftime=False, dim=dim)
    return pd.to_datetime(da2[dim].values)

# =========================
# Monthly quantile mapping (QM) function
# =========================
def seasonal_qm_fit_apply(obs_vals, obs_dates, sim_vals, sim_dates, target_vals, target_dates, n_q=1001):
    out = np.empty_like(target_vals, dtype=float)
    for m in range(1, 13):
        o = np.asarray(obs_vals[obs_dates.month == m], float)
        s = np.asarray(sim_vals[sim_dates.month == m], float)
        t = np.asarray(target_vals[target_dates.month == m], float)
        q = np.linspace(0, 1, n_q)
        o_q = np.quantile(o, q)
        s_q = np.quantile(s, q)
        s_q_u, idx = np.unique(s_q, return_index=True)
        o_q_u = o_q[idx]
        f = interp1d(s_q_u, o_q_u, bounds_error=False, fill_value=(o_q_u[0], o_q_u[-1]))
        out[target_dates.month == m] = f(t)
    return out

def make_sequences(arr, L=60):
    arr = np.asarray(arr, float)
    return np.array([arr[i:i+L] for i in range(len(arr)-L)])

# =========================
# CNN+LSTM model
# =========================
class CNNLSTM(nn.Module):
    def __init__(self, input_len):
        super().__init__()
        self.conv1 = nn.Conv1d(1, 16, kernel_size=3, padding=1)
        self.relu = nn.ReLU()
        self.lstm = nn.LSTM(16, 32, batch_first=True)
        self.fc = nn.Linear(32, 1)
        self.input_len = input_len
    def forward(self, x):
        x = self.relu(self.conv1(x))     # [B,16,L]
        x = x.permute(0, 2, 1)           # [B,L,16]
        x, _ = self.lstm(x)              # [B,L,32]
        y = self.fc(x[:, -1, :])         # [B,1]
        return y.squeeze(1)

# =========================
# Data reading and preprocessing (ERA5 2015–2025 & future 2015–2049)
# =========================

# Read ERA5 shortwave radiation and convert units (J/m² to W/m²)
era5_ds = xr.open_dataset("ERA5_ssr.nc", chunks={'time': 10})
era5 = era5_ds['ssr'] / 86400  # Convert J/m² to W/m² (average power)

# Read CMIP6 future data, typically W/m²
future_ds = xr.open_dataset("rsds_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc", chunks={'time': 10})
future = future_ds['rsds']

# Rename coordinates if necessary
if "latitude" in era5.coords:
    era5 = era5.rename({"latitude": "lat", "longitude": "lon"})
if "latitude" in future.coords:
    future = future.rename({"latitude": "lat", "longitude": "lon"})

# Remove invalid values
era5 = era5.where(np.isfinite(era5) & (era5 < 1e5))
future = future.where(np.isfinite(future) & (future < 1e5))

# Regional cropping (example: North America)
lat_min, lat_max = 25, 50
lon_min, lon_max = -125, -66
lon_min_c, lon_max_c = lon_min + 360, lon_max + 360  # CMIP6 longitude 0-360

era5 = era5.sel(lat=slice(lat_max, lat_min), lon=slice(lon_min_c, lon_max_c))
future = future.sel(lat=slice(lat_min, lat_max), lon=slice(lon_min_c, lon_max_c))

# Time selection & monthly mean
t_era5 = detect_time_dim(era5)
era5_2015_2025 = era5.sel({t_era5: slice("2015", "2025")})
future_2015_2049 = future.sel(time=slice("2015", "2049"))

era5_mon = era5_2015_2025.mean(dim=["lat", "lon"]).resample({t_era5: "1MS"}).mean()
future_mon = future_2015_2049.mean(dim=["lat", "lon"]).resample(time="1MS").mean()

# Time indices
dates_era5 = to_datetime_index(era5_mon, t_era5)
dates_future = to_datetime_index(future_mon, "time")

# Numeric sequences
obs_vals = era5_mon.values
target_vals = future_mon.values

# Future overlap segment (2015–2025)
future_mon_1525 = future_mon.sel(time=slice("2015", "2025"))
sim_vals = future_mon_1525.values
sim_dates = to_datetime_index(future_mon_1525, "time")

# Safety check
if len(obs_vals) == 0 or len(sim_vals) == 0:
    raise RuntimeError("No monthly mean data in ERA5 or future for 2015–2025.")

# =========================
# Step 1: Monthly QM (fit: 2015–2025; apply: 2015–2049)
# =========================
qm_future_all = seasonal_qm_fit_apply(
    obs_vals=obs_vals, obs_dates=dates_era5,
    sim_vals=sim_vals, sim_dates=sim_dates,
    target_vals=target_vals, target_dates=dates_future,
    n_q=1001
)
qm_future_all = np.clip(qm_future_all, 0, None)  # Radiation non-negative

# =========================
# Step 2: Train CNN-LSTM on residuals (2015–2025) and apply to 2015–2049
# =========================
mask_overlap = (dates_future >= dates_era5.min()) & (dates_future <= dates_era5.max())
qm_overlap = qm_future_all[mask_overlap]
dates_overlap = dates_future[mask_overlap]

# Residuals: ERA5 - QM(future)
if len(qm_overlap) != len(obs_vals):
    df_obs = pd.DataFrame({"date": dates_era5, "obs": obs_vals}).set_index("date")
    df_qm = pd.DataFrame({"date": dates_overlap, "qm": qm_overlap}).set_index("date")
    joined = df_obs.join(df_qm, how="inner")
    obs_tr = joined["obs"].values
    qm_tr = joined["qm"].values
else:
    obs_tr = obs_vals
    qm_tr = qm_overlap

residuals_train = (obs_tr - qm_tr).astype(float)

# Generate training sequences
input_len = 60  # 5-year window (monthly)
X_np = make_sequences(qm_tr, L=input_len)
y_np = residuals_train[input_len:]

# Standardize
x_mean, x_std = X_np.mean(), X_np.std() + 1e-8
Xn = (X_np - x_mean) / x_std
y_mean, y_std = y_np.mean(), y_np.std() + 1e-8
yn = (y_np - y_mean) / y_std

X_tensor = torch.tensor(Xn, dtype=torch.float32).unsqueeze(1)
y_tensor = torch.tensor(yn, dtype=torch.float32)

# 80/20 train-validation split
n = len(X_tensor)
ntr = max(int(0.8 * n), 1)
X_tr, X_va = X_tensor[:ntr], X_tensor[ntr:]
y_tr, y_va = y_tensor[:ntr], y_tensor[ntr:]

train_loader = DataLoader(TensorDataset(X_tr, y_tr), batch_size=64, shuffle=True)
val_loader = DataLoader(TensorDataset(X_va, y_va), batch_size=64) if len(X_va) > 0 else None

# Train model
model = CNNLSTM(input_len=input_len)
optimizer = optim.AdamW(model.parameters(), lr=1e-3, weight_decay=1e-5)
criterion = nn.MSELoss()
best_val, patience, max_pat = np.inf, 0, 30
for ep in range(300):
    model.train()
    tr_losses = []
    for bx, by in train_loader:
        optimizer.zero_grad()
        pred = model(bx)
        loss = criterion(pred, by)
        loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), 5.0)
        optimizer.step()
        tr_losses.append(loss.item())
    if val_loader is not None:
        model.eval()
        va_losses = []
        with torch.no_grad():
            for bx, by in val_loader:
                va_losses.append(criterion(model(bx), by).item())
        va = np.mean(va_losses)
    else:
        va = np.mean(tr_losses)
    tr = np.mean(tr_losses)
    print(f"Epoch {ep+1:03d}  Train {tr:.6f}  Val {va:.6f}")
    if va < best_val - 1e-6:
        best_val, patience = va, 0
        torch.save(model.state_dict(), "best_cnn_lstm_solar.pth")
    else:
        patience += 1
        if patience >= max_pat:
            print("Early stopping."); break

model.load_state_dict(torch.load("best_cnn_lstm_solar.pth", map_location="cpu"))
model.eval()

def predict_residuals_on_series(qm_series, L, x_mean, x_std, y_mean, y_std, mdl):
    qm_series = np.asarray(qm_series, float)
    res = np.zeros_like(qm_series)
    cnt = np.zeros_like(qm_series)
    with torch.no_grad():
        for i in range(len(qm_series) - L):
            window = qm_series[i:i+L]
            win_n = (window - x_mean) / x_std
            x = torch.tensor(win_n, dtype=torch.float32).unsqueeze(0).unsqueeze(1)
            pred_n = mdl(x).cpu().numpy()[0]
            pred = pred_n * y_std + y_mean
            res[i+L] += pred
            cnt[i+L] += 1
    cnt[cnt == 0] = 1
    return res / cnt

pred_res_1549 = predict_residuals_on_series(qm_future_all, input_len, x_mean, x_std, y_mean, y_std, model)
future_corrected_all = np.clip(qm_future_all + pred_res_1549, 0, None)

# =========================
# Plot ERA5 vs Future (Uncorrected vs Corrected) 2015–2025
# =========================
start, end = pd.Timestamp("2015-01-01"), pd.Timestamp("2025-12-31")
mask_era = (dates_era5 >= start) & (dates_era5 <= end)
x_era, y_era = dates_era5[mask_era], obs_vals[mask_era]
mask_fu = (dates_future >= start) & (dates_future <= end)
x_unc, y_unc = dates_future[mask_fu], target_vals[mask_fu]
y_cor = future_corrected_all[mask_fu]

import calendar
def mean_seasonal_cycle(values, dates):
    """Compute monthly mean across years, return 12-element array"""
    df = pd.DataFrame({"val": values}, index=dates)
    return df.groupby(df.index.month).mean().values

era5_cycle = mean_seasonal_cycle(y_era, x_era)
unc_cycle  = mean_seasonal_cycle(y_unc, x_unc)
cor_cycle  = mean_seasonal_cycle(y_cor, x_unc)

months = np.arange(1, 13)
month_names = [calendar.month_abbr[m] for m in months]

plt.figure(figsize=(10,5))
plt.plot(months, unc_cycle, label="CMIP6 Uncorrected", marker='o')
plt.plot(months, cor_cycle, label="CMIP6 Corrected",  marker='o')
plt.plot(months, era5_cycle, label="ERA5",  marker='o')
plt.xticks(months, month_names)
plt.xlabel("Month")
plt.ylabel("Shortwave Radiation [W/m²]")
plt.title("2015–2025 Mean Seasonal Cycle Solar Radiation")
plt.grid(True)
plt.legend()
plt.tight_layout()
plt.show()

from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

common_dates = dates_era5.intersection(dates_future)
obs_common = pd.Series(obs_vals, index=dates_era5).loc[common_dates].values
corrected_common = pd.Series(future_corrected_all, index=dates_future).loc[common_dates].values

rmse = np.sqrt(mean_squared_error(obs_common, corrected_common))
mae = mean_absolute_error(obs_common, corrected_common)
r2 = r2_score(obs_common, corrected_common)

print(f"RMSE: {rmse:.4f} W/m²")
print(f"MAE: {mae:.4f} W/m²")
print(f"R²: {r2:.4f}")

# Plot histogram
plt.figure(figsize=(12, 5))
obs = y_era
sim_raw = y_unc
sim_corrected = y_cor
n = min(len(obs), len(sim_raw), len(sim_corrected))
plt.hist(sim_raw[:n], bins=50, alpha=0.5, label='CMIP6 Uncorrected', density=True)
plt.hist(sim_corrected[:n], bins=50, alpha=0.5, label='QM + CNN-LSTM Corrected', density=True)
plt.hist(obs[:n], bins=50, alpha=0.5, label='ERA5', density=True)
plt.xlabel('Shortwave Radiation (W/m²)')
plt.ylabel('Probability Density')
plt.title("Distribution of Monthly Shortwave Radiation (2015–2025)")
plt.legend()
plt.tight_layout()
plt.show()
