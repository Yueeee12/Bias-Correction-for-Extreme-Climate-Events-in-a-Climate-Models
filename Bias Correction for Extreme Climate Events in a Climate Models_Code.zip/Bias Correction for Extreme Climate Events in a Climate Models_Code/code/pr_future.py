import torch
import numpy as np
import xarray as xr
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d
from torch import nn
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import pandas as pd
import matplotlib.ticker as mticker
from cartopy.mpl.gridliner import LONGITUDE_FORMATTER, LATITUDE_FORMATTER


# -----------------------------
# Define CNN + LSTM architecture
# -----------------------------
class CNNLSTM(nn.Module):
    def __init__(self, input_len):
        super(CNNLSTM, self).__init__()
        self.conv1 = nn.Conv1d(in_channels=1, out_channels=16, kernel_size=3, padding=1)
        self.relu = nn.ReLU()
        self.lstm = nn.LSTM(input_size=16, hidden_size=32, batch_first=True)
        self.fc = nn.Linear(32, 1)

    def forward(self, x):
        x = self.relu(self.conv1(x))         # [batch, 16, seq]
        x = x.permute(0, 2, 1)               # [batch, seq, 16]
        x, _ = self.lstm(x)                  # [batch, seq, 32]
        x = self.fc(x[:, -1, :])             # [batch, 1]
        return x

# -----------------------------
# Quantile Mapping function
# -----------------------------
def quantile_mapping(obs, sim, sim_future):
    quantiles = np.linspace(0, 1, 1001)
    obs_q = np.quantile(obs, quantiles)
    sim_q = np.quantile(sim, quantiles)
    sim_q_unique, idx = np.unique(sim_q, return_index=True)
    obs_q_unique = obs_q[idx]
    qm_func = interp1d(sim_q_unique, obs_q_unique, bounds_error=False,
                       fill_value=(obs_q_unique[0], obs_q_unique[-1]))
    return qm_func(sim_future)

# -----------------------------
# Load historical and future data
# -----------------------------
era5 = xr.open_dataset("ERA5_tp.nc", chunks={'time': 10})
cmip6 = xr.open_dataset("CMIP6_pr.nc", chunks={'time': 10})
future_ds = xr.open_dataset("pr_20150115-20491215.nc", chunks={'time': 10})

# Convert units to mm/day
era5 = era5['tp'] * 1000
cmip6 = cmip6['pr'] * 86400
future = future_ds['pr'] * 86400

# Coordinate and regional cropping
era5 = era5.rename({'latitude': 'lat', 'longitude': 'lon'})
cmip6 = cmip6.where(cmip6 != 1e20)
era5 = era5.where(era5 < 1e10)

lat_min, lat_max = 25, 50
lon_min, lon_max = -125, -66
lon_min_c, lon_max_c = lon_min + 360, lon_max + 360

era5 = era5.sel(lat=slice(lat_max, lat_min), lon=slice(lon_min_c, lon_max_c),
                valid_time=slice("1950", "2014"))
cmip6 = cmip6.sel(lat=slice(lat_min, lat_max), lon=slice(lon_min_c, lon_max_c),
                  time=slice("1950", "2014"))
future = future.sel(lat=slice(lat_min, lat_max), lon=slice(lon_min_c, lon_max_c))

# Mean time series
obs = era5.mean(dim=['lat', 'lon']).resample(valid_time='1MS').mean().values
sim_hist = cmip6.mean(dim=['lat', 'lon']).resample(time='1MS').mean().values
sim_future = future.mean(dim=['lat', 'lon']).values

# -----------------------------
# Step 1: Apply Quantile Mapping
# -----------------------------
qm_corrected = quantile_mapping(obs, sim_hist, sim_future)

# -----------------------------
# Step 2: Use CNN-LSTM to predict residuals
# -----------------------------
def create_sequences(data, input_len=30):
    return np.array([data[i:i+input_len] for i in range(len(data)-input_len)])

input_len = 30
X_seq = create_sequences(qm_corrected, input_len)
X_tensor = torch.tensor(X_seq, dtype=torch.float32).unsqueeze(1)

# Load model and predict residuals
model = CNNLSTM(input_len)
model.load_state_dict(torch.load("cnn_lstm_residual_model.pth"))
model.eval()

with torch.no_grad():
    residuals = model(X_tensor).squeeze().numpy()

# Trim QM-corrected series
qm_trimmed = qm_corrected[input_len:]

# Final deep corrected precipitation
deep_corrected = qm_trimmed + residuals

# -----------------------------
# Combine historical and corrected future series (1950-2049)
# -----------------------------
full_precip = np.concatenate([obs, deep_corrected])
full_dates = pd.date_range("1950-01", periods=len(full_precip), freq='MS')

# Convert to DataFrame for analysis and plotting
df_full = pd.DataFrame({
    'date': full_dates,
    'precip': full_precip
})
df_full['year'] = df_full['date'].dt.year

# -----------------------------
# Define extreme thresholds using historical observations
# -----------------------------
threshold_95 = np.percentile(obs, 95)
threshold_99 = np.percentile(obs, 99)
obs_max = np.max(obs)

# Identify extreme events
df_full['extreme95'] = df_full['precip'] > threshold_95
df_full['extreme99'] = df_full['precip'] > threshold_99
df_full['beyond_hist_max'] = df_full['precip'] > obs_max

# -----------------------------
# 1️⃣ Yearly frequency of extreme events
# -----------------------------
annual_stats = df_full.groupby('year').agg({
    'extreme95': 'sum',
    'extreme99': 'sum',
    'beyond_hist_max': 'sum'
}).rename(columns={
    'extreme95': 'count_95',
    'extreme99': 'count_99',
    'beyond_hist_max': 'count_beyond_max'
})

# 筛选2015-2049年数据
annual_stats_future = annual_stats.loc[2015:2049]

plt.figure(figsize=(12,6))
plt.plot(annual_stats_future.index, annual_stats_future['count_95'], label='> 95th Percentile')
plt.plot(annual_stats_future.index, annual_stats_future['count_99'], label='> 99th Percentile')
plt.plot(annual_stats_future.index, annual_stats_future['count_beyond_max'], label='> Historical Max')
plt.xlabel("Year")
plt.ylabel("Number of Extreme Months")
plt.title("Annual Extreme Precipitation Frequency (2015–2049)")
plt.legend()
plt.tight_layout()
plt.show()


def calc_duration_series(extreme_series):
    """计算布尔序列中连续True段的长度列表"""
    durations = []
    count = 0
    for val in extreme_series:
        if val:
            count += 1
        else:
            if count > 0:
                durations.append(count)
            count = 0
    # 处理序列末尾仍为True的情况
    if count > 0:
        durations.append(count)
    return durations

# 计算2015-2049年内95%和99%极端事件的持续时间（连续月数）
df_filtered = df_full[(df_full['year'] >= 2015) & (df_full['year'] <= 2049)]

durations_95 = calc_duration_series(df_filtered['extreme95'].values)
durations_99 = calc_duration_series(df_filtered['extreme99'].values)

# 统计持续时间出现频次（最长持续时间可能较长，限制x轴长度）
max_duration = 6  # 比如最长考虑12个月
bins = np.arange(1, max_duration + 2) - 0.5

hist_95, _ = np.histogram(durations_95, bins=bins)
hist_99, _ = np.histogram(durations_99, bins=bins)

# 绘图
plt.figure(figsize=(10,6))
x = np.arange(1, max_duration + 1)
plt.bar(x - 0.2, hist_95, width=0.4, label='> 95th Percentile', color='steelblue')
plt.bar(x + 0.2, hist_99, width=0.4, label='> 99th Percentile', color='indianred')
plt.xlabel("Duration of Consecutive Extreme Months")
plt.ylabel("Frequency")
plt.title("Distribution of Extreme Precipitation Event Durations (2015–2049)")
plt.xticks(x)
plt.legend()
plt.grid(True, linestyle='--', alpha=0.5)
plt.tight_layout()
plt.show()

# -----------------------------
# 2️⃣ Average intensity of extreme months
# -----------------------------
# 过滤2015-2049年数据
df_filtered = df_full[(df_full['year'] >= 2015) & (df_full['year'] <= 2049)]

# 提取95%极端事件并计算年均降水强度
extreme95_months = df_filtered[df_filtered['extreme95']]
avg_extreme95_by_year = extreme95_months.groupby('year')['precip'].mean()

# 提取99%极端事件并计算年均降水强度
extreme99_months = df_filtered[df_filtered['extreme99']]
avg_extreme99_by_year = extreme99_months.groupby('year')['precip'].mean()

plt.figure(figsize=(12,6))
plt.plot(avg_extreme95_by_year.index, avg_extreme95_by_year.values, marker='o', color='darkred', label='Extreme > 95%')
plt.plot(avg_extreme99_by_year.index, avg_extreme99_by_year.values, marker='x', color='navy', label='Extreme > 99%')

plt.xlabel("Year")
plt.ylabel("Mean Precipitation (mm/day)")
plt.title("Average Strength of Extreme Precipitation Events (2015–2049)")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()

import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

# -----------------------------
# 计算百分位
# -----------------------------
future_2015_2025 = future.sel(time=slice("2015", "2025"))
future_2015_2049 = future.sel(time=slice("2015", "2049"))

p95_2015_2025 = future_2015_2025.quantile(0.95, dim="time")
p99_2015_2025 = future_2015_2025.quantile(0.99, dim="time")
p95_2015_2049 = future_2015_2049.quantile(0.95, dim="time")
p99_2015_2049 = future_2015_2049.quantile(0.99, dim="time")

# -----------------------------
# 统一颜色刻度 (所有数据一起算 min/max)
# -----------------------------
vmin = min(
    p95_2015_2025.min().compute().item(),
    p99_2015_2025.min().compute().item(),
    p95_2015_2049.min().compute().item(),
    p99_2015_2049.min().compute().item()
)
vmax = max(
    p95_2015_2025.max().compute().item(),
    p99_2015_2025.max().compute().item(),
    p95_2015_2049.max().compute().item(),
    p99_2015_2049.max().compute().item()
)

# -----------------------------
# 绘图 (重用 plot_spatial)
# -----------------------------
def plot_spatial_percentile(data, lats, lons, title, vmin, vmax):
    fig, ax = plt.subplots(figsize=(9, 6), subplot_kw={'projection': ccrs.PlateCarree()},
                           constrained_layout=True)
    im = ax.pcolormesh(lons, lats, data, cmap="BuPu", shading="auto",
                       vmin=vmin, vmax=vmax, alpha=0.9)

    # 添加地理特征
    ax.coastlines(resolution='50m', linewidth=0.8)
    ax.add_feature(cfeature.BORDERS, linewidth=0.6, linestyle=':')
    ax.add_feature(cfeature.STATES, linewidth=0.4, alpha=0.5)

    # 设置范围
    ax.set_extent([lon_min, lon_max, lat_min, lat_max], crs=ccrs.PlateCarree())

    # 添加网格
    gl = ax.gridlines(crs=ccrs.PlateCarree(), draw_labels=True,
                      linewidth=0.8, color='gray', alpha=0.5, linestyle='--')
    gl.top_labels = False
    gl.right_labels = False
    gl.xlocator = mticker.FixedLocator(range(-120, -60, 10))
    gl.ylocator = mticker.FixedLocator(range(30, 55, 5))
    gl.xformatter = LONGITUDE_FORMATTER
    gl.yformatter = LATITUDE_FORMATTER
    gl.xlabel_style = {'size': 8}
    gl.ylabel_style = {'size': 8}

    # 颜色条
    cbar = plt.colorbar(im, ax=ax, orientation='vertical',
                        label='Precipitation (mm/day)', shrink=0.85, aspect=15)
    cbar.ax.tick_params(labelsize=8)

    ax.set_title(title, fontsize=10, pad=10)
    plt.show()


# -----------------------------
# 画四张图
# -----------------------------
plot_spatial_percentile(p95_2015_2025, future_2015_2025.lat, future_2015_2025.lon,
                        "Future Corrected 2015–2025 95th Percentile", vmin, vmax)
plot_spatial_percentile(p99_2015_2025, future_2015_2025.lat, future_2015_2025.lon,
                        "Future Corrected 2015–2025 99th Percentile", vmin, vmax)

plot_spatial_percentile(p95_2015_2049, future_2015_2049.lat, future_2015_2049.lon,
                        "Future Corrected 2015–2049 95th Percentile", vmin, vmax)
plot_spatial_percentile(p99_2015_2049, future_2015_2049.lat, future_2015_2049.lon,
                        "Future Corrected 2015–2049 99th Percentile", vmin, vmax)



# -----------------------------
# 3️⃣ Full precipitation time series (obs + corrected future)
# -----------------------------
plt.figure(figsize=(14,6))
plt.plot(df_full['date'], df_full['precip'], label='Observed (1950–2014) + Corrected Future (2015–2049)')
plt.axvline(pd.Timestamp('2015-01-01'), color='red', linestyle='--', label='Future Start (2015)')
plt.xlabel("Year")
plt.ylabel("Precipitation (mm/day)")
plt.title("Monthly Precipitation Time Series (1950–2049)")
plt.legend()
plt.tight_layout()
plt.show()

# -----------------------------
# Evaluation metrics: deep corrected vs QM-corrected (future only)
# -----------------------------
rmse = np.sqrt(mean_squared_error(qm_trimmed, deep_corrected))
mae = mean_absolute_error(qm_trimmed, deep_corrected)
r2 = r2_score(qm_trimmed, deep_corrected)

print("\n✅ Performance metrics: Deep Correction vs QM (Future):")
print(f"RMSE: {rmse:.4f} mm/day")
print(f"MAE: {mae:.4f} mm/day")
print(f"R²: {r2:.4f}")

# -----------------------------
# Extreme index comparison (future only)
# -----------------------------
qm_95, qm_99 = np.percentile(qm_corrected, [95, 99])
deep_95, deep_99 = np.percentile(deep_corrected, [95, 99])

# 打印指标
print("\n✅ Extreme Precipitation Indices (mm/day, Future):")
print(f"QM 95th: {qm_95:.4f}, QM + CNN-LSTM 95th: {deep_95:.4f}")
print(f"QM 99th: {qm_99:.4f}, QM + CNN-LSTM 99th: {deep_99:.4f}")

# 绘制柱状图比较
plt.figure(figsize=(6, 4))
labels = ['95th Percentile', '99th Percentile']
x = np.arange(len(labels))
width = 0.35

plt.bar(x - width/2, [qm_95, qm_99], width, label='QM Corrected', color='skyblue')
plt.bar(x + width/2, [deep_95, deep_99], width, label='QM + CNN-LSTM', color='salmon')

plt.ylabel('Precipitation (mm/day)')
plt.title('Future Extreme Precipitation Comparison (2015–2049)')
plt.xticks(x, labels)
plt.legend()
plt.tight_layout()
plt.show()


# -----------------------------
# Output years with values beyond historical maximum
# -----------------------------
years_beyond_max = df_full[df_full['beyond_hist_max']]['year'].unique()
print("📌 Years with months exceeding historical maximum precipitation:")
print(years_beyond_max)

from scipy.stats import genextreme
import matplotlib.pyplot as plt
import numpy as np

# -----------------------------
# Step 1: Prepare annual maxima series
# -----------------------------
# ERA5: 2015-2025
df_era5 = df_full[(df_full['year'] >= 2015) & (df_full['year'] <= 2025)].copy()
era5_annual_max = df_era5.groupby('year')['precip'].max().values

# QM & QM+CNN-LSTM & raw CMIP6: 2015-2049
df_future = df_full[df_full['year'] >= 2015].copy()
raw_annual_max = df_future.groupby('year')['precip'].max().values  # raw CMIP6
qm_annual_max = df_future.groupby('year')['precip_qm'].max().values  # QM corrected
deep_annual_max = deep_corrected.reshape(-1)[:len(qm_annual_max)]  # CNN-LSTM

print(df_future.columns)


# -----------------------------
# Step 2: Fit GEV distribution
# -----------------------------
def fit_gev(data):
    c, loc, scale = genextreme.fit(data)
    return c, loc, scale

c_era5, loc_era5, scale_era5 = fit_gev(era5_annual_max)
c_raw, loc_raw, scale_raw = fit_gev(raw_annual_max)
c_qm, loc_qm, scale_qm = fit_gev(qm_annual_max)
c_deep, loc_deep, scale_deep = fit_gev(deep_annual_max)

# -----------------------------
# Step 3: Compute return levels
# -----------------------------
return_periods = np.array([2, 5, 10, 20, 50, 100])

def gev_return_level(c, loc, scale, T):
    return genextreme.ppf(1 - 1/np.array(T), c, loc=loc, scale=scale)

rl_era5 = gev_return_level(c_era5, loc_era5, scale_era5, return_periods)
rl_raw = gev_return_level(c_raw, loc_raw, scale_raw, return_periods)
rl_qm = gev_return_level(c_qm, loc_qm, scale_qm, return_periods)
rl_deep = gev_return_level(c_deep, loc_deep, scale_deep, return_periods)

# -----------------------------
# Step 4: Plot return level curves
# -----------------------------
plt.figure(figsize=(8,6))
plt.plot(return_periods, rl_era5, 'd-', label='ERA5 (2015–2025)', color='green')
plt.plot(return_periods, rl_raw, '^-', label='Raw CMIP6 (2015–2049)', color='purple')
plt.plot(return_periods, rl_qm, 'o-', label='QM Corrected (2015–2049)', color='skyblue')
plt.plot(return_periods, rl_deep, 's-', label='QM + CNN-LSTM (2015–2049)', color='salmon')

plt.xlabel('Return Period (years)')
plt.ylabel('Return Level (mm/day)')
plt.title('GEV Return Level Plot: ERA5 vs Future Simulations')
plt.xscale('log')
plt.xticks(return_periods, return_periods)
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend()
plt.tight_layout()
plt.show()

# -----------------------------
# Step 5: Interpretation
# -----------------------------
print("✅ GEV parameters:")
print(f"ERA5: shape={c_era5:.3f}, loc={loc_era5:.3f}, scale={scale_era5:.3f}")
print(f"Raw CMIP6: shape={c_raw:.3f}, loc={loc_raw:.3f}, scale={scale_raw:.3f}")
print(f"QM Corrected: shape={c_qm:.3f}, loc={loc_qm:.3f}, scale={scale_qm:.3f}")
print(f"QM + CNN-LSTM: shape={c_deep:.3f}, loc={loc_deep:.3f}, scale={scale_deep:.3f}")

print("\nObservation:")
print("ERA5 shows observed extremes (2015–2025).")
print("Raw CMIP6, QM, and CNN-LSTM show projected extremes (2015–2049).")
print("CNN-LSTM correction generally smooths and stabilizes extreme values compared to QM and raw CMIP6.")
