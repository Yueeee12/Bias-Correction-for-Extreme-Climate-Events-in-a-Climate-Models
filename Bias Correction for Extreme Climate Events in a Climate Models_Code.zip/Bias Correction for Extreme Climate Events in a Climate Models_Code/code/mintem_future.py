import numpy as np
import pandas as pd
import xarray as xr
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import matplotlib.pyplot as plt
from scipy.interpolate import interp1d


# --- Time Helper Functions ---
def detect_time_dim(da: xr.DataArray) -> str:
    """Detect the time dimension name in an xarray DataArray."""
    if "time" in da.dims:
        return "time"
    if "valid_time" in da.dims:
        return "valid_time"
    for d in da.dims:
        if "time" in d:
            return d
    raise ValueError(f"Time dimension not found in dims={da.dims}")


def to_datetime_index(da: xr.DataArray, dim: str) -> pd.DatetimeIndex:
    """Convert the time dimension of an xarray DataArray to a pandas DatetimeIndex."""
    try:
        idx = da.indexes[dim]
        return pd.DatetimeIndex(idx.to_datetimeindex())
    except Exception:
        try:
            # Check for calendar attribute and convert to standard calendar if needed
            cal = getattr(da[dim].dt, "calendar", None)
            da2 = da.convert_calendar("standard", use_cftime=False, dim=dim)
            return pd.to_datetime(da2[dim].values)
        except Exception:
            raise RuntimeError("Cannot convert time to datetime index.")


# --- Monthly Seasonal Quantile Mapping (QM) ---
def seasonal_qm_fit_apply(obs_vals, obs_dates, sim_vals, sim_dates, target_vals, target_dates, n_q=1001):
    """
    Fit seasonal quantile mapping (QM) using observed and simulated data, then apply to target data.

    Parameters:
        obs_vals: Observed temperature values (1D array)
        obs_dates: DatetimeIndex corresponding to observed values
        sim_vals: Simulated (model) values for QM fitting (1D array)
        sim_dates: DatetimeIndex corresponding to simulated values
        target_vals: Target values to correct (1D array)
        target_dates: DatetimeIndex corresponding to target values
        n_q: Number of quantiles to use (default: 1001)

    Returns:
        out: QM-corrected target values (1D array)
    """
    out = np.empty_like(target_vals, dtype=float)
    # Apply QM separately for each month (1-12)
    for m in range(1, 13):
        # Extract data for the current month
        o = np.asarray(obs_vals[obs_dates.month == m], float)
        s = np.asarray(sim_vals[sim_dates.month == m], float)
        t = np.asarray(target_vals[target_dates.month == m], float)

        # Calculate quantiles
        q = np.linspace(0, 1, n_q)
        o_q = np.quantile(o, q)  # Observed quantiles
        s_q = np.quantile(s, q)  # Simulated quantiles

        # Remove duplicate quantile values to avoid interpolation issues
        s_q_u, idx = np.unique(s_q, return_index=True)
        o_q_u = o_q[idx]

        # Create interpolation function (map simulated quantiles to observed)
        f = interp1d(
            s_q_u, o_q_u,
            bounds_error=False,
            fill_value=(o_q_u[0], o_q_u[-1])  # Extrapolate with min/max if out of bounds
        )

        # Apply correction to target data for the current month
        out[target_dates.month == m] = f(t)
    return out


# --- Sequence Generation for Time-Series Models ---
def make_sequences(arr, L=60):
    """
    Convert a 1D time-series array into input sequences for LSTM.

    Parameters:
        arr: 1D time-series array
        L: Length of each input sequence (default: 60 time steps)

    Returns:
        sequences: 2D array of shape (n_sequences, L)
    """
    arr = np.asarray(arr, float)
    return np.array([arr[i:i + L] for i in range(len(arr) - L)])


# --- CNN-LSTM Hybrid Model ---
class CNNLSTM(nn.Module):
    """Hybrid CNN-LSTM model for residual correction of QM outputs."""

    def __init__(self, input_len):
        super().__init__()
        # 1D CNN layer (extract local temporal features)
        self.conv1 = nn.Conv1d(1, 16, kernel_size=3, padding=1)
        self.relu = nn.ReLU()  # Activation function
        # LSTM layer (capture long-term temporal dependencies)
        self.lstm = nn.LSTM(16, 32, batch_first=True)  # 16 input channels, 32 hidden units
        # Fully connected layer (output residual prediction)
        self.fc = nn.Linear(32, 1)
        self.input_len = input_len  # Length of input sequences

    def forward(self, x):
        """Forward pass of the CNN-LSTM model."""
        # CNN layer: [batch_size, 1, seq_len] → [batch_size, 16, seq_len]
        x = self.relu(self.conv1(x))
        # Permute for LSTM: [batch_size, seq_len, 16] (required for batch_first=True)
        x = x.permute(0, 2, 1)
        # LSTM layer: output shape → [batch_size, seq_len, 32]
        x, _ = self.lstm(x)
        # Use only the last time step of LSTM output for prediction
        y = self.fc(x[:, -1, :])  # [batch_size, 1]
        return y.squeeze(1)  # Remove extra dimension → [batch_size]


# ========== Load Data ==========
# CMIP6 minimum temperature (tasmin)
ds_tasmin = xr.open_dataset("tasmin_Amon_CESM2_ssp245_r4i1p1f1_gn_20150115-20491215.nc", chunks={'time': 10})
future = ds_tasmin['tasmin']  # Future CMIP6 tasmin data (unit: K)

# ERA5 minimum temperature (mn2t: 2m minimum temperature)
era5_ds = xr.open_dataset("mn2t.nc", chunks={'time': 10})
era5 = era5_ds['mn2t']  # ERA5 observed tasmin data (unit: K)

# Print time ranges for verification
print("CMIP6 time range:", future.time.min().values, "to", future.time.max().values)
print("ERA5 time range:", era5.valid_time.min().values, "to", era5.valid_time.max().values)

# ========== Dimension Processing ==========
# Standardize latitude/longitude coordinate names to 'lat'/'lon'
if "latitude" in era5.coords:
    era5 = era5.rename({"latitude": "lat", "longitude": "lon"})
if "latitude" in future.coords:
    future = future.rename({"latitude": "lat", "longitude": "lon"})

# Detect time dimension names for ERA5 and CMIP6
time_dim_era5 = detect_time_dim(era5)
time_dim_future = detect_time_dim(future)

# Convert time coordinates to pandas DatetimeIndex
dates_era5 = to_datetime_index(era5, time_dim_era5)
dates_future = to_datetime_index(future, time_dim_future)

# Spatial Subsetting (target region: e.g., CONUS)
lat_min, lat_max = 25, 50  # Latitude range (25°N to 50°N)
lon_min, lon_max = -125, -66  # Longitude range (-125°W to -66°W)
lon_min_c, lon_max_c = lon_min + 360, lon_max + 360  # Convert W longitude to E longitude (0-360°)

# Crop data to target region (note: ERA5 latitude may be in descending order)
era5 = era5.sel(lat=slice(lat_max, lat_min), lon=slice(lon_min_c, lon_max_c))
future = future.sel(lat=slice(lat_min, lat_max), lon=slice(lon_min_c, lon_max_c))

# Temporal Subsetting
# ERA5: 2015-2025 (calibration period)
era5_sel = era5.sel({time_dim_era5: slice("2015-01", "2025-12")})
# CMIP6: 2015-2049 (full future period)
future_sel = future.sel({time_dim_future: slice("2015-01", "2049-12")})

# Compute spatial average (regional mean) and monthly average
# ERA5: regional mean → monthly mean
era5_mon = era5_sel.mean(dim=["lat", "lon"]).resample({time_dim_era5: "1MS"}).mean()
# CMIP6: regional mean → monthly mean ("1MS" = month start frequency)
future_mon = future_sel.mean(dim=["lat", "lon"]).resample({time_dim_future: "1MS"}).mean()

# Prepare data arrays and corresponding datetime indexes
obs_vals = era5_mon.values  # ERA5 observed monthly mean values
target_vals = future_mon.values  # CMIP6 future monthly mean values (to correct)
dates_obs = to_datetime_index(era5_mon, time_dim_era5)  # ERA5 datetime index
dates_target = to_datetime_index(future_mon, time_dim_future)  # CMIP6 future datetime index

# CMIP6 subset for QM calibration (2015-2025, matching ERA5 period)
future_mon_1525 = future_mon.sel({time_dim_future: slice("2015-01", "2025-12")})
sim_vals = future_mon_1525.values  # CMIP6 calibration period values
sim_dates = to_datetime_index(future_mon_1525, time_dim_future)  # CMIP6 calibration datetime index

# ========== Apply Quantile Mapping (QM) ==========
# Correct full CMIP6 future data (2015-2049) using seasonal QM
qm_future_all = seasonal_qm_fit_apply(
    obs_vals=obs_vals, obs_dates=dates_obs,
    sim_vals=sim_vals, sim_dates=sim_dates,
    target_vals=target_vals, target_dates=dates_target,
    n_q=1001  # Use 1001 quantiles for smooth interpolation
)

# ========== CNN-LSTM for Residual Correction ==========
# Identify overlapping time period between ERA5 (obs) and QM-corrected CMIP6
mask_overlap = (dates_target >= dates_obs.min()) & (dates_target <= dates_obs.max())
qm_overlap = qm_future_all[mask_overlap]  # QM-corrected values in overlap period
dates_overlap = dates_target[mask_overlap]  # Datetime index for overlap period

# Align ERA5 and QM data by date (handle potential mismatches)
df_obs = pd.DataFrame({"date": dates_obs, "obs": obs_vals}).set_index("date")
df_qm = pd.DataFrame({"date": dates_overlap, "qm": qm_overlap}).set_index("date")
joined = df_obs.join(df_qm, how="inner")  # Inner join to keep only matching dates

# Calculate residuals (observed - QM-corrected) for model training
obs_tr = joined["obs"].values  # Observed values for training
qm_tr = joined["qm"].values  # QM-corrected values for training
residuals_train = obs_tr - qm_tr  # Residuals to predict with CNN-LSTM

# Generate input sequences for LSTM
input_len = 60  # Use 60 previous time steps to predict residual
X_np = make_sequences(qm_tr, L=input_len)  # Input sequences (QM-corrected data)
y_np = residuals_train[input_len:]  # Target residuals (shift by input_len)

# Normalize data (z-score standardization)
x_mean, x_std = X_np.mean(), X_np.std() + 1e-8  # Avoid division by zero
Xn = (X_np - x_mean) / x_std  # Normalized inputs
y_mean, y_std = y_np.mean(), y_np.std() + 1e-8
yn = (y_np - y_mean) / y_std  # Normalized targets

# Convert to PyTorch tensors
X_tensor = torch.tensor(Xn, dtype=torch.float32).unsqueeze(1)  # Add channel dim: [N, 1, L]
y_tensor = torch.tensor(yn, dtype=torch.float32)  # [N]

# Split into training and validation sets (80% train, 20% val)
n = len(X_tensor)
ntr = max(int(0.8 * n), 1)  # Ensure at least 1 training sample
X_tr, X_va = X_tensor[:ntr], X_tensor[ntr:]
y_tr, y_va = y_tensor[:ntr], y_tensor[ntr:]

# Create DataLoaders for batch processing
train_loader = DataLoader(TensorDataset(X_tr, y_tr), batch_size=64, shuffle=True)
val_loader = DataLoader(TensorDataset(X_va, y_va), batch_size=64) if len(X_va) > 0 else None

# Initialize model, optimizer, and loss function
model = CNNLSTM(input_len=input_len)
optimizer = optim.AdamW(
    model.parameters(),
    lr=1e-3,  # Learning rate
    weight_decay=1e-5  # L2 regularization to prevent overfitting
)
criterion = nn.MSELoss()  # Mean Squared Error for regression

# Train model with early stopping
best_val = np.inf  # Track best validation loss
patience = 0  # Counter for early stopping
max_pat = 30  # Stop if no improvement for 30 epochs

for ep in range(300):  # Maximum 300 epochs
    # Training phase
    model.train()
    tr_losses = []
    for bx, by in train_loader:
        optimizer.zero_grad()  # Reset gradients
        pred = model(bx)  # Forward pass
        loss = criterion(pred, by)  # Calculate loss
        loss.backward()  # Backpropagation
        torch.nn.utils.clip_grad_norm_(model.parameters(), 5.0)  # Gradient clipping
        optimizer.step()  # Update weights
        tr_losses.append(loss.item())

    # Validation phase
    if val_loader is not None:
        model.eval()
        va_losses = []
        with torch.no_grad():  # Disable gradient computation
            for bx, by in val_loader:
                va_losses.append(criterion(model(bx), by).item())
        va_loss = np.mean(va_losses)
    else:
        # If no validation data, use training loss
        va_loss = np.mean(tr_losses)

    tr_loss = np.mean(tr_losses)
    print(f"Epoch {ep + 1:03d} | Train Loss: {tr_loss:.6f} | Val Loss: {va_loss:.6f}")

    # Early stopping check
    if va_loss < best_val - 1e-6:  # Improvement threshold (1e-6)
        best_val = va_loss
        patience = 0
        # Save best model weights
        torch.save(model.state_dict(), "best_cnn_lstm_tasmin.pth")
    else:
        patience += 1
        if patience >= max_pat:
            print("Early stopping triggered (no improvement for {} epochs).".format(max_pat))
            break

# Load best model weights for inference
model.load_state_dict(torch.load("best_cnn_lstm_tasmin.pth", map_location="cpu"))
model.eval()


def predict_residuals_on_series(qm_series, L, x_mean, x_std, y_mean, y_std, mdl):
    """
    Predict residuals for a full QM-corrected time series using the trained CNN-LSTM model.

    Parameters:
        qm_series: QM-corrected time series (1D array)
        L: Input sequence length (same as training)
        x_mean/x_std: Normalization parameters for inputs
        y_mean/y_std: Normalization parameters for outputs
        mdl: Trained CNN-LSTM model

    Returns:
        res: Predicted residuals (1D array, same length as qm_series)
    """
    qm_series = np.asarray(qm_series, float)
    res = np.zeros_like(qm_series)  # Store predicted residuals
    cnt = np.zeros_like(qm_series)  # Count predictions per time step (for averaging)

    with torch.no_grad():
        for i in range(len(qm_series) - L):
            # Extract input window
            window = qm_series[i:i + L]
            # Normalize window
            win_n = (window - x_mean) / x_std
            # Convert to tensor with shape [1, 1, L] (batch=1, channel=1, length=L)
            x = torch.tensor(win_n, dtype=torch.float32).unsqueeze(0).unsqueeze(1)
            # Predict normalized residual
            pred_n = mdl(x).cpu().numpy()[0]
            # Denormalize residual
            pred = pred_n * y_std + y_mean
            # Assign to the time step immediately after the window
            res[i + L] += pred
            cnt[i + L] += 1

    # Handle time steps with no predictions (use 0 for residuals)
    cnt[cnt == 0] = 1
    return res / cnt


# Predict residuals for full QM-corrected future data (2015-2049)
pred_res_1549 = predict_residuals_on_series(
    qm_future_all, input_len, x_mean, x_std, y_mean, y_std, model
)

# Final correction: QM output + CNN-LSTM predicted residuals
future_corrected_all = qm_future_all + pred_res_1549

# ========== Visualization ==========
# Define time range for plotting (2015-2025, matching ERA5 period)
start, end = pd.Timestamp("2015-01-01"), pd.Timestamp("2025-12-31")

# Extract ERA5 data for plotting
mask_era = (dates_obs >= start) & (dates_obs <= end)
x_era, y_era = dates_obs[mask_era], obs_vals[mask_era]

# Extract CMIP6 data (uncorrected and corrected) for plotting
mask_fu = (dates_target >= start) & (dates_target <= end)
x_unc, y_unc = dates_target[mask_fu], target_vals[mask_fu]  # Uncorrected CMIP6
y_cor = future_corrected_all[mask_fu]  # QM + CNN-LSTM corrected CMIP6

# ===== Time Series Plot (Revised) =====
# Align ERA5 data to CMIP6 dates using temporal interpolation
era_series = pd.Series(obs_vals, index=dates_obs)
y_era_aligned = era_series.reindex(x_unc).interpolate('time').values  # Interpolate missing ERA5 dates

# Organize data into a DataFrame for easier grouping
df_min_temp = pd.DataFrame({
    'date': x_unc,
    'Uncorrected': y_unc,
    'Corrected': y_cor,
    'ERA5': y_era_aligned
})

# Calculate average temperature for each month (across years 2015-2025)
monthly_mean = df_min_temp.groupby(df_min_temp['date'].dt.month).mean()

# Plot seasonal cycle (monthly averages)
plt.figure(figsize=(12, 6))
plt.plot(range(1, 13), monthly_mean['Uncorrected'],
         label='CMIP6 (Uncorrected)', linewidth=1.2)
plt.plot(range(1, 13), monthly_mean['Corrected'],
         label='CMIP6 (QM + CNN-LSTM Corrected)', linewidth=1.8)
plt.plot(range(1, 13), monthly_mean['ERA5'],
         label='ERA5 (2015–2025)', linewidth=1.5)

# Customize plot
plt.xticks(range(1, 13), ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'])
plt.xlabel("Month")
plt.ylabel("Min Temperature (K)")
plt.title("Seasonal Cycle of Minimum Temperature (2015–2025)")
plt.grid(True, linestyle='--', alpha=0.3)  # Light grid for readability
plt.legend(loc='best')
plt.tight_layout()  # Adjust layout to prevent label cutoff
plt.show()

# ===== Performance Metrics: CNN-LSTM Correction vs QM =====
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# Define time range for performance evaluation (2015-2025)
start_perf, end_perf = pd.Timestamp("2015"), pd.Timestamp("2025")
mask_perf = (dates_target >= start_perf) & (dates_target <= end_perf)

# Extract QM-only and QM+CNN-LSTM corrected data for the evaluation period
qm_trimmed = qm_future_all[mask_perf]
deep_corrected = future_corrected_all[mask_perf]

# Ensure both arrays have the same length (safety check)
min_len = min(len(qm_trimmed), len(deep_corrected))
qm_trimmed = qm_trimmed[:min_len]
deep_corrected = deep_corrected[:min_len]

# Calculate regression metrics
rmse = np.sqrt(mean_squared_error(qm_trimmed, deep_corrected))  # Root Mean Squared Error
mae = mean_absolute_error(qm_trimmed, deep_corrected)  # Mean Absolute Error
r2 = r2_score(qm_trimmed, deep_corrected)  # R-squared (goodness of fit)

# Print metrics
print("\n✅ Performance metrics: QM + CNN-LSTM vs QM-only (Future Period 2015-2025):")
print(f"RMSE: {rmse:.4f} K")
print(f"MAE: {mae:.4f} K")
print(f"R²: {r2:.4f}")

# ===== Temperature Distribution Histogram =====
plt.figure(figsize=(12, 6))

# Define histogram bins (cover full range of temperature data with 1K intervals)
temp_min = df_min_temp[['Uncorrected', 'Corrected', 'ERA5']].min().min() - 1
temp_max = df_min_temp[['Uncorrected', 'Corrected', 'ERA5']].max().max() + 1
bins = np.arange(temp_min, temp_max, 1)

# Plot histograms with transparency
plt.hist(df_min_temp['Uncorrected'], bins=bins, alpha=0.5, label='CMIP6 (Uncorrected)')
plt.hist(df_min_temp['Corrected'], bins=bins, alpha=0.7, label='CMIP6 (QM + CNN-LSTM Corrected)')
plt.hist(df_min_temp['ERA5'], bins=bins, alpha=0.5, label='ERA5 (2015–2025)')

# Customize plot
plt.xlabel("Minimum Temperature (K)")
plt.ylabel("Frequency")
plt.title("Histogram of Minimum Temperature (2015–2025)")
plt.grid(True, linestyle='--', alpha=0.5)
plt.legend(loc='upper right')
plt.tight_layout()
plt.show()